use rodio::{Decoder, DeviceSinkBuilder, Player, Source};
use std::fs::File;
use std::io::{Read, Seek, SeekFrom, Write};
use std::path::PathBuf;
use std::time::{Duration, Instant};

struct HttpSource {
    client: reqwest::blocking::Client,
    url: String,
    resp: reqwest::blocking::Response,
    pos: u64,
    total: Option<u64>,
    part: PathBuf,
    file: Option<File>,
    done: bool,
}

impl Read for HttpSource {
    fn read(&mut self, buf: &mut [u8]) -> std::io::Result<usize> {
        let n = self.resp.read(buf)?;
        if n == 0 {
            if !self.done {
                self.done = true;
                eprintln!("EOF pos={} total={:?}", self.pos, self.total);
                if let Some(mut f) = self.file.take() {
                    let _ = f.flush();
                }
                eprintln!("EOF pos={} total={:?}", self.pos, self.total);
            }
            return Ok(0);
        }
        self.pos += n as u64;
        if let Some(f) = self.file.as_mut() {
            let _ = f.write_all(&buf[..n]);
        }
        Ok(n)
    }
}
impl Seek for HttpSource {
    fn seek(&mut self, from: SeekFrom) -> std::io::Result<u64> {
        let target = match from {
            SeekFrom::Start(p) => p as i64,
            SeekFrom::Current(p) => self.pos as i64 + p,
            SeekFrom::End(p) => match self.total {
                Some(total) => total as i64 + p,
                None => return Err(std::io::Error::new(std::io::ErrorKind::Unsupported, "size unknown")),
            },
        };
        if target < 0 { return Err(std::io::Error::new(std::io::ErrorKind::InvalidInput, "neg")); }
        let target = target as u64;
        eprintln!("SEEK -> {}", target);
        let resp = self.client.get(&self.url).header(reqwest::header::RANGE, format!("bytes={target}-")).send()
            .map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, e.to_string()))?;
        if !resp.status().is_success() {
            return Err(std::io::Error::new(std::io::ErrorKind::Other, format!("http {}", resp.status())));
        }
        self.resp = resp;
        self.pos = target;
        self.file = None;
        Ok(target)
    }
}

fn main() {
    let url = std::env::args().nth(1).expect("url");
    let client = reqwest::blocking::Client::builder()
        .connect_timeout(Duration::from_secs(10))
        .user_agent("Mozilla/5.0")
        .tcp_nodelay(true)
        .pool_idle_timeout(Duration::from_secs(90))
        .pool_max_idle_per_host(4)
        .build()
        .unwrap();
    let resp = client
        .get(&url)
        .header(reqwest::header::RANGE, "bytes=0-")
        .send()
        .unwrap();
    let total = resp
        .headers()
        .get(reqwest::header::CONTENT_RANGE)
        .and_then(|v| v.to_str().ok())
        .and_then(|s| s.rsplit('/').next())
        .and_then(|s| s.trim().parse::<u64>().ok())
        .or_else(|| resp.content_length());
    let part = PathBuf::from("/tmp/rustify_probe3.part");
    let file = File::create(&part).ok();
    let source = HttpSource { client: client.clone(), url: url.clone(), resp, pos: 0, total, part, file, done: false };
    let mut builder = Decoder::builder().with_data(source).with_hint("m4a").with_seekable(true);
    if let Some(total) = total { builder = builder.with_byte_len(total); }
    let decoder = builder.build().unwrap();
    println!("total={:?}", decoder.total_duration());
    let sink = DeviceSinkBuilder::open_default_sink().unwrap();
    let player = Player::connect_new(sink.mixer());
    player.set_volume(0.0);
    player.append(decoder);
    player.play();
    let start = Instant::now();
    let mut last = Instant::now();
    loop {
        std::thread::sleep(Duration::from_millis(250));
        if last.elapsed() >= Duration::from_secs(5) {
            println!("t={:.1}s pos={:?} empty={}", start.elapsed().as_secs_f64(), player.get_pos(), player.empty());
            last = Instant::now();
        }
        if player.empty() {
            println!("EMPTY at t={:.2}s", start.elapsed().as_secs_f64());
            break;
        }
        if start.elapsed() > Duration::from_secs(95) {
            println!("alive at 95s pos={:?}", player.get_pos());
            break;
        }
    }
    player.stop();
    let _ = std::fs::remove_file("/tmp/rustify_probe3.part");
}
