use rodio::{Decoder, DeviceSinkBuilder, Player, Source};
use std::fs::File;
use std::io::BufReader;
use std::time::{Duration, Instant};

fn main() {
    let path = std::env::args().nth(1).expect("path");
    let file = File::open(&path).unwrap();
    let decoder = Decoder::new(BufReader::with_capacity(256 * 1024, file)).unwrap();
    println!("total={:?}", decoder.total_duration());
    let sink = DeviceSinkBuilder::open_default_sink().unwrap();
    let player = Player::connect_new(sink.mixer());
    player.set_volume(0.0);
    player.append(decoder);
    player.play();
    let start = Instant::now();
    let mut last = Instant::now();
    loop {
        std::thread::sleep(Duration::from_millis(250));
        if last.elapsed() >= Duration::from_secs(2) {
            println!("t={:.1}s pos={:?} empty={} paused={}", start.elapsed().as_secs_f64(), player.get_pos(), player.empty(), player.is_paused());
            last = Instant::now();
        }
        if player.empty() {
            println!("EMPTY at t={:.2}s pos={:?}", start.elapsed().as_secs_f64(), player.get_pos());
            break;
        }
        if start.elapsed() > Duration::from_secs(75) {
            println!("still alive at 75s pos={:?}", player.get_pos());
            break;
        }
    }
    player.stop();
}
