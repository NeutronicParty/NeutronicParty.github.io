use std::io::Read;
use std::time::{Duration, Instant};

fn main() {
    let url = std::env::args().nth(1).expect("url");
    let client = reqwest::blocking::Client::builder()
        .connect_timeout(Duration::from_secs(10))
        .user_agent("Mozilla/5.0")
        .tcp_nodelay(true)
        .pool_idle_timeout(Duration::from_secs(90))
        .pool_max_idle_per_host(4)
        .build()
        .unwrap();
    let mut resp = client
        .get(&url)
        .header(reqwest::header::RANGE, "bytes=0-")
        .send()
        .unwrap();
    eprintln!("status={} len={:?}", resp.status(), resp.content_length());
    let start = Instant::now();
    let mut total: u64 = 0;
    let mut last = Instant::now();
    let mut buf = [0u8; 16384];
    loop {
        if last.elapsed() >= Duration::from_secs(1) {
            println!("t={:.0}s bytes={} rate={:.0}B/s", start.elapsed().as_secs_f64(), total, total as f64 / start.elapsed().as_secs_f64());
            last = Instant::now();
            if start.elapsed() >= Duration::from_secs(80) {
                println!("still alive after 80s, bytes={}", total);
                return;
            }
        }
        match resp.read(&mut buf) {
            Ok(0) => {
                println!("EOF at t={:.2}s bytes={}", start.elapsed().as_secs_f64(), total);
                return;
            }
            Ok(n) => {
                total += n as u64;
                std::thread::sleep(Duration::from_millis(50));
            }
            Err(e) => {
                println!("ERR at t={:.2}s bytes={}: {e}", start.elapsed().as_secs_f64(), total);
                return;
            }
        }
    }
}
