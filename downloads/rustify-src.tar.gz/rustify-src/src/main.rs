// Rustify - a small native YouTube Music client written in Rust.
//
// Search and stream resolution go through yt-dlp; audio is decoded and played
// by rodio (cpal), art is fetched straight from YouTube's CDN. No browser, no
// Electron, no Spotify client.

use std::cell::{Cell, RefCell};
use std::collections::{HashMap, HashSet, VecDeque};
use std::fs::File;
use std::io::{BufReader, Read, Seek, SeekFrom, Write};
use std::path::{Path, PathBuf};
use std::process::{Child, ChildStdout, Command, Stdio};
use std::rc::Rc;
use std::sync::atomic::{AtomicBool, AtomicU32, AtomicU64, AtomicUsize, Ordering};
use std::sync::mpsc::{self, Receiver, Sender};
use std::sync::{Arc, Condvar, Mutex, OnceLock};
use std::time::{Duration, Instant};

use gtk::glib::translate::ToGlibPtr;
use gtk::prelude::*;
use rodio::{Decoder, DeviceSinkBuilder, Player, Source};
use soup::Cookie;
use webkit2gtk::{
    CookieManagerExt, WebContext, WebContextExt, WebView, WebViewExt, WebsiteDataManager,
};

// allocator note: GTK/GLib allocate through glibc anyway, so running a
// second allocator only doubles the reserved heap and never returns it
#[cfg(target_env = "gnu")]
extern "C" {
    fn malloc_trim(pad: usize) -> std::os::raw::c_int;
}

#[link(name = "pangocairo-1.0")]
extern "C" {
    fn pango_cairo_show_layout(
        cr: *mut gtk::cairo::ffi::cairo_t,
        layout: *mut gtk::pango::ffi::PangoLayout,
    );
}

const DEVICE_NAME: &str = "Rustify";
const SIDEBAR_WIDTH: i32 = 240;
const SIDEBAR_COMPACT_WIDTH: i32 = 56;
const SEARCH_LIMIT: usize = 20;
const DETAIL_ROW_LIMIT: usize = 1000;
const PREFETCH_COUNT: usize = 4;
const PREFETCH_MAX_DURATION_MS: u32 = 30 * 60 * 1000;

// pid of the detached relaunch helper started by "Wipe User Data". The
// shutdown sweep must not kill it, or the app would not come back.
static RELAUNCH_PID: AtomicU32 = AtomicU32::new(0);

// "didy" easter egg: when set, the UI is repainted in a fast rainbow cycle.
static RAINBOW: AtomicBool = AtomicBool::new(false);

// "ilytommy" easter egg: the play/pause button refuses to sit still.
static JUMPY_PLAY: AtomicBool = AtomicBool::new(false);

// --------------------------------------------------------------- themes

// Each theme supplies a small palette; the shared structural sheet below does
// the heavy lifting so every theme keeps the same layout, radii and spacing.
const RUSTIFY_COLORS: &str = r#"
@define-color rs_bg #0d0916;
@define-color rs_bg2 #130d21;
@define-color rs_surface #181026;
@define-color rs_sidebar #100a1b;
@define-color rs_entry #0a0612;
@define-color rs_text #f6f1ff;
@define-color rs_border rgba(255, 255, 255, 0.08);
@define-color rs_accent #a855f7;
@define-color rs_accent2 #ec4899;
@define-color rs_accent_text #1a0526;
@define-color rs_danger #fb7185;
@define-color rs_on_danger #2b0710;
@define-color rs_shadow #050208;
"#;

const SLATE_COLORS: &str = r#"
@define-color rs_bg #0a0a0a;
@define-color rs_bg2 #101010;
@define-color rs_surface #161616;
@define-color rs_sidebar #0c0c0c;
@define-color rs_entry #060606;
@define-color rs_text #f5f5f5;
@define-color rs_border rgba(255, 255, 255, 0.10);
@define-color rs_accent #cfcfcf;
@define-color rs_accent2 #ffffff;
@define-color rs_accent_text #0a0a0a;
@define-color rs_danger #bfbfbf;
@define-color rs_on_danger #0a0a0a;
@define-color rs_shadow #000000;
"#;

const MINT_COLORS: &str = r#"
@define-color rs_bg #f4fbf7;
@define-color rs_bg2 #ecf7f1;
@define-color rs_surface #ffffff;
@define-color rs_sidebar #e8f5ee;
@define-color rs_entry #ffffff;
@define-color rs_text #17251d;
@define-color rs_border rgba(21, 71, 45, 0.12);
@define-color rs_accent #10b981;
@define-color rs_accent2 #34d399;
@define-color rs_accent_text #042116;
@define-color rs_danger #ef4444;
@define-color rs_on_danger #ffffff;
@define-color rs_shadow #163a26;
"#;

const LIGHT_COLORS: &str = r#"
@define-color rs_bg #ffffff;
@define-color rs_bg2 #f7f7f8;
@define-color rs_surface #ffffff;
@define-color rs_sidebar #f2f2f4;
@define-color rs_entry #ffffff;
@define-color rs_text #121216;
@define-color rs_border rgba(0, 0, 0, 0.12);
@define-color rs_accent #18181c;
@define-color rs_accent2 #3c3c44;
@define-color rs_accent_text #ffffff;
@define-color rs_danger #dc2626;
@define-color rs_on_danger #ffffff;
@define-color rs_shadow #000000;
"#;

// Light theme keeps the dark accent for text, controls and meters, but filled
// buttons use a soft grey so they don't punch black holes into the white UI.
const LIGHT_EXTRA: &str = r#"
button.suggested-action,
button.rustify-login,
.rustify-play {
    background-image: none;
    background-color: #e6e6ea;
    color: @rs_text;
    border-color: rgba(0, 0, 0, 0.14);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.10);
}

button.suggested-action image,
button.rustify-login image,
.rustify-play image {
    color: @rs_text;
}

button.suggested-action:hover,
button.rustify-login:hover,
.rustify-play:hover {
    background-image: none;
    background-color: #d9d9df;
    border-color: rgba(0, 0, 0, 0.20);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.12);
}

button.suggested-action:active,
button.rustify-login:active,
.rustify-play:active {
    background-image: none;
    background-color: #cfcfd6;
    border-color: rgba(0, 0, 0, 0.24);
}
"#;

const DISCORD_COLORS: &str = r#"
@define-color rs_bg #17181c;
@define-color rs_bg2 #1b1c21;
@define-color rs_surface #232428;
@define-color rs_sidebar #1c1d21;
@define-color rs_entry #111214;
@define-color rs_text #f2f3f5;
@define-color rs_border rgba(255, 255, 255, 0.09);
@define-color rs_accent #5865f2;
@define-color rs_accent2 #8b5cf6;
@define-color rs_accent_text #f8faff;
@define-color rs_danger #ed4245;
@define-color rs_on_danger #ffffff;
@define-color rs_shadow #000000;
"#;

const TRANSPARENT_COLORS: &str = r#"
@define-color rs_bg transparent;
@define-color rs_bg2 transparent;
@define-color rs_surface rgba(255, 255, 255, 0.62);
@define-color rs_sidebar rgba(255, 255, 255, 0.42);
@define-color rs_entry rgba(255, 255, 255, 0.78);
@define-color rs_text #14141a;
@define-color rs_border rgba(0, 0, 0, 0.14);
@define-color rs_accent #000000;
@define-color rs_accent2 #2a2a2a;
@define-color rs_accent_text #ffffff;
@define-color rs_danger #dc2626;
@define-color rs_on_danger #ffffff;
@define-color rs_shadow #000000;
"#;

// the transparent theme paints the client area itself so the toplevel stays
// fully transparent; appended after the shared sheet so it wins the cascade
const TRANSPARENT_EXTRA: &str = r#"
window, .background { background-color: transparent; }
.rustify-main { background-color: rgba(255, 255, 255, 0.70); background-image: none; }
headerbar { background-color: rgba(255, 255, 255, 0.70); }
/* icons that pick up the purple accent elsewhere stay black on the light theme */
.rustify-nav image, .rustify-nav:hover image,
.rustify-repeat image, .rustify-repeat:checked image,
.rustify-chevron, .rustify-result-row:hover .rustify-chevron {
    color: #000000;
}
"#;

const COMMON_CSS: &str = r#"
/* Rustify shared structural sheet. Palettes supply the @rs_* colours. */
@define-color placeholder_text_color alpha(@rs_text, 0.55);
* { transition: none; font-family: "Inter"; }

window, .background {
    background-color: @rs_bg;
    color: @rs_text;
    font-size: 10.5pt;
}

.rustify-main {
    background-color: @rs_bg;
    background-image: radial-gradient(circle at 6% -14%, alpha(@rs_accent, 0.18), transparent 46%),
                      radial-gradient(circle at 104% 114%, alpha(@rs_accent2, 0.14), transparent 48%);
    /* the content box reaches the window edge, so it has to carry the bottom
       rounding itself; GTK does not clip children to the decoration radius */
    border-bottom-right-radius: 12px;
}

.rustify-hero {
    background-image: radial-gradient(circle at 50% 34%, alpha(@rs_accent, 0.16), transparent 58%);
}

/* no rounding when the window is not floating */
window.maximized .rustify-main, window.maximized .rustify-sidebar,
window.tiled .rustify-main, window.tiled .rustify-sidebar,
window.fullscreen .rustify-main, window.fullscreen .rustify-sidebar {
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
}

headerbar {
    min-height: 46px;
    padding: 0 10px;
    background-image: none;
    background-color: alpha(@rs_bg, 0.72);
    color: @rs_text;
    border-bottom: 1px solid @rs_border;
    box-shadow: none;
}

headerbar .title, headerbar .subtitle { color: @rs_text; }

headerbar button {
    background-image: none;
    background-color: alpha(@rs_text, 0.05);
    color: @rs_text;
    border: 1px solid @rs_border;
    border-radius: 12px;
    box-shadow: none;
    padding: 4px 10px;
    min-height: 24px;
    font-weight: bold;
}

headerbar button:hover { background-color: alpha(@rs_text, 0.11); }
headerbar button:active { background-color: alpha(@rs_text, 0.16); }

headerbar button.titlebutton {
    background-color: transparent;
    border-color: transparent;
    padding: 2px;
}

.rustify-title { font-size: 11pt; font-weight: bold; }
.rustify-dot {
    min-width: 9px;
    min-height: 9px;
    border-radius: 99px;
    background-image: linear-gradient(135deg, @rs_accent, @rs_accent2);
    box-shadow: 0 0 10px alpha(@rs_accent, 0.55);
}

button {
    background-image: none;
    background-color: alpha(@rs_text, 0.05);
    color: @rs_text;
    border: 1px solid @rs_border;
    border-radius: 12px;
    box-shadow: none;
    text-shadow: none;
    padding: 7px 14px;
    font-weight: bold;
}

button:hover { background-color: alpha(@rs_text, 0.10); }

button:active, button:checked {
    background-color: alpha(@rs_accent, 0.20);
    border-color: alpha(@rs_accent, 0.45);
}

button.flat {
    background-color: transparent;
    border-color: transparent;
    box-shadow: none;
}

button.flat:hover { background-color: alpha(@rs_text, 0.07); }

button.suggested-action {
    background-image: linear-gradient(135deg, @rs_accent, @rs_accent2);
    background-color: @rs_accent;
    color: @rs_accent_text;
    border-color: transparent;
    box-shadow: 0 10px 24px alpha(@rs_accent, 0.30);
}

button.suggested-action:hover {
    background-image: linear-gradient(135deg, shade(@rs_accent, 1.10), shade(@rs_accent2, 1.10));
}

button.suggested-action image { color: @rs_accent_text; }

button.rustify-login {
    background-image: none;
    background-color: @rs_accent;
}

button.rustify-login:hover {
    background-image: none;
    background-color: shade(@rs_accent, 1.10);
}

button.destructive-action {
    background-image: linear-gradient(135deg, @rs_danger, shade(@rs_danger, 0.82));
    background-color: @rs_danger;
    color: @rs_on_danger;
    border-color: transparent;
    font-weight: bold;
}

button.destructive-action:hover {
    background-image: linear-gradient(135deg, shade(@rs_danger, 1.06), shade(@rs_danger, 0.90));
}

entry, searchentry, spinbutton {
    background-image: none;
    background-color: alpha(@rs_entry, 0.95);
    color: @rs_text;
    border: 1px solid @rs_border;
    border-radius: 14px;
    box-shadow: none;
    padding: 8px 12px;
}

entry:focus, searchentry:focus {
    border-color: alpha(@rs_accent, 0.65);
    box-shadow: 0 0 0 3px alpha(@rs_accent, 0.16);
}

entry selection, searchentry selection {
    background-color: alpha(@rs_accent, 0.35);
    color: @rs_text;
}

entry image, searchentry image { color: alpha(@rs_text, 0.55); }

.rustify-search { padding: 12px 16px 6px 16px; }
.rustify-search searchentry { min-height: 32px; }

.rustify-hero-search {
    min-height: 30px;
    padding: 10px 18px;
    border-radius: 99px;
    font-size: 11pt;
}

.rustify-pill {
    background-color: alpha(@rs_text, 0.06);
    border: 1px solid @rs_border;
    border-radius: 99px;
    padding: 5px 14px;
    color: alpha(@rs_text, 0.65);
    font-size: 8.5pt;
    font-weight: bold;
}

scale trough {
    background-color: alpha(@rs_text, 0.12);
    border: none;
    border-radius: 99px;
    min-height: 6px;
}

scale highlight {
    background-image: linear-gradient(to right, @rs_accent, @rs_accent2);
    background-color: @rs_accent;
    border-radius: 99px;
}

scale slider {
    background-color: @rs_text;
    border: 2px solid @rs_accent;
    border-radius: 99px;
    box-shadow: 0 2px 6px alpha(@rs_shadow, 0.40);
    min-width: 12px;
    min-height: 12px;
}

scale:hover slider { border-color: @rs_accent2; }

levelbar trough {
    background-color: alpha(@rs_text, 0.10);
    border-radius: 99px;
    min-height: 8px;
}

levelbar block { border-radius: 99px; }

levelbar block.filled {
    background-image: none;
    background-color: @rs_accent;
    border: none;
}

switch {
    background-color: alpha(@rs_text, 0.12);
    border: 1px solid @rs_border;
    border-radius: 99px;
    min-width: 46px;
    min-height: 24px;
}

switch:checked {
    background-image: linear-gradient(135deg, @rs_accent, @rs_accent2);
    background-color: @rs_accent;
    border-color: transparent;
}

switch slider {
    background-color: #ffffff;
    border: none;
    border-radius: 99px;
    box-shadow: 0 1px 3px alpha(@rs_shadow, 0.45);
    min-width: 20px;
    min-height: 20px;
}

check, radio {
    background-color: @rs_entry;
    border: 1px solid @rs_border;
    border-radius: 6px;
    min-width: 16px;
    min-height: 16px;
}

radio { border-radius: 99px; }

check:checked, radio:checked {
    background-image: linear-gradient(135deg, @rs_accent, @rs_accent2);
    background-color: @rs_accent;
    border-color: transparent;
}

list, listbox { background-color: transparent; color: @rs_text; }

listbox row { background-color: transparent; border-radius: 16px; }

listbox row:hover, row:hover { background-color: alpha(@rs_accent, 0.07); }

listbox row:selected {
    background-color: alpha(@rs_accent, 0.16);
    border-color: alpha(@rs_accent, 0.26);
}

.rustify-result-row {
    margin: 3px 12px;
    border: 1px solid transparent;
    border-radius: 16px;
}

.rustify-result-row:hover {
    background-color: alpha(@rs_accent, 0.09);
    border-color: alpha(@rs_accent, 0.20);
}

.rustify-index { font-size: 8.5pt; color: alpha(@rs_text, 0.35); }

.rustify-result-row:hover .rustify-index { color: alpha(@rs_accent, 0.85); }

.rustify-chip {
    background-color: alpha(@rs_text, 0.06);
    border: 1px solid @rs_border;
    border-radius: 99px;
    padding: 3px 9px;
    color: alpha(@rs_text, 0.55);
}

.rustify-chevron { font-size: 14pt; color: alpha(@rs_text, 0.35); }

.rustify-result-row:hover .rustify-chevron { color: @rs_accent; }

separator {
    background-color: @rs_border;
    min-height: 1px;
}

label { color: @rs_text; }

scrolledwindow { background-color: transparent; }

scrollbar { background-color: transparent; border: none; }

scrollbar slider {
    background-color: alpha(@rs_text, 0.16);
    border-radius: 99px;
    min-width: 6px;
    min-height: 30px;
}

scrollbar slider:hover { background-color: alpha(@rs_text, 0.28); }

.rustify-sidebar {
    background-color: @rs_sidebar;
    background-image: linear-gradient(180deg, alpha(@rs_accent, 0.07), transparent 38%);
    border-right: 1px solid @rs_border;
    padding: 4px;
    /* match the window's rounded bottom-left corner */
    border-bottom-left-radius: 12px;
}

/* compact rail: icons only */
.rustify-sidebar-compact .rustify-brand { padding: 12px 8px 10px 8px; }
.rustify-sidebar-compact .rustify-navbox { padding: 4px 6px; }
.rustify-sidebar-compact .rustify-nav { padding: 9px 0; }

.rustify-brand { padding: 16px 14px 10px 14px; }

.rustify-brand-mark {
    min-width: 36px;
    min-height: 36px;
    border-radius: 12px;
    background-image: none;
    background-color: @rs_accent;
    color: @rs_accent_text;
    box-shadow: 0 8px 20px alpha(@rs_accent, 0.30);
}

.rustify-brand-mark image { color: @rs_accent_text; }

.rustify-brand-name { font-size: 12pt; font-weight: bold; }
.rustify-brand-sub { font-size: 8pt; color: alpha(@rs_text, 0.45); }

.rustify-navbox { padding: 4px 8px; }

.rustify-nav {
    min-height: 26px;
    padding: 9px 12px;
    border-radius: 14px;
    background-color: transparent;
    border: 1px solid transparent;
    box-shadow: none;
    color: @rs_text;
}

.rustify-nav image { color: alpha(@rs_text, 0.72); }

.rustify-nav:hover {
    background-color: alpha(@rs_accent, 0.12);
    border-color: alpha(@rs_accent, 0.22);
}

.rustify-nav:hover image { color: @rs_accent; }

.rustify-nav:active, .rustify-nav:checked {
    background-image: linear-gradient(to right, alpha(@rs_accent, 0.26), alpha(@rs_accent2, 0.18));
    border-color: alpha(@rs_accent, 0.30);
}

.rustify-sidefooter { padding: 6px 8px 10px 8px; }

.rustify-meter {
    background-color: alpha(@rs_surface, 0.75);
    border: 1px solid @rs_border;
    border-radius: 16px;
    padding: 10px 12px;
}

.rustify-player {
    margin: 6px 14px 14px 14px;
    padding: 12px 18px 4px 18px;
    border-radius: 22px;
    background-color: alpha(@rs_surface, 0.92);
    border: 1px solid @rs_border;
    box-shadow: 0 14px 40px alpha(@rs_shadow, 0.35);
}

/* minimized player: a single compact bar */
.rustify-player-mini { padding: 6px 12px 6px 12px; }

/* plain fill bar that replaces the player while a song is downloading */
.rustify-player-downloading { padding: 6px 12px; }
.rustify-dlbar trough {
    min-height: 10px;
    border: none;
    border-radius: 999px;
    background-color: alpha(@rs_text, 0.10);
}
.rustify-dlbar progress {
    min-height: 10px;
    border-radius: 999px;
    background-image: none;
    background-color: @rs_accent;
}

.rustify-np-minimize {
    min-width: 26px;
    min-height: 26px;
    padding: 0;
    border-radius: 99px;
    background-color: alpha(@rs_text, 0.05);
}

.rustify-np-minimize:hover { background-color: alpha(@rs_text, 0.12); }

.rustify-cancel {
    min-width: 26px;
    min-height: 26px;
    padding: 0;
    border-radius: 99px;
    background-color: alpha(@rs_text, 0.05);
}

.rustify-cancel:hover { background-color: alpha(@rs_text, 0.12); }

.rustify-np-title { font-size: 12pt; font-weight: bold; }
.rustify-np-artist { font-size: 9.5pt; color: alpha(@rs_text, 0.55); }
.rustify-time { font-size: 8.5pt; color: alpha(@rs_text, 0.50); }
.rustify-status { font-size: 8.5pt; color: alpha(@rs_text, 0.40); padding: 0 20px 8px 20px; }

.rustify-transport {
    min-width: 40px;
    min-height: 40px;
    padding: 0;
    border-radius: 99px;
    background-color: alpha(@rs_text, 0.05);
}

.rustify-transport:hover { background-color: alpha(@rs_text, 0.12); }

.rustify-repeat image { color: alpha(@rs_text, 0.72); }

.rustify-repeat:checked {
    background-color: alpha(@rs_accent, 0.22);
    border-color: alpha(@rs_accent, 0.55);
}

.rustify-repeat:checked image { color: @rs_accent; }

.rustify-play {
    min-width: 58px;
    min-height: 58px;
    padding: 0;
    border-radius: 99px;
    background-image: none;
    background-color: @rs_accent;
    color: @rs_accent_text;
    border-color: transparent;
    box-shadow: 0 12px 30px alpha(@rs_accent, 0.40);
}

.rustify-play image { color: @rs_accent_text; }

.rustify-play:hover {
    background-image: none;
    background-color: shade(@rs_accent, 1.08);
}

.rustify-settings-body {
    background-color: alpha(@rs_surface, 0.55);
    border: 1px solid @rs_border;
    border-radius: 20px;
    padding: 18px 20px;
}

.rustify-lyrics-body {
    background-color: alpha(@rs_surface, 0.55);
    border: 1px solid @rs_border;
    border-radius: 20px;
    padding: 30px 34px;
}

.rustify-lyrics {
    font-size: 22pt;
    font-weight: bold;
    color: @rs_text;
}

.rustify-lyric-line {
    font-size: 22pt;
    font-weight: bold;
    color: alpha(@rs_text, 0.38);
}

.rustify-lyric-line.active {
    color: @rs_text;
}

.rustify-miniplayer { background-color: @rs_bg; }
.rustify-miniplayer-lyric { font-size: 16pt; font-weight: bold; color: @rs_text; }
.rustify-miniplayer-next { font-size: 10.5pt; color: alpha(@rs_text, 0.40); }
.rustify-miniplayer-play {
    min-width: 46px;
    min-height: 46px;
    padding: 0;
    border-radius: 99px;
    background-image: none;
    background-color: @rs_accent;
    color: @rs_accent_text;
    border-color: transparent;
}
.rustify-miniplayer-play image { color: @rs_accent_text; }
.rustify-miniplayer-play:hover { background-image: none; background-color: shade(@rs_accent, 1.08); }

.rustify-gate {
    background-color: alpha(@rs_surface, 0.55);
    border: 1px solid @rs_border;
    border-radius: 22px;
    padding: 30px 38px;
    box-shadow: 0 18px 50px alpha(@rs_shadow, 0.30);
}

.rustify-home { background-color: transparent; }

.rustify-recent-card {
    background-color: alpha(@rs_surface, 0.70);
    border: 1px solid @rs_border;
    border-radius: 16px;
    padding: 10px;
}

.rustify-recent-card:hover {
    background-color: alpha(@rs_accent, 0.16);
    border-color: alpha(@rs_accent, 0.45);
}

.rustify-cover { border-radius: 10px; }

.rustify-cover-empty { color: alpha(@rs_text, 0.35); }

.rustify-flow-arrow {
    min-width: 40px;
    min-height: 40px;
    padding: 0;
    border: none;
    box-shadow: none;
    background-image: none;
    background-color: transparent;
}

.rustify-flow-arrow:hover,
.rustify-flow-arrow:active,
.rustify-flow-arrow:focus {
    border: none;
    box-shadow: none;
    background-image: none;
    background-color: transparent;
}

.rustify-flow-arrow image { color: alpha(@rs_text, 0.78); }

.rustify-flow-arrow:hover image { color: @rs_accent; }

.rustify-flow-arrow:disabled { opacity: 0.35; }

paned > separator {
    background-color: transparent;
    min-width: 0px;
    min-height: 0px;
}

.rustify-quiet-scrim {
    background-color: alpha(@rs_shadow, 0.45);
}

.rustify-quiet-sheet {
    background-color: @rs_surface;
    border-left: 2px solid alpha(@rs_text, 0.18);
    box-shadow: -24px 0 48px alpha(@rs_shadow, 0.40);
}

.rustify-quiet-progress {
    min-height: 4px;
    min-width: 320px;
}

.rustify-quiet-progress trough {
    min-height: 4px;
    border-radius: 99px;
    background-color: alpha(@rs_text, 0.14);
}

.rustify-quiet-progress progress {
    min-height: 4px;
    border-radius: 99px;
    background-color: @rs_accent;
}
"#;

// OG GUI: a classic, square, flat desktop skin layered over the slate palette.
// It strips every radius, gradient and drop shadow so the interface looks like
// a plain beveled GTK window instead of the modern rounded shell.
const OG_SLATE_EXTRA: &str = r#"
window.background, window.background * {
    border-radius: 0;
    font-family: sans-serif;
}
.rustify-main { background-image: none; background-color: @rs_bg; }
.rustify-hero { background-image: none; background-color: transparent; }
.rustify-dot {
    background-image: none;
    background-color: @rs_accent;
    box-shadow: none;
}
headerbar {
    background-image: none;
    background-color: @rs_sidebar;
    box-shadow: none;
}
button, headerbar button {
    background-image: none;
    background-color: alpha(@rs_text, 0.08);
    border: 1px solid alpha(@rs_text, 0.30);
    border-bottom-color: alpha(@rs_shadow, 0.95);
    border-right-color: alpha(@rs_shadow, 0.95);
    box-shadow: none;
}
button:hover, headerbar button:hover { background-color: alpha(@rs_text, 0.14); }
button:active, button:checked, headerbar button:active {
    background-color: alpha(@rs_shadow, 0.55);
    border-color: alpha(@rs_shadow, 0.95);
}
button.flat { background-color: transparent; border-color: transparent; }
button.suggested-action {
    background-image: none;
    background-color: @rs_accent;
    border-color: @rs_accent2;
    box-shadow: none;
}
button.destructive-action {
    background-image: none;
    background-color: @rs_danger;
    border-color: shade(@rs_danger, 0.70);
}
entry, searchentry, spinbutton {
    background-image: none;
    background-color: @rs_entry;
    border: 1px solid alpha(@rs_shadow, 0.95);
    box-shadow: none;
}
entry:focus, searchentry:focus {
    border-color: @rs_accent;
    box-shadow: none;
}
.rustify-hero-search, .rustify-pill, .rustify-chip { background-image: none; }
scale trough, levelbar trough {
    background-image: none;
    border: 1px solid @rs_border;
}
scale highlight, levelbar block.filled {
    background-image: none;
    background-color: @rs_accent;
}
scale slider {
    background-image: none;
    background-color: alpha(@rs_text, 0.85);
    border: 1px solid @rs_shadow;
    box-shadow: none;
}
switch { background-image: none; }
switch:checked {
    background-image: none;
    background-color: @rs_accent;
    border-color: @rs_accent2;
}
switch slider { background-image: none; box-shadow: none; }
check:checked, radio:checked {
    background-image: none;
    background-color: @rs_accent;
    border-color: @rs_accent2;
}
listbox row, .rustify-result-row { background-image: none; }
listbox row:hover, .rustify-result-row:hover { background-color: alpha(@rs_accent, 0.16); }
listbox row:selected, .rustify-result-row:selected { background-color: alpha(@rs_accent, 0.30); }
scrollbar slider { background-image: none; }
.rustify-sidebar {
    background-image: none;
    background-color: @rs_sidebar;
}
.rustify-brand-mark {
    background-image: none;
    background-color: @rs_accent;
    box-shadow: none;
}
.rustify-nav:active, .rustify-nav:checked {
    background-image: none;
    background-color: alpha(@rs_accent, 0.30);
}
.rustify-transport { background-image: none; }
.rustify-play {
    background-image: none;
    background-color: @rs_accent;
    border-color: @rs_accent2;
    box-shadow: none;
}
.rustify-play:hover { background-image: none; background-color: shade(@rs_accent, 1.12); }
.rustify-meter, .rustify-settings-body, .rustify-gate, .rustify-player {
    background-image: none;
    box-shadow: none;
}
"#;

fn theme_css_og(name: &str, og: bool) -> String {
    // OG GUI wins over the selected theme: same slate palette, old skin.
    if og {
        return format!("{SLATE_COLORS}\n{COMMON_CSS}\n{OG_SLATE_EXTRA}");
    }
    let (colors, extra) = match name {
        "mint" => (MINT_COLORS, ""),
        "light" => (LIGHT_COLORS, LIGHT_EXTRA),
        "discord" => (DISCORD_COLORS, ""),
        "transparent" => (TRANSPARENT_COLORS, TRANSPARENT_EXTRA),
        "slate" => (SLATE_COLORS, ""),
        "rustify" => (RUSTIFY_COLORS, ""),
        _ => return custom_theme_css(name),
    };
    format!("{colors}\n{COMMON_CSS}\n{extra}")
}

// ------------------------------------------------------- custom theme codes
//
// The code language is a colon-separated list of selections. Each selection is
// a number (1 = background, 2 = all buttons) followed by a colour, written as
// its first letter (r = red, b = blue). Colours that share a first letter use
// one or more '-' or '!' prefixes for the later entries, so `-b` and `!b` are
// black while `b` is blue. Full names ("black") also work.
// Example: `1R:2!B` is a red background with black buttons.

const COLOR_TABLE: &[(&str, &str)] = &[
    ("blue", "#3b82f6"),
    ("black", "#000000"),
    ("brown", "#8b5a2b"),
    ("red", "#ef4444"),
    ("rose", "#f43f5e"),
    ("green", "#22c55e"),
    ("gray", "#9ca3af"),
    ("grey", "#9ca3af"),
    ("purple", "#a855f7"),
    ("pink", "#ec4899"),
    ("magenta", "#d946ef"),
    ("maroon", "#800000"),
    ("orange", "#f97316"),
    ("yellow", "#facc15"),
    ("white", "#ffffff"),
    ("cyan", "#06b6d4"),
    ("teal", "#14b8a6"),
    ("lime", "#84cc16"),
    ("navy", "#1e3a8a"),
    ("indigo", "#6366f1"),
    ("violet", "#8b5cf6"),
    ("amber", "#f59e0b"),
    ("silver", "#c0c0c0"),
];

static CUSTOM_THEME_CODES: OnceLock<Mutex<HashMap<String, String>>> = OnceLock::new();

fn custom_theme_codes() -> &'static Mutex<HashMap<String, String>> {
    CUSTOM_THEME_CODES.get_or_init(|| Mutex::new(HashMap::new()))
}

fn register_custom_theme(name: &str, code: &str) {
    if let Ok(mut map) = custom_theme_codes().lock() {
        map.insert(name.to_string(), code.to_string());
    }
}

fn hex_rgb(hex: &str) -> Option<(u8, u8, u8)> {
    let h = hex.strip_prefix('#')?;
    if h.len() != 6 {
        return None;
    }
    let r = u8::from_str_radix(&h[0..2], 16).ok()?;
    let g = u8::from_str_radix(&h[2..4], 16).ok()?;
    let b = u8::from_str_radix(&h[4..6], 16).ok()?;
    Some((r, g, b))
}

fn rgb_hex((r, g, b): (u8, u8, u8)) -> String {
    format!("#{r:02x}{g:02x}{b:02x}")
}

// Multiply each channel; used to derive sidebar/entry/hover shades.
fn scale_rgb((r, g, b): (u8, u8, u8), factor: f64) -> (u8, u8, u8) {
    let f = |c: u8| (c as f64 * factor).round().clamp(0.0, 255.0) as u8;
    (f(r), f(g), f(b))
}

fn luminance((r, g, b): (u8, u8, u8)) -> f64 {
    (0.299 * r as f64 + 0.587 * g as f64 + 0.114 * b as f64) / 255.0
}

fn contrast_text(rgb: (u8, u8, u8)) -> (u8, u8, u8) {
    if luminance(rgb) > 0.55 {
        (18, 18, 22)
    } else {
        (246, 241, 255)
    }
}

fn resolve_color(spec: &str) -> Option<(u8, u8, u8)> {
    let mut alt = 0usize;
    let mut rest = spec.trim();
    while let Some(c) = rest.chars().next() {
        if c == '-' || c == '!' {
            alt += 1;
            rest = &rest[c.len_utf8()..];
        } else {
            break;
        }
    }
    let rest = rest.trim();
    if rest.is_empty() {
        return None;
    }
    // an explicit full name sidesteps first-letter collisions
    if let Some((_, hex)) = COLOR_TABLE
        .iter()
        .find(|(name, _)| name.eq_ignore_ascii_case(rest))
    {
        return hex_rgb(hex);
    }
    let letter = rest.chars().next()?.to_ascii_uppercase();
    let matches: Vec<&str> = COLOR_TABLE
        .iter()
        .filter(|(name, _)| {
            name.chars()
                .next()
                .map(|c| c.to_ascii_uppercase() == letter)
                .unwrap_or(false)
        })
        .map(|(_, hex)| *hex)
        .collect();
    matches.get(alt).and_then(|hex| hex_rgb(hex))
}

fn average_color(stops: &[(u8, u8, u8)], fallback: (u8, u8, u8)) -> (u8, u8, u8) {
    if stops.is_empty() {
        return fallback;
    }
    let n = stops.len() as u32;
    let mut r = 0u32;
    let mut g = 0u32;
    let mut b = 0u32;
    for (sr, sg, sb) in stops {
        r += *sr as u32;
        g += *sg as u32;
        b += *sb as u32;
    }
    ((r / n) as u8, (g / n) as u8, (b / n) as u8)
}

// `to bottom` means the first stop is the top edge and the last is the bottom.
// A single stop is still a valid one-stop gradient, so callers can use this for
// solid colours too.
fn gradient_css(stops: &[(u8, u8, u8)], factor: f64) -> String {
    let fallback = [(13, 9, 22)];
    let source: &[(u8, u8, u8)] = if stops.is_empty() { &fallback } else { stops };
    let mut list: Vec<String> = source
        .iter()
        .map(|c| rgb_hex(scale_rgb(*c, factor)))
        .collect();
    // GTK wants at least two colour stops; duplicate a solid colour
    if list.len() == 1 {
        list.push(list[0].clone());
    }
    format!("linear-gradient(to bottom, {})", list.join(", "))
}

// Each token is `<selector><colour>`. Repeating a selector adds another
// gradient stop; a missing colour invalidates the whole code, so every letter
// really is coloured.
fn parse_theme_code(code: &str) -> Option<(Vec<(u8, u8, u8)>, Vec<(u8, u8, u8)>)> {
    let mut bg: Vec<(u8, u8, u8)> = Vec::new();
    let mut btn: Vec<(u8, u8, u8)> = Vec::new();
    let mut any = false;
    for token in code.split(':') {
        let token = token.trim();
        if token.is_empty() {
            continue;
        }
        let selector = token.chars().next()?;
        let rgb = resolve_color(&token[selector.len_utf8()..])?;
        match selector {
            '1' => bg.push(rgb),
            '2' => btn.push(rgb),
            _ => return None,
        }
        any = true;
    }
    if !any {
        return None;
    }
    Some((bg, btn))
}

fn build_custom_palette(code: &str) -> Option<(String, String)> {
    let (bg_stops, btn_stops) = parse_theme_code(code)?;
    let bg = bg_stops.first().copied().unwrap_or((13, 9, 22));
    let bg_avg = average_color(&bg_stops, bg);
    let accent = btn_stops
        .first()
        .copied()
        .unwrap_or_else(|| hex_rgb("#a855f7").unwrap());
    let accent_avg = average_color(&btn_stops, accent);

    let text = contrast_text(bg_avg);
    let text_hex = rgb_hex(text);
    let border = if luminance(text) > 0.5 {
        "rgba(255, 255, 255, 0.10)"
    } else {
        "rgba(0, 0, 0, 0.12)"
    };
    let bg_hex = rgb_hex(bg);
    let bg2_hex = rgb_hex(scale_rgb(bg, 1.16));
    let surface_hex = rgb_hex(scale_rgb(bg, 1.32));
    let sidebar_hex = rgb_hex(scale_rgb(bg, 0.86));
    let entry_hex = rgb_hex(scale_rgb(bg, 0.74));
    let accent_hex = rgb_hex(accent);
    let accent2 = if btn_stops.len() > 1 {
        btn_stops[btn_stops.len() - 1]
    } else {
        scale_rgb(accent, 1.18)
    };
    let accent2_hex = rgb_hex(accent2);
    let accent_text = rgb_hex(contrast_text(accent_avg));
    let shadow_hex = rgb_hex(scale_rgb(bg, 0.40));

    let palette = format!(
        "@define-color rs_bg {bg_hex};\n\
         @define-color rs_bg2 {bg2_hex};\n\
         @define-color rs_surface {surface_hex};\n\
         @define-color rs_sidebar {sidebar_hex};\n\
         @define-color rs_entry {entry_hex};\n\
         @define-color rs_text {text_hex};\n\
         @define-color rs_border {border};\n\
         @define-color rs_accent {accent_hex};\n\
         @define-color rs_accent2 {accent2_hex};\n\
         @define-color rs_accent_text {accent_text};\n\
         @define-color rs_danger #ef4444;\n\
         @define-color rs_on_danger #ffffff;\n\
         @define-color rs_shadow {shadow_hex};\n"
    );

    // the main surfaces get the real multi-stop gradient; one stop keeps the
    // shared sheet's radial accent glows
    let bg_extra = if bg_stops.len() > 1 {
        let image = gradient_css(&bg_stops, 1.0);
        format!(
            "window, .background {{\n\
                 background-image: {image};\n\
                 background-color: {bg_hex};\n\
             }}\n\
             .rustify-main {{\n\
                 background-image: {image};\n\
                 background-color: {bg_hex};\n\
             }}\n"
        )
    } else {
        String::new()
    };

    // every button follows the button stop list, solid when there is one stop
    let button_extra = if btn_stops.is_empty() {
        String::new()
    } else {
        let normal = gradient_css(&btn_stops, 1.0);
        let hover = gradient_css(&btn_stops, 1.10);
        let active = gradient_css(&btn_stops, 0.88);
        format!(
            "button, headerbar button {{\n\
                 background-image: {normal};\n\
                 background-color: {accent_hex};\n\
                 color: {accent_text};\n\
                 border-color: {border};\n\
                 text-shadow: none;\n\
             }}\n\
             button:hover, headerbar button:hover {{\n\
                 background-image: {hover}; background-color: {accent_hex};\n\
             }}\n\
             button:active, button:checked, headerbar button:active {{\n\
                 background-image: {active}; background-color: {accent_hex};\n\
                 border-color: {border};\n\
             }}\n\
             button.flat {{\n\
                 background-image: {normal}; background-color: {accent_hex};\n\
                 color: {accent_text}; border-color: {border};\n\
             }}\n\
             button.flat:hover {{ background-image: {hover}; }}\n\
             button.suggested-action, button.rustify-login, .rustify-play, .rustify-brand-mark {{\n\
                 background-image: {normal}; background-color: {accent_hex};\n\
                 color: {accent_text}; border-color: {border};\n\
             }}\n\
             button.suggested-action:hover, button.rustify-login:hover, .rustify-play:hover {{\n\
                 background-image: {hover};\n\
             }}\n"
        )
    };

    Some((palette, format!("{bg_extra}{button_extra}")))
}

fn custom_theme_css(name: &str) -> String {
    let code = custom_theme_codes()
        .lock()
        .ok()
        .and_then(|map| map.get(name).cloned());
    match code.and_then(|code| build_custom_palette(&code)) {
        Some((palette, extra)) => format!("{palette}\n{COMMON_CSS}\n{extra}"),
        None => format!("{RUSTIFY_COLORS}\n{COMMON_CSS}"),
    }
}

// GTK3's CSS parser rejects hsl(), so convert to #rrggbb before emitting.
fn hsl_hex(h: f64, s: f64, l: f64) -> String {
    let s = (s / 100.0).clamp(0.0, 1.0);
    let l = (l / 100.0).clamp(0.0, 1.0);
    let c = (1.0 - (2.0 * l - 1.0).abs()) * s;
    let hp = h.rem_euclid(360.0) / 60.0;
    let x = c * (1.0 - (hp % 2.0 - 1.0).abs());
    let (r1, g1, b1) = match hp as i32 {
        0 => (c, x, 0.0),
        1 => (x, c, 0.0),
        2 => (0.0, c, x),
        3 => (0.0, x, c),
        4 => (x, 0.0, c),
        _ => (c, 0.0, x),
    };
    let m = l - c / 2.0;
    let r = ((r1 + m) * 255.0).round().clamp(0.0, 255.0) as u8;
    let g = ((g1 + m) * 255.0).round().clamp(0.0, 255.0) as u8;
    let b = ((b1 + m) * 255.0).round().clamp(0.0, 255.0) as u8;
    format!("#{r:02x}{g:02x}{b:02x}")
}

// "didy" easter egg stylesheet: the app's own surfaces get a rainbow gradient
// whose hue keeps rotating. It targets Rustify's classes instead of "*" so it
// stays inside this app, leaves labels readable, and does not repaint every
// other GTK window on the screen. Reloaded a few dozen times a second.
fn rainbow_sheet(t: f64) -> String {
    let h = (t * 1440.0) % 360.0;
    let h2 = (h + 120.0) % 360.0;
    let h3 = (h + 240.0) % 360.0;
    let c1 = hsl_hex(h, 100.0, 62.0);
    let c2 = hsl_hex(h2, 100.0, 54.0);
    let c3 = hsl_hex(h3, 100.0, 62.0);
    format!(
        ".rustify-main, .rustify-hero, .rustify-sidebar, .rustify-navbox, .rustify-nav,\n\
         .rustify-player, .rustify-meter, .rustify-gate, .rustify-settings-body,\n\
         .rustify-result-row, .rustify-brand, .rustify-brand-mark, .rustify-play,\n\
         .rustify-transport, .rustify-chip, .rustify-pill, .rustify-hero-search {{\n\
            background-image: linear-gradient(135deg, {c1}, {c2}, {c3});\n\
            background-color: transparent;\n\
            border-color: rgba(0, 0, 0, 0.32);\n\
            box-shadow: none;\n\
        }}\n\
        .rustify-hero-search, entry.rustify-hero-search {{\n\
            background-image: linear-gradient(135deg, {c2}, {c3});\n\
        }}\n"
    )
}

// Tux, the Linux mascot, embedded so the top-left mark works regardless of
// which icon theme the desktop is using.
const TUX_SVG: &str = include_str!("../tux.svg");

// The desktop theme has no "file with an up arrow", so this one is drawn here
// and dropped into the user's icon theme. Everything is a filled shape because
// GTK's symbolic recolouring tints fills but leaves strokes at their original
// dark colour, which made the outline invisible on the dark sidebar.
const FILE_UPLOAD_ICON_NAME: &str = "rustify-import-file-symbolic";

const FILE_UPLOAD_ICON_SVG: &str = r##"<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
  <g fill="#2e3436" transform="translate(-0.24 -0.24) scale(1.03)">
    <path d="M4.1 0.75 H9.5 L14.5 5.75 V12.65 A2.6 2.6 0 0 1 11.9 15.25 H4.1 A2.6 2.6 0 0 1 1.5 12.65 V3.35 A2.6 2.6 0 0 1 4.1 0.75 Z M4.1 13.25 H11.9 A0.6 0.6 0 0 0 12.5 12.65 V6.578 L8.672 2.75 H4.1 A0.6 0.6 0 0 0 3.5 3.35 V12.65 A0.6 0.6 0 0 0 4.1 13.25 Z"/>
    <path d="M8 5.6 L10.9 9.9 H9.1 V14 H6.9 V9.9 H5.1 Z"/>
  </g>
</svg>
"##;

fn install_symbolic_icons() {
    let root = data_root().join("icons");
    let mut theme_dirs = vec![root.join("hicolor")];
    if let Some(name) = gtk::Settings::default()
        .and_then(|s| s.gtk_icon_theme_name())
        .map(|s| s.to_string())
    {
        if !name.is_empty() && !name.contains('/') && !name.contains('\\') {
            theme_dirs.push(root.join(name));
        }
    }
    for theme_dir in &theme_dirs {
        let actions = theme_dir.join("scalable").join("actions");
        if std::fs::create_dir_all(&actions).is_err() {
            continue;
        }
        let _ = std::fs::write(
            actions.join(format!("{FILE_UPLOAD_ICON_NAME}.svg")),
            FILE_UPLOAD_ICON_SVG,
        );
    }
    // the old name lived in the cache root; drop it so nothing stale is left
    let _ = std::fs::remove_dir_all(cache_root().join("icons"));
    if let Some(screen) = gtk::gdk::Screen::default() {
        if let Some(theme) = gtk::IconTheme::for_screen(&screen) {
            theme.prepend_search_path(&root);
        }
    }
}

fn tux_pixbuf(max: i32) -> Option<gtk::gdk_pixbuf::Pixbuf> {
    use gtk::gdk_pixbuf::prelude::PixbufLoaderExt;
    use gtk::gdk_pixbuf::{InterpType, PixbufLoader};
    let loader = PixbufLoader::new();
    loader.write(TUX_SVG.as_bytes()).ok()?;
    loader.close().ok()?;
    let pix = loader.pixbuf()?;
    let scale = (max as f64 / pix.width() as f64).min(max as f64 / pix.height() as f64);
    let w = ((pix.width() as f64 * scale).round() as i32).max(1);
    let h = ((pix.height() as f64 * scale).round() as i32).max(1);
    pix.scale_simple(w, h, InterpType::Bilinear)
}

// Full desaturation, used so image assets match the monochrome Slate theme.
fn grayscale_pixbuf(pix: &gtk::gdk_pixbuf::Pixbuf) -> Option<gtk::gdk_pixbuf::Pixbuf> {
    let dest = gtk::gdk_pixbuf::Pixbuf::new(
        gtk::gdk_pixbuf::Colorspace::Rgb,
        pix.has_alpha(),
        pix.bits_per_sample(),
        pix.width(),
        pix.height(),
    )?;
    pix.saturate_and_pixelate(&dest, 0.0, false);
    Some(dest)
}

// Hard two-tone version: every pixel is snapped to pure white or pure black by
// Rec. 601 luma, alpha untouched. Used by the transparent theme so the logo is
// white and black only, with no leftover colour from the asset.
fn black_white_pixbuf(pix: &gtk::gdk_pixbuf::Pixbuf) -> Option<gtk::gdk_pixbuf::Pixbuf> {
    let dest = pix.copy()?;
    if dest.bits_per_sample() != 8 {
        return Some(dest);
    }
    let channels = dest.n_channels() as usize;
    if channels < 3 {
        return Some(dest);
    }
    let width = dest.width() as usize;
    let height = dest.height() as usize;
    let rowstride = dest.rowstride() as usize;
    // SAFETY: dest is a private deep copy and nothing else borrows it while the
    // mutable slice is alive; all writes stay inside width/height.
    let data = unsafe { dest.pixels() };
    for y in 0..height {
        for x in 0..width {
            let o = y * rowstride + x * channels;
            if o + 2 >= data.len() {
                continue;
            }
            let luma = 0.299 * data[o] as f64
                + 0.587 * data[o + 1] as f64
                + 0.114 * data[o + 2] as f64;
            let v = if luma >= 128.0 { 255 } else { 0 };
            data[o] = v;
            data[o + 1] = v;
            data[o + 2] = v;
        }
    }
    Some(dest)
}

// "bloated mode": a higher-priority sheet added to the screen only while the
// toggle is on. It re-enables transitions the themes switch off and adds a
// little lift on hover/focus, so every widget reacts with motion.
const BLOAT_CSS: &str = r#"
* {
    transition: all 180ms ease-in-out;
}

button {
    transition: background-color 180ms ease, box-shadow 240ms ease, border-color 180ms ease;
}

button:hover, listbox row:hover, .rustify-nav:hover {
    box-shadow: 0 10px 26px alpha(@rs_accent, 0.30);
}

button:active {
    box-shadow: 0 0 22px alpha(@rs_accent2, 0.45);
}

entry:focus, searchentry:focus {
    box-shadow: 0 0 0 3px alpha(@rs_accent, 0.22), 0 10px 26px alpha(@rs_accent, 0.20);
}

switch slider, scale slider {
    transition: all 240ms ease-in-out;
}

.rustify-play:hover {
    box-shadow: 0 12px 34px alpha(@rs_accent2, 0.48);
}

.rustify-result-row:hover {
    box-shadow: 0 8px 22px alpha(@rs_accent, 0.22);
}
"#;

// ---------------------------------------------------------------- state

#[derive(Clone)]
struct ResultItem {
    id: String,
    title: String,
    artist: String,
    duration_ms: u32,
}

#[derive(Clone)]
struct PlaylistRow {
    id: String,
    title: String,
    count: String,
}

/// Where a list row's play command should read its queue from.
#[derive(Clone, Copy, PartialEq, Eq)]
enum RowSource {
    Results,
    Imports,
}

#[derive(Clone)]
struct LyricLine {
    at_ms: u32,
    text: String,
}

struct UiState {
    status: String,
    title: String,
    artist: String,
    duration_ms: u32,
    pos_ms: u32,
    playing: bool,
    volume: f64,
    results: Arc<Vec<ResultItem>>,
    results_serial: u64,
    playlists: Vec<PlaylistRow>,
    playlists_serial: u64,
    /// mp3 files found in the imports folder, played straight from disk
    imports: Arc<Vec<ResultItem>>,
    imports_serial: u64,
    /// bumped whenever the persisted recently-played list changes
    recent_serial: u64,
    /// worker sets this after opening a playlist so the UI jumps back to the
    /// root view when the tracks land
    show_results_soon: bool,
    /// set after a song is saved to the imports folder so the UI switches to
    /// the imports tab
    show_imports_soon: bool,
    /// set after fifteen taps on the sidebar tux; the UI reveals the hidden
    /// developer section in settings on the next tick
    dev_reveal_soon: bool,
    /// how many search results to ask for
    search_limit: usize,
    /// when true, the "i love windows" easter egg is disabled
    no_easter_eggs: bool,
    /// developer option: search and play without a YouTube Music session
    no_account: bool,
    /// active theme name: rustify, slate, mint, discord or transparent
    theme: String,
    /// last opaque theme; developer-only transparency is never persisted, so
    /// this is what gets written to disk and restored on the next launch
    opaque_theme: String,
    /// frame-rate cap for the render loop
    fps_limit: u64,
    /// extra animations everywhere; persisted like the other settings
    bloated: bool,
    /// classic square GUI, applied when the slate theme is active
    og_gui: bool,
    /// repeat mode: loop the current search track, or the whole playlist
    repeat: bool,
    /// shuffle mode: playlists play in a random order
    shuffle: bool,
    /// audio quality preference: very low, low, medium, high or max
    quality: String,
    /// cap playback at 15% and hide the volume slider
    sensitive_ears: bool,
    /// youtube id of the current track ("" for local files)
    current_id: String,
    /// position the user dragged to while the track was paused or still
    /// loading; applied as soon as the decoder can seek
    seek_to_ms: Option<u32>,
    /// snapshot of the worker queue, published for the quiet-mode list
    queue: Arc<Vec<ResultItem>>,
    queue_cursor: usize,
    queue_serial: u64,
    /// strip the ui down to a queue rail and a big now-playing card
    quiet_mode: bool,
    /// show the slim progress bar under the quiet-mode transport
    quiet_progress: bool,
    /// keep the pointer tilt on the big quiet-mode cover
    quiet_tilt: bool,
    /// plain-text lyrics for the current track, fetched from Genius
    lyrics: String,
    /// time-synced lyrics (LRC) for the current track; empty when only plain
    /// text is available
    lyrics_synced: Arc<Vec<LyricLine>>,
    /// bumped whenever `lyrics` or `lyrics_synced` changes so the UI only
    /// rebuilds the lyric view on new content
    lyrics_serial: u64,
    /// set when the transparent theme is switched on from the search box so the
    /// render loop reloads the stylesheet on the UI thread
    theme_apply_soon: bool,
    /// themes the user added from the settings picker
    custom_themes: Vec<CustomTheme>,
}

impl Default for UiState {
    fn default() -> Self {
        Self {
            status: "Search for something.".into(),
            title: String::new(),
            artist: String::new(),
            duration_ms: 0,
            pos_ms: 0,
            playing: false,
            volume: 70.0,
            results: Arc::new(Vec::new()),
            results_serial: 0,
            playlists: Vec::new(),
            playlists_serial: 0,
            imports: Arc::new(Vec::new()),
            imports_serial: 0,
            recent_serial: 0,
            show_results_soon: false,
            show_imports_soon: false,
            dev_reveal_soon: false,
            search_limit: SEARCH_LIMIT,
            no_easter_eggs: false,
            no_account: false,
            theme: "rustify".to_string(),
            opaque_theme: "rustify".to_string(),
            fps_limit: 240,
            bloated: true,
            og_gui: false,
            repeat: false,
            shuffle: false,
            quality: "medium".to_string(),
            sensitive_ears: false,
            current_id: String::new(),
            seek_to_ms: None,
            queue: Arc::new(Vec::new()),
            queue_cursor: 0,
            queue_serial: 0,
            quiet_mode: false,
            quiet_progress: false,
            quiet_tilt: true,
            lyrics: String::new(),
            lyrics_synced: Arc::new(Vec::new()),
            lyrics_serial: 0,
            theme_apply_soon: false,
            custom_themes: Vec::new(),
        }
    }
}

// A user-defined theme built from the compact code language entered in the
// settings picker. Stored verbatim so edits stay round-trippable.
#[derive(Clone, serde::Serialize, serde::Deserialize)]
struct CustomTheme {
    name: String,
    code: String,
}

// Persisted user settings. Kept in ~/.config/rustify/settings/settings.json;
// the wipe action deletes that whole settings folder alongside the cache and
// session. Developer options (FPS overlay/cap, OG GUI, bloated, no-account,
// memory test) are intentionally runtime-only and never land here. The
// transparent theme is hidden from settings but persists once unlocked by
// searching for it.
#[derive(serde::Serialize, serde::Deserialize)]
#[serde(default)]
struct Config {
    theme: String,
    search_limit: usize,
    no_easter_eggs: bool,
    quality: String,
    sensitive_ears: bool,
    shuffle: bool,
    quiet_mode: bool,
    quiet_progress: bool,
    quiet_tilt: bool,
    custom_themes: Vec<CustomTheme>,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            theme: "rustify".to_string(),
            search_limit: SEARCH_LIMIT,
            no_easter_eggs: false,
            quality: "medium".to_string(),
            sensitive_ears: false,
            shuffle: false,
            quiet_mode: false,
            quiet_progress: false,
            quiet_tilt: true,
            custom_themes: Vec::new(),
        }
    }
}

fn config_path() -> PathBuf {
    if let Ok(dir) = std::env::var("XDG_CONFIG_HOME") {
        PathBuf::from(dir)
            .join("rustify")
            .join("settings")
            .join("settings.json")
    } else if let Ok(home) = std::env::var("HOME") {
        PathBuf::from(home)
            .join(".config")
            .join("rustify")
            .join("settings")
            .join("settings.json")
    } else {
        PathBuf::from("/tmp/rustify")
            .join("settings")
            .join("settings.json")
    }
}

fn load_config() -> Config {
    let mut cfg = std::fs::read_to_string(config_path())
        .ok()
        .and_then(|text| serde_json::from_str::<Config>(&text).ok())
        .unwrap_or_default();
    let custom_known = cfg.custom_themes.iter().any(|t| t.name == cfg.theme);
    if !custom_known
        && !matches!(
            cfg.theme.as_str(),
            "rustify" | "slate" | "mint" | "light" | "discord" | "transparent"
        )
    {
        cfg.theme = "rustify".to_string();
    }
    cfg.search_limit = cfg.search_limit.clamp(1, SEARCH_LIMIT);
    if !QUALITY_IDS.contains(&cfg.quality.as_str()) {
        cfg.quality = "medium".to_string();
    }
    cfg
}

fn save_config(cfg: &Config) {
    let path = config_path();
    if let Some(parent) = path.parent() {
        let _ = std::fs::create_dir_all(parent);
    }
    if let Ok(text) = serde_json::to_string_pretty(cfg) {
        let tmp = path.with_extension("json.tmp");
        if std::fs::write(&tmp, text).is_ok() {
            let _ = std::fs::rename(&tmp, &path);
        }
    }
}

// Recently played tracks, newest first. Lives beside settings.json so the
// "Wipe User Data" command removes it along with everything else.
const RECENT_MAX: usize = 50;
// A track only lands in history after this much real playback, so clicking a
// song and immediately skipping it does not clutter the home page.
const RECENT_MIN_MS: u32 = 100;

#[derive(Clone, serde::Serialize, serde::Deserialize)]
struct RecentTrack {
    id: String,
    title: String,
    artist: String,
    #[serde(default)]
    duration_ms: u32,
}

impl RecentTrack {
    fn to_item(&self) -> ResultItem {
        ResultItem {
            id: self.id.clone(),
            title: self.title.clone(),
            artist: self.artist.clone(),
            duration_ms: self.duration_ms,
        }
    }
}

fn history_path() -> PathBuf {
    config_path().with_file_name("history.json")
}

fn load_history() -> Vec<RecentTrack> {
    let mut rows = std::fs::read_to_string(history_path())
        .ok()
        .and_then(|text| serde_json::from_str::<Vec<RecentTrack>>(&text).ok())
        .unwrap_or_default();
    rows.retain(|row| !row.id.is_empty());
    rows.truncate(RECENT_MAX);
    rows
}

fn save_history(rows: &[RecentTrack]) {
    let path = history_path();
    if let Some(parent) = path.parent() {
        let _ = std::fs::create_dir_all(parent);
    }
    if let Ok(text) = serde_json::to_string(rows) {
        let tmp = path.with_extension("json.tmp");
        if std::fs::write(&tmp, text).is_ok() {
            let _ = std::fs::rename(&tmp, &path);
        }
    }
}

// Called from the worker once a track actually starts. Re-playing a song moves
// it back to the front instead of adding a duplicate, and the serial bump makes
// the home page rebuild its carousel.
fn mark_played(state: &Arc<Mutex<UiState>>, track: &ResultItem) {
    let mut rows = load_history();
    rows.retain(|row| row.id != track.id);
    rows.insert(
        0,
        RecentTrack {
            id: track.id.clone(),
            title: track.title.clone(),
            artist: track.artist.clone(),
            duration_ms: track.duration_ms,
        },
    );
    rows.truncate(RECENT_MAX);
    save_history(&rows);
    if let Ok(mut s) = state.lock() {
        s.recent_serial = s.recent_serial.wrapping_add(1);
    }
}

fn config_from_state(state: &Arc<Mutex<UiState>>) -> Config {
    match state.lock() {
        Ok(s) => Config {
            theme: if s.theme.is_empty() {
                String::from("rustify")
            } else {
                s.theme.clone()
            },
            search_limit: s.search_limit.clamp(1, SEARCH_LIMIT),
            no_easter_eggs: s.no_easter_eggs,
            quality: if QUALITY_IDS.contains(&s.quality.as_str()) {
                s.quality.clone()
            } else {
                "medium".to_string()
            },
            sensitive_ears: s.sensitive_ears,
            shuffle: s.shuffle,
            quiet_mode: s.quiet_mode,
            quiet_progress: s.quiet_progress,
            quiet_tilt: s.quiet_tilt,
            custom_themes: s.custom_themes.clone(),
        },
        Err(_) => Config::default(),
    }
}

fn persist_settings(state: &Arc<Mutex<UiState>>) {
    let cfg = config_from_state(state);
    save_config(&cfg);
}

// A token identifies the newest track the user asked to play. Every request
// bumps the generation; anything spawned under an older token (a yt-dlp
// download, a live stream) is killed the moment a new request arrives, so two
// tracks never load against each other.
#[derive(Clone, Copy, PartialEq, Eq)]
struct PlayToken(u64);

static PLAY_GEN: AtomicU64 = AtomicU64::new(0);

fn new_play_token() -> PlayToken {
    let gen = PLAY_GEN.fetch_add(1, Ordering::SeqCst) + 1;
    cancel_loads_before(gen);
    PlayToken(gen)
}

fn current_play_token() -> PlayToken {
    PlayToken(PLAY_GEN.load(Ordering::SeqCst))
}

// True while play_current is still fetching/opening a track. The UI reads it
// to turn next/prev into an immediate abort instead of a command that would
// sit in the channel until the load finishes.
static LOADING: AtomicBool = AtomicBool::new(false);

struct LoadingGuard;

impl Drop for LoadingGuard {
    fn drop(&mut self) {
        LOADING.store(false, Ordering::SeqCst);
    }
}

fn is_current(token: PlayToken) -> bool {
    PLAY_GEN.load(Ordering::SeqCst) == token.0
}

// Search runs off the command thread and is coalesced: only the newest query
// may touch the results list, so a burst of Enter presses cannot queue a pile
// of stale network calls in front of the one the user actually wants.
static SEARCH_GEN: AtomicU64 = AtomicU64::new(0);
static SEARCHING: AtomicBool = AtomicBool::new(false);

fn new_search_gen() -> u64 {
    SEARCHING.store(true, Ordering::SeqCst);
    SEARCH_GEN.fetch_add(1, Ordering::SeqCst) + 1
}

// Clears the search spinner when a query finishes synchronously (cache hit,
// easter egg, not logged in…). Async searches clear it from SearchDone.
struct SearchDoneGuard {
    gen: u64,
    armed: bool,
}

impl Drop for SearchDoneGuard {
    fn drop(&mut self) {
        if self.armed && SEARCH_GEN.load(Ordering::SeqCst) == self.gen {
            SEARCHING.store(false, Ordering::SeqCst);
        }
    }
}

// Foreground fetch progress for the track the user is waiting on. The playback
// bar shows this instead of the position while the current track is still being
// downloaded/streamed and playback has not started yet.
static DL_ACTIVE: AtomicBool = AtomicBool::new(false);
static DL_GEN: AtomicU64 = AtomicU64::new(0);
static DL_PERMILLE: AtomicU32 = AtomicU32::new(0);

fn dl_begin(token: PlayToken) {
    if is_current(token) {
        DL_GEN.store(token.0, Ordering::SeqCst);
        DL_PERMILLE.store(0, Ordering::SeqCst);
        DL_ACTIVE.store(true, Ordering::SeqCst);
    }
}

fn dl_update(token: PlayToken, frac: f64) {
    if DL_ACTIVE.load(Ordering::SeqCst)
        && DL_GEN.load(Ordering::SeqCst) == token.0
        && is_current(token)
    {
        let permille = (frac.clamp(0.0, 1.0) * 1000.0).round() as u32;
        DL_PERMILLE.store(permille, Ordering::SeqCst);
    }
}

fn dl_end(token: PlayToken) {
    if DL_GEN.load(Ordering::SeqCst) == token.0 {
        DL_ACTIVE.store(false, Ordering::SeqCst);
        DL_PERMILLE.store(0, Ordering::SeqCst);
    }
}

// Only report progress for the token that is still the current play request.
fn dl_snapshot() -> Option<f64> {
    if DL_ACTIVE.load(Ordering::SeqCst) && DL_GEN.load(Ordering::SeqCst) == PLAY_GEN.load(Ordering::SeqCst)
    {
        Some(DL_PERMILLE.load(Ordering::SeqCst) as f64 / 1000.0)
    } else {
        None
    }
}

// yt-dlp progress-template line: "DL <downloaded> <total> <estimate>", where
// missing numbers come through as "NA".
fn parse_dl_progress(line: &str) -> Option<f64> {
    let rest = line.trim().strip_prefix("DL ")?;
    let mut fields = rest.split_whitespace();
    let downloaded: f64 = fields.next()?.parse().ok()?;
    let total = fields
        .next()
        .and_then(|t| t.parse::<f64>().ok())
        .or_else(|| fields.next().and_then(|t| t.parse::<f64>().ok()))?;
    if total <= 0.0 {
        return None;
    }
    Some((downloaded / total).clamp(0.0, 1.0))
}

// yt-dlp children currently owned by a load, tagged with the token that
// spawned them. Killing from here lets a new click abort a load that is still
// blocked inside a read (resolving formats), not just one that polls.
fn active_loads() -> &'static Mutex<HashMap<u32, u64>> {
    static ACTIVE: OnceLock<Mutex<HashMap<u32, u64>>> = OnceLock::new();
    ACTIVE.get_or_init(|| Mutex::new(HashMap::new()))
}

#[cfg(unix)]
fn terminate_pid(pid: u32) {
    const SIGKILL: i32 = 9;
    extern "C" {
        fn kill(pid: i32, sig: i32) -> i32;
    }
    unsafe {
        kill(pid as i32, SIGKILL);
    }
}

#[cfg(not(unix))]
fn terminate_pid(_pid: u32) {}

fn register_load(pid: u32, token: PlayToken) {
    // the token may already be stale by the time the child exists; do not let
    // that work run at all
    if !is_current(token) {
        terminate_pid(pid);
        return;
    }
    if let Ok(mut map) = active_loads().lock() {
        map.insert(pid, token.0);
    }
}

fn unregister_load(pid: u32) {
    if let Ok(mut map) = active_loads().lock() {
        map.remove(&pid);
    }
}

fn cancel_loads_before(gen: u64) {
    let Ok(mut map) = active_loads().lock() else {
        return;
    };
    let stale: Vec<u32> = map
        .iter()
        .filter(|(_, tag)| **tag < gen)
        .map(|(pid, _)| *pid)
        .collect();
    for pid in &stale {
        terminate_pid(*pid);
        map.remove(pid);
    }
}

// --------------------------------------------------------------- lyrics

// Every lyric lookup bumps this generation. A lookup that finishes after the
// user already moved on is dropped instead of overwriting the new track's text.
static LYRICS_GEN: AtomicU64 = AtomicU64::new(0);

fn lyrics_cache_path(title: &str, artist: &str) -> PathBuf {
    use std::hash::{Hash, Hasher};
    let mut hasher = std::collections::hash_map::DefaultHasher::new();
    title.to_lowercase().hash(&mut hasher);
    artist.to_lowercase().hash(&mut hasher);
    cache_root()
        .join("lyrics")
        .join(format!("{:016x}.txt", hasher.finish()))
}

enum LrclibLyrics {
    Synced(String),
    Plain(String),
}

fn set_plain_lyrics(state: &Arc<Mutex<UiState>>, text: String) {
    if let Ok(mut s) = state.lock() {
        s.lyrics = text;
        s.lyrics_synced = Arc::new(Vec::new());
        s.lyrics_serial = s.lyrics_serial.wrapping_add(1);
    }
}

fn set_synced_lyrics(state: &Arc<Mutex<UiState>>, lines: Arc<Vec<LyricLine>>) {
    if let Ok(mut s) = state.lock() {
        s.lyrics = String::new();
        s.lyrics_synced = lines;
        s.lyrics_serial = s.lyrics_serial.wrapping_add(1);
    }
}

fn write_lyrics_cache(path: &Path, text: &str) {
    if let Some(parent) = path.parent() {
        let _ = std::fs::create_dir_all(parent);
    }
    let tmp = PathBuf::from(format!("{}.tmp", path.display()));
    if std::fs::write(&tmp, text).is_ok() {
        let _ = std::fs::rename(&tmp, path);
    }
}

fn start_lyrics_fetch(
    state: &Arc<Mutex<UiState>>,
    title: String,
    artist: String,
    duration_ms: u32,
) {
    if title.trim().is_empty() {
        return;
    }
    let gen = LYRICS_GEN.fetch_add(1, Ordering::SeqCst) + 1;
    let plain_path = lyrics_cache_path(&title, &artist);
    let lrc_path = plain_path.with_extension("lrc");

    // Synced lyrics are the good stuff: load them instantly if already cached.
    if let Ok(text) = std::fs::read_to_string(&lrc_path) {
        let lines = parse_lrc(&text);
        if !lines.is_empty() {
            set_synced_lyrics(state, Arc::new(lines));
            return;
        }
    }

    // A cached plain-text lookup paints right away while the timed version is
    // fetched; it also means a failed refresh never blanks the page.
    let mut have_plain = false;
    if let Ok(text) = std::fs::read_to_string(&plain_path) {
        if !text.trim().is_empty() {
            set_plain_lyrics(state, text);
            have_plain = true;
        }
    }
    if !have_plain {
        set_plain_lyrics(state, "Loading lyrics…".to_string());
    }

    let state = state.clone();
    std::thread::spawn(move || {
        let mut fetched: Option<LrclibLyrics> = fetch_lrclib_lyrics(&title, &artist, duration_ms);
        let mut synced: Option<Arc<Vec<LyricLine>>> = None;
        let mut plain: Option<String> = None;

        match fetched.take() {
            Some(LrclibLyrics::Synced(text)) => {
                let lines = parse_lrc(&text);
                if !lines.is_empty() {
                    write_lyrics_cache(&lrc_path, &text);
                    synced = Some(Arc::new(lines));
                }
            }
            Some(LrclibLyrics::Plain(text)) if !text.trim().is_empty() => {
                write_lyrics_cache(&plain_path, &text);
                plain = Some(text);
            }
            _ => {}
        }

        if synced.is_none() && plain.is_none() && !have_plain {
            match fetch_genius_lyrics(&title, &artist) {
                Ok(text) if !text.trim().is_empty() => {
                    write_lyrics_cache(&plain_path, &text);
                    plain = Some(text);
                }
                Ok(_) => plain = Some("No lyrics found.".to_string()),
                Err(e) => plain = Some(format!("No lyrics found.\n\n{e}")),
            }
        }

        if LYRICS_GEN.load(Ordering::SeqCst) != gen {
            return;
        }
        if let Some(lines) = synced {
            set_synced_lyrics(&state, lines);
        } else if let Some(text) = plain {
            set_plain_lyrics(&state, text);
        }
    });
}

// LRCLIB returns community-timed lyrics for a huge chunk of the catalogue and
// needs no account. Match on cleaned title + artist, and prefer the record
// whose duration is closest to ours.
const LRCLIB_UA: &str = "Rustify/0.1.0 (native music player)";

fn fetch_lrclib_lyrics(title: &str, artist: &str, duration_ms: u32) -> Option<LrclibLyrics> {
    let client = reqwest::blocking::Client::builder()
        .timeout(Duration::from_secs(10))
        .user_agent(LRCLIB_UA)
        .build()
        .ok()?;
    let cleaned = clean_song_title(title);
    let track = if cleaned.trim().is_empty() {
        title.trim()
    } else {
        cleaned.trim()
    };
    if track.is_empty() {
        return None;
    }
    let mut url = format!(
        "https://lrclib.net/api/search?track_name={}",
        percent_encode(track)
    );
    let artist = artist.trim();
    if !artist.is_empty() {
        url.push_str(&format!("&artist_name={}", percent_encode(artist)));
    }
    let resp = client.get(url).send().ok()?.error_for_status().ok()?;
    let body = resp.text().ok()?;
    let value: serde_json::Value = serde_json::from_str(&body).ok()?;
    let rows = value.as_array()?;

    let want = duration_ms as i64;
    let mut best_synced: Option<(i64, String)> = None;
    let mut best_plain: Option<(i64, String)> = None;
    for row in rows {
        if row
            .get("instrumental")
            .and_then(|v| v.as_bool())
            .unwrap_or(false)
        {
            continue;
        }
        let score = row
            .get("duration")
            .and_then(|v| v.as_f64())
            .map(|d| (d * 1000.0) as i64)
            .map(|d| if want > 0 { (d - want).abs() } else { 0 })
            .unwrap_or(i64::MAX / 2);
        if let Some(text) = row.get("syncedLyrics").and_then(|v| v.as_str()) {
            if !text.trim().is_empty()
                && best_synced
                    .as_ref()
                    .map(|(s, _)| score < *s)
                    .unwrap_or(true)
            {
                best_synced = Some((score, text.to_string()));
            }
        }
        if let Some(text) = row.get("plainLyrics").and_then(|v| v.as_str()) {
            if !text.trim().is_empty()
                && best_plain
                    .as_ref()
                    .map(|(s, _)| score < *s)
                    .unwrap_or(true)
            {
                best_plain = Some((score, text.to_string()));
            }
        }
    }
    if let Some((_, text)) = best_synced {
        return Some(LrclibLyrics::Synced(text));
    }
    best_plain.map(|(_, text)| LrclibLyrics::Plain(text))
}

// Parse the LRC dialect LRCLIB emits: [mm:ss.xx] line timestamps, optional
// [offset:±ms], several timestamps on one line, and <mm:ss.xx> word tags that
// are stripped so they do not show up as text.
fn parse_lrc(text: &str) -> Vec<LyricLine> {
    let mut offset: i64 = 0;
    for line in text.lines() {
        let t = line.trim();
        if let Some(v) = t.strip_prefix("[offset:").and_then(|r| r.strip_suffix(']')) {
            if let Ok(n) = v.trim().parse::<i64>() {
                offset = n;
            }
        }
    }

    let mut out: Vec<LyricLine> = Vec::new();
    for raw in text.lines() {
        let mut rest = raw.trim_end();
        let mut stamps: Vec<u32> = Vec::new();
        loop {
            let Some(stripped) = rest.strip_prefix('[') else {
                break;
            };
            let Some(end) = stripped.find(']') else {
                break;
            };
            let tag = &stripped[..end];
            rest = &stripped[end + 1..];
            if let Some(ms) = parse_lrc_time(tag) {
                stamps.push(ms);
            }
        }
        if stamps.is_empty() {
            continue;
        }
        let text = strip_lrc_inline(rest.trim());
        for ms in stamps {
            let at = (ms as i64 + offset).clamp(0, u32::MAX as i64) as u32;
            out.push(LyricLine {
                at_ms: at,
                text: text.clone(),
            });
        }
    }
    out.sort_by_key(|line| line.at_ms);
    out
}

fn parse_lrc_time(tag: &str) -> Option<u32> {
    let (mins, rest) = tag.split_once(':')?;
    let mins: u32 = mins.trim().parse().ok()?;
    let (secs, frac) = match rest.split_once('.') {
        Some((s, f)) => (s, f),
        None => (rest, ""),
    };
    let secs: u32 = secs.trim().parse().ok()?;
    let frac: u32 = if frac.is_empty() {
        0
    } else {
        let digits: String = frac.chars().take(3).collect();
        let n: u32 = digits.parse().ok()?;
        match digits.len() {
            1 => n * 100,
            2 => n * 10,
            _ => n,
        }
    };
    Some(
        mins.saturating_mul(60_000)
            .saturating_add(secs.saturating_mul(1000))
            .saturating_add(frac),
    )
}

fn strip_lrc_inline(text: &str) -> String {
    let mut out = String::with_capacity(text.len());
    let mut in_tag = false;
    for c in text.chars() {
        match c {
            '<' => in_tag = true,
            '>' => in_tag = false,
            _ if !in_tag => out.push(c),
            _ => {}
        }
    }
    out.trim().to_string()
}

fn lyric_index_at(lines: &[LyricLine], pos_ms: u32) -> Option<usize> {
    let mut found = None;
    for (i, line) in lines.iter().enumerate() {
        if line.at_ms <= pos_ms {
            found = Some(i);
        } else {
            break;
        }
    }
    found
}

const GENIUS_UA: &str = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36";

fn fetch_genius_lyrics(title: &str, artist: &str) -> Result<String, String> {
    let client = reqwest::blocking::Client::builder()
        .timeout(Duration::from_secs(15))
        .user_agent(GENIUS_UA)
        .build()
        .map_err(|e| e.to_string())?;

    // Try the URL Bing found first (exact Genius slug), then the slug we build.
    let mut urls: Vec<String> = Vec::new();
    if let Some(url) = bing_genius_url(&client, title, artist) {
        urls.push(url);
    }
    let guessed = genius_slug_url(title, artist);
    if !urls.iter().any(|u| u == &guessed) {
        urls.push(guessed);
    }

    let mut last_error = String::from("Genius is unreachable");
    for url in urls {
        match fetch_genius_page(&client, &url) {
            Ok(html) => {
                if let Some(text) =
                    extract_genius_lyrics(&html).filter(|text| !text.trim().is_empty())
                {
                    return Ok(text);
                }
                last_error = "Genius page had no lyrics.".to_string();
            }
            Err(e) => last_error = e,
        }
    }
    Err(last_error)
}

fn has_lyrics_markup(html: &str) -> bool {
    html.contains("data-lyrics-container") || html.contains("class=\"lyrics\"")
}

fn bing_genius_url(
    client: &reqwest::blocking::Client,
    title: &str,
    artist: &str,
) -> Option<String> {
    let clean = clean_song_title(title);
    let artist = artist.trim();
    let artist_l = artist.to_lowercase();
    let with_artist = !artist.is_empty()
        && artist_l != "imported audio"
        && !clean.to_lowercase().contains(&artist_l);
    let query = if with_artist {
        format!("site:genius.com {clean} {artist} lyrics")
    } else {
        format!("site:genius.com {clean} lyrics")
    };
    let html = client
        .get("https://www.bing.com/search")
        .query(&[("q", query.as_str()), ("setlang", "en"), ("cc", "us")])
        .header(reqwest::header::ACCEPT, "text/html,application/xhtml+xml")
        .header(reqwest::header::ACCEPT_LANGUAGE, "en-US,en;q=0.9")
        .send()
        .ok()?
        .error_for_status()
        .ok()?
        .text()
        .ok()?;

    let mut urls = genius_urls_in(&html);
    if urls.is_empty() {
        return None;
    }
    // prefer the slug sharing the most words with the requested track
    let words: Vec<String> = format!("{clean} {artist}")
        .split_whitespace()
        .map(|w| w.to_lowercase())
        .filter(|w| w.chars().count() > 2)
        .collect();
    urls.sort_by_cached_key(|url| {
        let lower = url.to_lowercase();
        let hits = words.iter().filter(|w| lower.contains(w.as_str())).count();
        std::cmp::Reverse(hits)
    });
    urls.into_iter().next()
}

fn genius_urls_in(html: &str) -> Vec<String> {
    let mut out: Vec<String> = Vec::new();
    // plain hrefs
    let mut search = 0usize;
    while let Some(rel) = html[search..].find("https://genius.com/") {
        let start = search + rel;
        let rest = &html[start..];
        let end = rest
            .find(|c: char| c == '"' || c == '\'' || c == '<' || c == ' ' || c == '&')
            .unwrap_or(rest.len());
        let url = &rest[..end];
        if url.ends_with("-lyrics") && !out.iter().any(|u| u == url) {
            out.push(url.to_string());
        }
        search = start + end.max(1);
    }
    // Bing wraps results as u=a1<base64url>
    let mut search = 0usize;
    while let Some(rel) = html[search..].find("u=a1") {
        let start = search + rel + 4;
        let rest = &html[start..];
        let end = rest
            .find(|c: char| !(c.is_ascii_alphanumeric() || c == '-' || c == '_'))
            .unwrap_or(rest.len());
        if end > 0 {
            if let Some(bytes) = b64url_decode(&rest[..end]) {
                if let Ok(url) = String::from_utf8(bytes) {
                    if url.starts_with("https://genius.com/") && url.ends_with("-lyrics") {
                        if !out.iter().any(|u| u == &url) {
                            out.push(url);
                        }
                    }
                }
            }
        }
        search = start + end.max(1);
    }
    out
}

fn b64url_decode(input: &str) -> Option<Vec<u8>> {
    let mut out = Vec::with_capacity(input.len() * 3 / 4);
    let mut buf = 0u32;
    let mut bits = 0u32;
    for byte in input.bytes() {
        let value = match byte {
            b'A'..=b'Z' => byte - b'A',
            b'a'..=b'z' => byte - b'a' + 26,
            b'0'..=b'9' => byte - b'0' + 52,
            b'-' | b'+' => 62,
            b'_' | b'/' => 63,
            b'=' => break,
            _ => return None,
        } as u32;
        buf = (buf << 6) | value;
        bits += 6;
        if bits >= 8 {
            bits -= 8;
            out.push((buf >> bits) as u8);
        }
    }
    Some(out)
}

fn genius_slug_url(title: &str, artist: &str) -> String {
    let clean = clean_song_title(title);
    let artist = artist.trim();
    let artist_l = artist.to_lowercase();
    let with_artist = !artist.is_empty()
        && artist_l != "imported audio"
        && !clean.to_lowercase().contains(&artist_l);
    let combined = if with_artist {
        format!("{artist} {clean}")
    } else {
        clean
    };
    let mut slug = genius_slug(&combined);
    if slug.is_empty() {
        slug = "song".to_string();
    }
    format!("https://genius.com/{slug}-lyrics")
}

// Genius slugs are the first letter upper-cased, everything else lower-cased,
// runs of punctuation collapsed to one dash; apostrophes vanish entirely.
fn genius_slug(text: &str) -> String {
    let mut out = String::with_capacity(text.len());
    let mut prev_dash = false;
    let mut first = true;
    for c in text.chars() {
        if c.is_alphanumeric() {
            if first {
                out.extend(c.to_uppercase());
                first = false;
            } else {
                out.extend(c.to_lowercase());
            }
            prev_dash = false;
        } else if c == '\'' || c == '’' || c == '‘' {
            continue;
        } else if !out.is_empty() && !prev_dash {
            out.push('-');
            prev_dash = true;
        }
    }
    out.trim_matches('-').to_string()
}

fn fetch_genius_page(client: &reqwest::blocking::Client, url: &str) -> Result<String, String> {
    // 1. direct: instant when the network is not challenged
    if let Ok(resp) = client
        .get(url)
        .timeout(Duration::from_secs(8))
        .header(reqwest::header::ACCEPT, "text/html,application/xhtml+xml")
        .header(reqwest::header::ACCEPT_LANGUAGE, "en-US,en;q=0.9")
        .send()
    {
        if resp.status().is_success() {
            if let Ok(text) = resp.text() {
                if has_lyrics_markup(&text) {
                    return Ok(text);
                }
            }
        }
    }

    // 2. Google Translate's page fetcher renders Genius server-side and is not
    // hit by the Cloudflare browser challenge. Same-language pages are
    // returned untouched, so the lyrics come back in their original wording.
    if let Some(proxy) = translate_proxy_url(url) {
        if let Ok(resp) = client
            .get(&proxy)
            .timeout(Duration::from_secs(15))
            .header(reqwest::header::ACCEPT, "text/html,application/xhtml+xml")
            .send()
        {
            if resp.status().is_success() {
                if let Ok(text) = resp.text() {
                    if has_lyrics_markup(&text) {
                        return Ok(text);
                    }
                }
            }
        }
    }

    // 3. last resort: public CORS reader
    let proxied = format!(
        "https://api.allorigins.win/raw?url={}",
        percent_encode(url)
    );
    let mut last_error = String::from("Genius is unreachable");
    for attempt in 0..2u64 {
        match client
            .get(&proxied)
            .timeout(Duration::from_secs(12))
            .header(reqwest::header::ACCEPT, "text/html,application/xhtml+xml")
            .send()
        {
            Ok(resp) if resp.status().is_success() => match resp.text() {
                Ok(text) if has_lyrics_markup(&text) => return Ok(text),
                Ok(_) => last_error = "Genius page had no lyrics.".to_string(),
                Err(e) => last_error = e.to_string(),
            },
            Ok(resp) => last_error = format!("Genius proxy HTTP {}", resp.status()),
            Err(e) => last_error = e.to_string(),
        }
        std::thread::sleep(Duration::from_millis(300 * (attempt + 1)));
    }
    Err(last_error)
}

fn translate_proxy_url(url: &str) -> Option<String> {
    let path = url.strip_prefix("https://genius.com/")?;
    Some(format!(
        "https://genius-com.translate.goog/{path}?_x_tr_sl=auto&_x_tr_tl=en&_x_tr_hl=en"
    ))
}

fn percent_encode(input: &str) -> String {
    let mut out = String::with_capacity(input.len() + 8);
    for byte in input.bytes() {
        if byte.is_ascii_alphanumeric() || matches!(byte, b'-' | b'_' | b'.' | b'~') {
            out.push(byte as char);
        } else {
            out.push_str(&format!("%{byte:02X}"));
        }
    }
    out
}

// KB's titles carry "(Official Video)", "[Lyrics]" and friends; drop bracketed
// tails so the search query resembles the real song name.
fn clean_song_title(title: &str) -> String {
    let mut out = String::with_capacity(title.len());
    let mut depth = 0i32;
    for c in title.chars() {
        match c {
            '(' | '[' | '{' => depth += 1,
            ')' | ']' | '}' => {
                if depth > 0 {
                    depth -= 1;
                }
            }
            _ if depth == 0 => out.push(c),
            _ => {}
        }
    }
    let cleaned = out.trim().trim_matches('-').trim();
    if cleaned.is_empty() {
        title.trim().to_string()
    } else {
        cleaned.to_string()
    }
}

fn extract_genius_lyrics(html: &str) -> Option<String> {
    let mut chunks: Vec<String> = Vec::new();
    collect_lyric_divs(html, "data-lyrics-container=\"true\"", &mut chunks);
    if chunks.is_empty() {
        collect_lyric_divs(html, "class=\"lyrics\"", &mut chunks);
    }
    if chunks.is_empty() {
        return None;
    }
    let mut text = String::new();
    for chunk in chunks {
        text.push_str(&html_to_text(&strip_excluded(&chunk)));
        text.push('\n');
    }
    let text = tidy_lyrics(&text);
    if text.is_empty() {
        None
    } else {
        Some(text)
    }
}

fn collect_lyric_divs(html: &str, marker: &str, out: &mut Vec<String>) {
    let mut search = 0usize;
    while let Some(rel) = html[search..].find(marker) {
        let abs = search + rel;
        let Some(open_rel) = html[abs..].find('>') else {
            break;
        };
        let start = abs + open_rel + 1;
        let Some(end) = matching_div_end(html, start) else {
            break;
        };
        out.push(html[start..end].to_string());
        search = end + 6;
    }
}

fn matching_div_end(html: &str, start: usize) -> Option<usize> {
    let mut depth = 1i32;
    let mut i = start;
    while i < html.len() {
        if html[i..].starts_with("<div") {
            depth += 1;
            i += 4;
        } else if html[i..].starts_with("</div>") {
            depth -= 1;
            if depth == 0 {
                return Some(i);
            }
            i += 6;
        } else {
            let c = html[i..].chars().next()?;
            i += c.len_utf8();
        }
    }
    None
}

// Genius puts the contributor header, translation menu and song description
// inside the first lyrics container, marked to be skipped by selection. Drop
// those subtrees before flattening tags.
fn strip_excluded(fragment: &str) -> String {
    let mut out = fragment.to_string();
    let attr = "data-exclude-from-selection=\"true\"";
    loop {
        let Some(pos) = out.find(attr) else {
            break;
        };
        let Some(open_start) = out[..pos].rfind('<') else {
            break;
        };
        let Some(open_rel) = out[pos..].find('>') else {
            break;
        };
        let content_start = pos + open_rel + 1;
        if !out[open_start + 1..].starts_with("div") {
            out.replace_range(pos..pos + attr.len(), "");
            continue;
        }
        let Some(end) = matching_div_end(&out, content_start) else {
            break;
        };
        out.replace_range(open_start..end + 6, "");
    }
    out
}

fn html_to_text(fragment: &str) -> String {
    let mut out = String::with_capacity(fragment.len());
    let mut i = 0;
    while i < fragment.len() {
        let c = match fragment[i..].chars().next() {
            Some(c) => c,
            None => break,
        };
        if c == '<' {
            let Some(rel) = fragment[i..].find('>') else {
                break;
            };
            let tag = fragment[i + 1..i + rel].trim_start().to_lowercase();
            let block = tag.starts_with("br")
                || tag.starts_with("p")
                || tag.starts_with("/p")
                || tag.starts_with("div")
                || tag.starts_with("/div")
                || tag.starts_with("li")
                || tag.starts_with("/li")
                || tag.starts_with("h")
                || tag.starts_with("/h");
            if block && !out.ends_with('\n') {
                out.push('\n');
            }
            i += rel + 1;
        } else if c.is_whitespace() {
            // pretty-printed proxies sprinkle indentation between tags; collapse
            // it so only <br>/block tags create lyric line breaks
            if !out.ends_with(' ') && !out.ends_with('\n') {
                out.push(' ');
            }
            i += c.len_utf8();
        } else {
            out.push(c);
            i += c.len_utf8();
        }
    }
    decode_entities(&out)
}

fn decode_entities(input: &str) -> String {
    let mut out = String::with_capacity(input.len());
    let mut i = 0;
    while i < input.len() {
        if input.as_bytes()[i] == b'&' {
            if let Some(semi) = input[i..].find(';') {
                if semi <= 12 {
                    let entity = &input[i + 1..i + semi];
                    let rep: Option<String> = match entity {
                        "amp" => Some("&".to_string()),
                        "lt" => Some("<".to_string()),
                        "gt" => Some(">".to_string()),
                        "quot" => Some("\"".to_string()),
                        "apos" => Some("'".to_string()),
                        "nbsp" => Some(" ".to_string()),
                        "ndash" => Some("–".to_string()),
                        "mdash" => Some("—".to_string()),
                        "hellip" => Some("…".to_string()),
                        "rsquo" => Some("’".to_string()),
                        "lsquo" => Some("‘".to_string()),
                        "ldquo" => Some("“".to_string()),
                        "rdquo" => Some("”".to_string()),
                        _ => {
                            let numeric = entity
                                .strip_prefix("#x")
                                .or_else(|| entity.strip_prefix("#X"))
                                .and_then(|hex| u32::from_str_radix(hex, 16).ok())
                                .or_else(|| {
                                    entity
                                        .strip_prefix('#')
                                        .and_then(|dec| dec.parse::<u32>().ok())
                                });
                            numeric
                                .and_then(char::from_u32)
                                .map(|c| c.to_string())
                        }
                    };
                    if let Some(rep) = rep {
                        out.push_str(&rep);
                        i += semi + 1;
                        continue;
                    }
                }
            }
        }
        let c = match input[i..].chars().next() {
            Some(c) => c,
            None => break,
        };
        out.push(c);
        i += c.len_utf8();
    }
    out
}

fn tidy_lyrics(text: &str) -> String {
    let mut out = String::with_capacity(text.len());
    let mut blank = 0u32;
    for raw in text.lines() {
        let line = raw.replace('\u{200b}', "");
        let trimmed = line.trim();
        if trimmed.eq_ignore_ascii_case("You might also like")
            || trimmed.eq_ignore_ascii_case("Embed")
        {
            continue;
        }
        if trimmed.is_empty() {
            blank += 1;
            if blank > 1 || out.is_empty() {
                continue;
            }
            out.push('\n');
        } else {
            blank = 0;
            out.push_str(trimmed);
            out.push('\n');
        }
    }
    out.trim().to_string()
}

enum Cmd {
    Search {
        query: String,
        gen: u64,
    },
    SearchDone {
        gen: u64,
        query: String,
        limit: usize,
        items: Result<Vec<ResultItem>, String>,
    },
    PlayAt {
        index: usize,
        token: PlayToken,
    },
    PlayImport {
        index: usize,
        token: PlayToken,
    },
    PlayRecent {
        id: String,
        token: PlayToken,
    },
    PlayQueue {
        index: usize,
        token: PlayToken,
    },
    ScanImports,
    PlayPause,
    Next,
    Prev,
    CancelLoad {
        token: PlayToken,
    },
    /// next/prev pressed while the current track is still loading; the old
    /// load has already been aborted by the UI, so just move the cursor
    SkipLoad {
        forward: bool,
    },
    SetShuffle(bool),
    Volume(f64),
    SetSensitiveEars(bool),
    Seek(f64),
    ListPlaylists,
    OpenPlaylist {
        index: usize,
        token: PlayToken,
    },
    Lucky {
        token: PlayToken,
    },
    CreatePlaylist {
        name: String,
        reply: Sender<Result<(), String>>,
    },
    PlaylistDetails {
        id: String,
        reply: Sender<Result<Vec<ResultItem>, String>>,
    },
    AddCurrentToPlaylist {
        id: String,
        reply: Sender<Result<(), String>>,
    },
    RemoveFromPlaylist {
        playlist_id: String,
        video_id: String,
        reply: Sender<Result<(), String>>,
    },
    DeletePlaylist {
        id: String,
        title: String,
        reply: Sender<Result<(), String>>,
    },
    Prefetch(String),
    DownloadCurrent,
    Logout,
    WipeData,
}

// ------------------------------------------------------------------ ui

// Send SIGTERM, then SIGKILL, to every process descended from us. Rust does
// not reap children when the process exits, so a streaming yt-dlp (or a
// lingering WebKit helper) would otherwise survive the window closing. This is
// run from the application shutdown hook so closing the app really closes
// everything it started.
#[cfg(unix)]
fn kill_descendants() {
    const SIGTERM: i32 = 15;
    const SIGKILL: i32 = 9;
    extern "C" {
        fn kill(pid: i32, sig: i32) -> i32;
    }

    fn descendants(skip: u32) -> Vec<u32> {
        let me = std::process::id();
        let mut kids: HashMap<u32, Vec<u32>> = HashMap::new();
        if let Ok(entries) = std::fs::read_dir("/proc") {
            for entry in entries.flatten() {
                let pid = match entry.file_name().to_string_lossy().parse::<u32>() {
                    Ok(pid) => pid,
                    Err(_) => continue,
                };
                let stat = match std::fs::read_to_string(format!("/proc/{pid}/stat")) {
                    Ok(stat) => stat,
                    Err(_) => continue,
                };
                // /proc/<pid>/stat: "pid (comm) state ppid ..."; comm may hold
                // spaces and parentheses, so anchor on the last ')'
                let after = match stat.rfind(')') {
                    Some(i) => &stat[i + 1..],
                    None => continue,
                };
                let mut fields = after.split_whitespace();
                let _state = fields.next();
                let ppid = match fields.next().and_then(|p| p.parse::<u32>().ok()) {
                    Some(ppid) => ppid,
                    None => continue,
                };
                kids.entry(ppid).or_default().push(pid);
            }
        }
        let mut out = Vec::new();
        let mut stack = vec![me];
        while let Some(parent) = stack.pop() {
            if let Some(children) = kids.get(&parent) {
                for &child in children {
                    if skip != 0 && child == skip {
                        continue;
                    }
                    out.push(child);
                    stack.push(child);
                }
            }
        }
        out
    }

    let skip = RELAUNCH_PID.load(Ordering::SeqCst);
    let pids = descendants(skip);
    for &pid in &pids {
        unsafe {
            kill(pid as i32, SIGTERM);
        }
    }
    std::thread::sleep(Duration::from_millis(80));
    // anything that ignored SIGTERM gets SIGKILL
    for pid in descendants(skip) {
        unsafe {
            kill(pid as i32, SIGKILL);
        }
    }
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.len() >= 2 && (args[1] == "--version" || args[1] == "-V") {
        println!("rustify {}", env!("CARGO_PKG_VERSION"));
        return;
    }
    if args.len() >= 2 && args[1] == "--playlists" {
        let client = reqwest::blocking::Client::builder()
            .timeout(Duration::from_secs(20))
            .user_agent(BROWSER_UA)
            .build()
            .expect("http client");
        match list_playlists(&client) {
            Ok(rows) => {
                for row in rows {
                    println!("{} | {}", row.id, row.title);
                }
            }
            Err(e) => {
                eprintln!("playlists failed: {e}");
                std::process::exit(1);
            }
        }
        return;
    }
    if args.len() >= 3 {
        match args[1].as_str() {
            "--search" => {
                let client = reqwest::blocking::Client::builder()
                    .timeout(Duration::from_secs(20))
                    .build()
                    .expect("http client");
                match search(&client, &args[2], SEARCH_LIMIT) {
                    Ok(items) => {
                        for item in items {
                            println!("{} | {} | {} | {}", item.id, item.title, item.artist, fmt_time(item.duration_ms));
                        }
                    }
                    Err(e) => {
                        eprintln!("search failed: {e}");
                        std::process::exit(1);
                    }
                }
                return;
            }
            "--stream" => {
                match resolve_stream(&args[2], &load_config().quality) {
                    Ok(url) => println!("{url}"),
                    Err(e) => {
                        eprintln!("stream failed: {e}");
                        std::process::exit(1);
                    }
                }
                return;
            }
            "--playtest" => {
                if let Err(e) = playtest(&args[2]) {
                    eprintln!("playtest failed: {e}");
                    std::process::exit(1);
                }
                return;
            }
            _ => {}
        }
    }

    if args.len() >= 2 && args[1] == "--selftest" {
        let cfg = load_config();
        let mut st0 = UiState::default();
        st0.quality = cfg.quality;
        st0.theme = cfg.theme;
        st0.volume = 0.0;
        let items: Vec<ResultItem> = load_history().iter().take(3).map(|r| r.to_item()).collect();
        for it in &items {
            eprintln!("queued: {} {} {}", it.id, it.title, it.duration_ms);
        }
        st0.results = Arc::new(items);
        let state = Arc::new(Mutex::new(st0));
        let (tx, rx) = mpsc::channel();
        spawn_worker(state.clone(), rx, tx.clone());
        std::thread::sleep(Duration::from_millis(500));
        let _ = tx.send(Cmd::PlayAt { index: 0, token: new_play_token() });
        let started = Instant::now();
        let mut last_title = String::new();
        loop {
            std::thread::sleep(Duration::from_millis(1000));
            let (title, artist, pos, dur, playing, status) = {
                let s = state.lock().unwrap();
                (s.title.clone(), s.artist.clone(), s.pos_ms, s.duration_ms, s.playing, s.status.clone())
            };
            if title != last_title {
                eprintln!("[{:6.1}s] TRACK -> {} | {} | dur={}ms playing={} status={}", started.elapsed().as_secs_f64(), title, artist, dur, playing, status);
                last_title = title;
            } else if started.elapsed().as_secs() % 5 == 0 {
                eprintln!("[{:6.1}s] pos={}ms dur={}ms playing={} status={}", started.elapsed().as_secs_f64(), pos, dur, playing, status);
            }
            if started.elapsed() > Duration::from_secs(240) {
                break;
            }
        }
        std::process::exit(0);
    }

    // session-only audio cache: no track survives a close, so clear anything a
    // previous (possibly crashed) session left behind before we start
    wipe_audio_cache();

    gtk::glib::set_prgname(Some("rustify"));
    let config = load_config();
    let mut initial_state = UiState::default();
    // the theme (including the hidden transparent one) is restored as saved;
    // the remaining developer options stay runtime-only
    initial_state.theme = config.theme.clone();
    initial_state.opaque_theme = config.theme;
    initial_state.search_limit = config.search_limit;
    initial_state.no_easter_eggs = config.no_easter_eggs;
    initial_state.quality = config.quality;
    initial_state.sensitive_ears = config.sensitive_ears;
    initial_state.shuffle = config.shuffle;
    initial_state.quiet_mode = config.quiet_mode;
    initial_state.quiet_progress = config.quiet_progress;
    initial_state.quiet_tilt = config.quiet_tilt;
    initial_state.custom_themes = config.custom_themes.clone();
    for custom in &config.custom_themes {
        register_custom_theme(&custom.name, &custom.code);
    }
    let state = Arc::new(Mutex::new(initial_state));
    let (tx, rx) = mpsc::channel();

    spawn_worker(state.clone(), rx, tx.clone());

    let app = gtk::Application::builder()
        .application_id("org.rusty.Rustify")
        .build();
    let st = state.clone();
    let cmd = tx.clone();
    app.connect_activate(move |app| {
        if let Some(window) = app.active_window() {
            window.present();
            return;
        }
        build_ui(app, st.clone(), cmd.clone())
    });
    // closing the window ends the main loop; take every child process with us
    app.connect_shutdown(|_| {
        kill_descendants();
        // played/prefetched audio is only meant to last for this session
        wipe_audio_cache();
    });
    app.run();
}

fn playtest(id: &str) -> Result<(), String> {
    let cache = cache_root().join("audio");
    let quality = load_config().quality;
    let path = download_track(id, &cache, &quality, None, false)?;
    println!("downloaded {:?} ({} bytes)", path, std::fs::metadata(&path).map(|m| m.len()).unwrap_or(0));

    let file = File::open(&path).map_err(|e| e.to_string())?;
    let decoder = Decoder::new(BufReader::with_capacity(256 * 1024, file))
        .map_err(|e| e.to_string())?;
    println!("decoded, duration {:?}", decoder.total_duration());

    let sink = DeviceSinkBuilder::open_default_sink().map_err(|e| e.to_string())?;
    let player = Player::connect_new(sink.mixer());
    player.set_volume(0.0);
    player.append(decoder);
    player.play();
    std::thread::sleep(Duration::from_secs(3));
    println!("position after 3s: {:?}", player.get_pos());
    player.stop();
    Ok(())
}

// Small download glyph drawn directly: a short arrow with a line under it.
fn download_glyph() -> gtk::DrawingArea {
    let area = gtk::DrawingArea::new();
    area.set_size_request(16, 16);
    area.set_valign(gtk::Align::Center);
    area.connect_draw(|w, cr| {
        let rgba = w.style_context().color(w.state_flags());
        cr.set_source_rgba(
            rgba.red() as f64,
            rgba.green() as f64,
            rgba.blue() as f64,
            rgba.alpha() as f64,
        );
        cr.set_line_width(1.6);
        cr.set_line_cap(gtk::cairo::LineCap::Round);
        cr.set_line_join(gtk::cairo::LineJoin::Round);
        // short shaft
        cr.move_to(8.0, 3.0);
        cr.line_to(8.0, 8.5);
        // arrow head
        cr.move_to(4.8, 6.0);
        cr.line_to(8.0, 9.2);
        cr.line_to(11.2, 6.0);
        // little line under it
        cr.move_to(4.0, 13.0);
        cr.line_to(12.0, 13.0);
        let _ = cr.stroke();
        gtk::glib::Propagation::Proceed
    });
    area
}

// Sidebar toggle: a rounded square split down the middle, one half bright and
// one half dim, painted on a bare DrawingArea so no theme button chrome (or its
// square hover plate) can bleed through. The bright side tracks the collapsed
// state; the hover tint is drawn here too.
fn sidebar_toggle(compact: std::rc::Rc<std::cell::Cell<bool>>) -> gtk::DrawingArea {
    let area = gtk::DrawingArea::new();
    area.set_size_request(28, 28);
    area.set_valign(gtk::Align::Center);
    area.set_halign(gtk::Align::End);
    // only button presses: no enter/leave means the theme never paints a
    // :hover plate behind the glyph
    area.add_events(gtk::gdk::EventMask::BUTTON_PRESS_MASK);
    area.connect_draw(move |w, cr| {
        let rgba = w.style_context().color(w.state_flags());
        let (r, g, b) = (rgba.red() as f64, rgba.green() as f64, rgba.blue() as f64);
        let alloc = w.allocation();
        let (cw, ch) = (alloc.width() as f64, alloc.height() as f64);

        // glyph lives in a 16x16 box, centred in the 28x28 hit area
        let _ = cr.save();
        cr.translate((cw - 16.0) / 2.0, (ch - 16.0) / 2.0);
        const PI: f64 = std::f64::consts::PI;
        let (x, y, ww, hh, rad) = (2.5f64, 3.5f64, 11.0f64, 9.0f64, 2.0f64);

        let bright_left = !compact.get();
        let (left_a, right_a) = if bright_left { (0.88, 0.18) } else { (0.18, 0.88) };
        let _ = cr.save();
        cr.rectangle(x + 1.0, y + 1.0, ww - 2.0, hh - 2.0);
        cr.clip();
        cr.set_source_rgba(r, g, b, left_a);
        cr.rectangle(x, y, ww / 2.0, hh);
        let _ = cr.fill();
        cr.set_source_rgba(r, g, b, right_a);
        cr.rectangle(x + ww / 2.0, y, ww / 2.0, hh);
        let _ = cr.fill();
        let _ = cr.restore();

        cr.new_sub_path();
        cr.arc(x + ww - rad, y + rad, rad, -PI / 2.0, 0.0);
        cr.arc(x + ww - rad, y + hh - rad, rad, 0.0, PI / 2.0);
        cr.arc(x + rad, y + hh - rad, rad, PI / 2.0, PI);
        cr.arc(x + rad, y + rad, rad, PI, 1.5 * PI);
        cr.close_path();
        cr.set_line_width(1.4);
        cr.set_source_rgba(r, g, b, 0.92);
        let _ = cr.stroke();

        cr.set_line_width(1.0);
        cr.set_source_rgba(r, g, b, 0.45);
        cr.move_to(x + ww / 2.0, y + 0.5);
        cr.line_to(x + ww / 2.0, y + hh - 0.5);
        let _ = cr.stroke();
        let _ = cr.restore();

        gtk::glib::Propagation::Proceed
    });
    area
}

// Quiet-mode volume: a hand-drawn slider instead of GtkScale. GtkScale picks
// up theme hover painting (and its value popup) that left a dark box over the
// quiet footer; a DrawingArea with only press/drag events stays clean.
#[derive(Clone)]
struct QuietVolume {
    area: gtk::DrawingArea,
    value: std::rc::Rc<Cell<f64>>,
}

impl QuietVolume {
    fn value(&self) -> f64 {
        self.value.get()
    }

    fn set_value(&self, v: f64) {
        let v = if v.is_finite() { v.clamp(0.0, 100.0) } else { 0.0 };
        if (v - self.value.get()).abs() < 0.01 {
            return;
        }
        self.value.set(v);
        self.area.queue_draw();
    }
}

// Map a pointer x to 0..1 across the drawn track, not the whole allocation.
fn quiet_volume_frac(width: i32, x: f64) -> f64 {
    let width = width.max(1) as f64;
    let pad = 6.0;
    let x0 = pad;
    let x1 = (width - pad).max(x0 + 1.0);
    ((x - x0) / (x1 - x0)).clamp(0.0, 1.0)
}

fn quiet_volume(tx: Sender<Cmd>, initial: f64) -> QuietVolume {
    let area = gtk::DrawingArea::new();
    area.set_size_request(160, 18);
    area.set_valign(gtk::Align::Center);
    area.set_can_focus(false);
    area.set_has_tooltip(false);
    let value = std::rc::Rc::new(Cell::new(initial.clamp(0.0, 100.0)));
    let dragging = std::rc::Rc::new(Cell::new(false));

    {
        let value = value.clone();
        area.connect_draw(move |w, cr| {
            let width = w.allocated_width() as f64;
            let height = w.allocated_height() as f64;
            let rgba = w.style_context().color(w.state_flags());
            let (r, g, b) = (rgba.red() as f64, rgba.green() as f64, rgba.blue() as f64);
            let cy = (height / 2.0).round();
            let track = 6.0;
            let pad = 6.0;
            let x0 = pad;
            let x1 = (width - pad).max(x0 + 1.0);
            let frac = (value.get() / 100.0).clamp(0.0, 1.0);
            let kx = x0 + (x1 - x0) * frac;

            cr.set_source_rgba(r, g, b, 0.14);
            rounded_rect(cr, x0, cy - track / 2.0, x1 - x0, track, track / 2.0);
            let _ = cr.fill();

            if kx > x0 + 0.5 {
                cr.set_source_rgba(r, g, b, 0.88);
                rounded_rect(cr, x0, cy - track / 2.0, kx - x0, track, track / 2.0);
                let _ = cr.fill();
            }

            cr.set_source_rgba(r, g, b, 1.0);
            cr.arc(kx, cy, 6.0, 0.0, std::f64::consts::TAU);
            let _ = cr.fill();

            gtk::glib::Propagation::Proceed
        });
    }

    {
        let value = value.clone();
        let dragging = dragging.clone();
        let area_c = area.clone();
        let tx = tx.clone();
        area.connect_button_press_event(move |_, ev| {
            if ev.button() != 1 {
                return gtk::glib::Propagation::Proceed;
            }
            dragging.set(true);
            let frac = quiet_volume_frac(area_c.allocated_width(), ev.position().0);
            let v = (frac * 100.0).round();
            value.set(v);
            area_c.queue_draw();
            let _ = tx.send(Cmd::Volume(v));
            gtk::glib::Propagation::Stop
        });
    }
    {
        let value = value.clone();
        let dragging = dragging.clone();
        let area_c = area.clone();
        let tx = tx.clone();
        area.connect_motion_notify_event(move |_, ev| {
            if !dragging.get() {
                return gtk::glib::Propagation::Proceed;
            }
            let frac = quiet_volume_frac(area_c.allocated_width(), ev.position().0);
            let v = (frac * 100.0).round();
            if (v - value.get()).abs() >= 0.5 {
                value.set(v);
                area_c.queue_draw();
                let _ = tx.send(Cmd::Volume(v));
            }
            gtk::glib::Propagation::Proceed
        });
    }
    {
        let dragging = dragging.clone();
        area.connect_button_release_event(move |_, _| {
            dragging.set(false);
            gtk::glib::Propagation::Proceed
        });
    }
    {
        let value = value.clone();
        let area_c = area.clone();
        let tx = tx.clone();
        area.connect_scroll_event(move |_, ev| {
            let step = match ev.direction() {
                gtk::gdk::ScrollDirection::Up
                | gtk::gdk::ScrollDirection::Right => 5.0,
                gtk::gdk::ScrollDirection::Down
                | gtk::gdk::ScrollDirection::Left => -5.0,
                _ => return gtk::glib::Propagation::Proceed,
            };
            let v = (value.get() + step).clamp(0.0, 100.0);
            value.set(v);
            area_c.queue_draw();
            let _ = tx.send(Cmd::Volume(v));
            gtk::glib::Propagation::Stop
        });
    }
    // press/release/drag/scroll only: no enter/leave, so the theme never puts
    // a hover plate behind the slider
    area.add_events(
        gtk::gdk::EventMask::BUTTON_PRESS_MASK
            | gtk::gdk::EventMask::BUTTON_RELEASE_MASK
            | gtk::gdk::EventMask::POINTER_MOTION_MASK
            | gtk::gdk::EventMask::SCROLL_MASK,
    );

    QuietVolume { area, value }
}


// Quiet-mode seek bar: hand-drawn like the volume slider so the theme cannot
// paint a hover plate over it. Press or drag anywhere on the track to seek.
#[derive(Clone)]
struct QuietProgress {
    area: gtk::DrawingArea,
    fraction: std::rc::Rc<Cell<f64>>,
    dragging: std::rc::Rc<Cell<bool>>,
}

fn quiet_progress_frac(width: i32, x: f64) -> f64 {
    let width = width.max(1) as f64;
    let pad = 6.0;
    let x0 = pad;
    let x1 = (width - pad).max(x0 + 1.0);
    ((x - x0) / (x1 - x0)).clamp(0.0, 1.0)
}

fn quiet_progress(tx: Sender<Cmd>, state: Arc<Mutex<UiState>>) -> QuietProgress {
    let area = gtk::DrawingArea::new();
    area.set_size_request(440, 18);
    area.set_valign(gtk::Align::Center);
    area.set_can_focus(false);
    area.set_has_tooltip(false);
    let fraction = std::rc::Rc::new(Cell::new(0.0f64));
    let dragging = std::rc::Rc::new(Cell::new(false));

    {
        let fraction = fraction.clone();
        area.connect_draw(move |w, cr| {
            let width = w.allocated_width() as f64;
            let height = w.allocated_height() as f64;
            let rgba = w.style_context().color(w.state_flags());
            let (r, g, b) = (rgba.red() as f64, rgba.green() as f64, rgba.blue() as f64);
            let cy = (height / 2.0).round();
            let track = 6.0;
            let pad = 6.0;
            let x0 = pad;
            let x1 = (width - pad).max(x0 + 1.0);
            let frac = fraction.get().clamp(0.0, 1.0);
            let kx = x0 + (x1 - x0) * frac;

            cr.set_source_rgba(r, g, b, 0.14);
            rounded_rect(cr, x0, cy - track / 2.0, x1 - x0, track, track / 2.0);
            let _ = cr.fill();

            if kx > x0 + 0.5 {
                cr.set_source_rgba(r, g, b, 0.88);
                rounded_rect(cr, x0, cy - track / 2.0, kx - x0, track, track / 2.0);
                let _ = cr.fill();
            }

            gtk::glib::Propagation::Proceed
        });
    }

    {
        let fraction = fraction.clone();
        let dragging = dragging.clone();
        let area_c = area.clone();
        area.connect_button_press_event(move |_, ev| {
            if ev.button() != 1 {
                return gtk::glib::Propagation::Proceed;
            }
            dragging.set(true);
            let frac = quiet_progress_frac(area_c.allocated_width(), ev.position().0);
            fraction.set(frac);
            area_c.queue_draw();
            gtk::glib::Propagation::Stop
        });
    }
    {
        let fraction = fraction.clone();
        let dragging = dragging.clone();
        let area_c = area.clone();
        area.connect_motion_notify_event(move |_, ev| {
            if !dragging.get() {
                return gtk::glib::Propagation::Proceed;
            }
            let frac = quiet_progress_frac(area_c.allocated_width(), ev.position().0);
            fraction.set(frac);
            area_c.queue_draw();
            gtk::glib::Propagation::Stop
        });
    }
    {
        let fraction = fraction.clone();
        let dragging = dragging.clone();
        let area_c = area.clone();
        let state_seek = state.clone();
        area.connect_button_release_event(move |_, ev| {
            if ev.button() != 1 || !dragging.get() {
                return gtk::glib::Propagation::Proceed;
            }
            dragging.set(false);
            let frac = quiet_progress_frac(area_c.allocated_width(), ev.position().0);
            fraction.set(frac);
            area_c.queue_draw();
            if let Ok(mut s) = state_seek.lock() {
                let target = (s.duration_ms as f64 * frac.clamp(0.0, 1.0)) as u32;
                s.pos_ms = target;
                s.seek_to_ms = Some(target);
            }
            let _ = tx.send(Cmd::Seek(frac));
            gtk::glib::Propagation::Stop
        });
    }
    area.add_events(
        gtk::gdk::EventMask::BUTTON_PRESS_MASK
            | gtk::gdk::EventMask::BUTTON_RELEASE_MASK
            | gtk::gdk::EventMask::POINTER_MOTION_MASK,
    );

    QuietProgress {
        area,
        fraction,
        dragging,
    }
}

// Keep the active lyric roughly centred in the scroll area.
fn scroll_lyrics_to(scroller: &gtk::ScrolledWindow, view: &gtk::Box, line: &gtk::Label) {
    let adj = scroller.vadjustment();
    let page = adj.page_size();
    if page <= 0.0 {
        return;
    }
    let Some((_, y)) = line.translate_coordinates(view, 0, 0) else {
        return;
    };
    let h = line.allocation().height() as f64;
    let target = (y as f64 + h / 2.0 - page / 2.0)
        .max(adj.lower())
        .min((adj.upper() - page).max(adj.lower()));
    adj.set_value(target);
}

struct Miniplayer {
    window: gtk::Window,
    title: gtk::Label,
    artist: gtk::Label,
    lyric: gtk::Label,
    next_lyric: gtk::Label,
    time: gtk::Label,
    progress: gtk::Scale,
    play_icon: gtk::Image,
    seeking: Rc<Cell<bool>>,
    last_title: RefCell<String>,
    last_artist: RefCell<String>,
    last_lyric: RefCell<String>,
    last_next: RefCell<String>,
    last_time: RefCell<String>,
    last_playing: Cell<bool>,
}

impl Miniplayer {
    fn toggle(&self) {
        if self.window.is_visible() {
            self.window.hide();
        } else {
            self.window.show_all();
            self.window.present();
        }
    }

    fn is_open(&self) -> bool {
        self.window.is_visible()
    }

    fn update(
        &self,
        title: &str,
        artist: &str,
        pos_ms: u32,
        duration_ms: u32,
        playing: bool,
        plain: &str,
        synced: &[LyricLine],
    ) {
        if !self.window.is_visible() {
            return;
        }

        let shown_title = if title.trim().is_empty() {
            "Nothing playing"
        } else {
            title
        };
        if *self.last_title.borrow() != shown_title {
            self.title.set_text(shown_title);
            *self.last_title.borrow_mut() = shown_title.to_string();
        }

        if *self.last_artist.borrow() != artist {
            self.artist
                .set_text(if artist.trim().is_empty() { "—" } else { artist });
            *self.last_artist.borrow_mut() = artist.to_string();
        }

        let (lyric, next) = if title.trim().is_empty() {
            ("Pick a song to see lyrics.".to_string(), String::new())
        } else {
            mini_lyric_pair(plain, synced, pos_ms, duration_ms)
        };
        if *self.last_lyric.borrow() != lyric {
            self.lyric.set_text(&lyric);
            *self.last_lyric.borrow_mut() = lyric;
        }
        if *self.last_next.borrow() != next {
            self.next_lyric.set_text(&next);
            *self.last_next.borrow_mut() = next;
        }

        let frac = if duration_ms > 0 {
            (pos_ms as f64 / duration_ms as f64).clamp(0.0, 1.0)
        } else {
            0.0
        };
        if !self.seeking.get() && (self.progress.value() - frac * 1000.0).abs() > 0.5 {
            self.progress.set_value(frac * 1000.0);
        }

        let shown_time = if duration_ms > 0 {
            format!("{} / {}", fmt_time(pos_ms), fmt_time(duration_ms))
        } else {
            String::new()
        };
        if *self.last_time.borrow() != shown_time {
            self.time.set_text(&shown_time);
            *self.last_time.borrow_mut() = shown_time;
        }

        if self.last_playing.get() != playing {
            self.last_playing.set(playing);
            self.play_icon.set_icon_name(Some(if playing {
                "media-playback-pause-symbolic"
            } else {
                "media-playback-start-symbolic"
            }));
        }
    }
}

fn mini_lyric_pair(
    plain: &str,
    synced: &[LyricLine],
    pos_ms: u32,
    duration_ms: u32,
) -> (String, String) {
    if !synced.is_empty() {
        return match lyric_index_at(synced, pos_ms) {
            Some(index) => {
                let current = if synced[index].text.trim().is_empty() {
                    "♪".to_string()
                } else {
                    synced[index].text.clone()
                };
                let next = synced
                    .get(index + 1)
                    .map(|line| line.text.clone())
                    .unwrap_or_default();
                (current, next)
            }
            None => (
                "♪".to_string(),
                synced
                    .first()
                    .map(|line| line.text.clone())
                    .unwrap_or_default(),
            ),
        };
    }

    let lines: Vec<&str> = plain
        .lines()
        .map(str::trim)
        .filter(|line| !line.is_empty())
        .collect();
    if lines.is_empty() {
        return (String::new(), String::new());
    }
    let index = if duration_ms > 0 {
        ((pos_ms as u64 * lines.len() as u64) / duration_ms as u64) as usize
    } else {
        0
    };
    let index = index.min(lines.len() - 1);
    (
        lines[index].to_string(),
        lines.get(index + 1).copied().unwrap_or("").to_string(),
    )
}

fn build_miniplayer(parent: &gtk::ApplicationWindow, tx: Sender<Cmd>) -> Rc<Miniplayer> {
    let window = gtk::Window::new(gtk::WindowType::Toplevel);
    window.set_title("Miniplayer");
    window.set_default_size(300, 640);
    window.set_resizable(true);
    // Deliberately not a transient of the main window: window managers map a
    // transient's children down together with the parent, which made the
    // miniplayer vanish whenever the main app was minimized. Keep the two
    // windows independent, but close the miniplayer with the app.
    window.set_keep_above(true);
    window.set_skip_taskbar_hint(false);
    window.set_position(gtk::WindowPosition::Center);
    {
        let window = window.clone();
        parent.connect_destroy(move |_| {
            window.close();
        });
    }

    let header = gtk::HeaderBar::new();
    header.set_show_close_button(true);
    let header_title = gtk::Label::new(Some("Miniplayer"));
    header_title.style_context().add_class("rustify-title");
    header.set_custom_title(Some(&header_title));
    window.set_titlebar(Some(&header));
    window.connect_delete_event(|window, _| {
        window.hide();
        gtk::glib::Propagation::Stop
    });

    let body = gtk::Box::new(gtk::Orientation::Vertical, 10);
    body.style_context().add_class("rustify-miniplayer");

    let content = gtk::Box::new(gtk::Orientation::Vertical, 10);
    content.set_margin_start(16);
    content.set_margin_end(16);
    content.set_margin_top(12);
    content.set_margin_bottom(14);

    let title = gtk::Label::new(Some("Nothing playing"));
    title.style_context().add_class("rustify-np-title");
    title.set_xalign(0.0);
    title.set_hexpand(true);
    title.set_ellipsize(gtk::pango::EllipsizeMode::End);
    title.set_max_width_chars(34);

    let artist = gtk::Label::new(Some("—"));
    artist.style_context().add_class("rustify-np-artist");
    artist.set_xalign(0.0);
    artist.set_hexpand(true);
    artist.set_ellipsize(gtk::pango::EllipsizeMode::End);
    artist.set_max_width_chars(40);

    let lyric = gtk::Label::new(Some("Pick a song to see lyrics."));
    lyric.style_context().add_class("rustify-miniplayer-lyric");
    lyric.set_xalign(0.5);
    lyric.set_yalign(0.0);
    lyric.set_justify(gtk::Justification::Center);
    lyric.set_line_wrap(true);
    lyric.set_line_wrap_mode(gtk::pango::WrapMode::WordChar);
    lyric.set_lines(4);
    lyric.set_ellipsize(gtk::pango::EllipsizeMode::End);
    lyric.set_vexpand(true);
    lyric.set_valign(gtk::Align::Center);

    let next_lyric = gtk::Label::new(None);
    next_lyric.style_context().add_class("rustify-miniplayer-next");
    next_lyric.set_xalign(0.5);
    next_lyric.set_justify(gtk::Justification::Center);
    next_lyric.set_line_wrap(true);
    next_lyric.set_line_wrap_mode(gtk::pango::WrapMode::WordChar);
    next_lyric.set_lines(2);
    next_lyric.set_ellipsize(gtk::pango::EllipsizeMode::End);
    next_lyric.set_max_width_chars(40);

    let progress = gtk::Scale::with_range(gtk::Orientation::Horizontal, 0.0, 1000.0, 1.0);
    progress.set_draw_value(false);
    progress.set_hexpand(true);
    let time = gtk::Label::new(None);
    time.style_context().add_class("rustify-time");
    time.set_xalign(1.0);
    time.set_width_chars(11);
    let progress_row = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    progress_row.pack_start(&progress, true, true, 0);
    progress_row.pack_end(&time, false, false, 0);

    let prev = gtk::Button::from_icon_name(
        Some("media-skip-backward-symbolic"),
        gtk::IconSize::LargeToolbar,
    );
    prev.style_context().add_class("rustify-transport");
    prev.set_tooltip_text(Some("Previous"));
    let play = gtk::Button::new();
    let play_icon = gtk::Image::from_icon_name(
        Some("media-playback-start-symbolic"),
        gtk::IconSize::LargeToolbar,
    );
    play.set_image(Some(&play_icon));
    play.style_context().add_class("rustify-miniplayer-play");
    play.set_tooltip_text(Some("Play / pause"));
    let next = gtk::Button::from_icon_name(
        Some("media-skip-forward-symbolic"),
        gtk::IconSize::LargeToolbar,
    );
    next.style_context().add_class("rustify-transport");
    next.set_tooltip_text(Some("Next"));

    let controls = gtk::Box::new(gtk::Orientation::Horizontal, 18);
    controls.set_halign(gtk::Align::Center);
    controls.pack_start(&prev, false, false, 0);
    controls.pack_start(&play, false, false, 0);
    controls.pack_start(&next, false, false, 0);

    content.pack_start(&title, false, false, 0);
    content.pack_start(&artist, false, false, 0);
    content.pack_start(&lyric, true, true, 0);
    content.pack_start(&next_lyric, false, false, 0);
    content.pack_start(&progress_row, false, false, 0);
    content.pack_start(&controls, false, false, 0);
    body.pack_start(&content, true, true, 0);
    window.add(&body);

    let seeking = Rc::new(Cell::new(false));
    {
        let seeking = seeking.clone();
        progress.connect_button_press_event(move |_, _| {
            seeking.set(true);
            gtk::glib::Propagation::Proceed
        });
    }
    {
        let tx_seek = tx.clone();
        let progress_widget = progress.clone();
        let seeking = seeking.clone();
        progress.connect_button_release_event(move |_, _| {
            let frac = progress_widget.value() / 1000.0;
            seeking.set(false);
            let _ = tx_seek.send(Cmd::Seek(frac));
            gtk::glib::Propagation::Proceed
        });
    }
    {
        let tx_prev = tx.clone();
        prev.connect_clicked(move |_| {
            if LOADING.load(Ordering::SeqCst) {
                let _ = new_play_token();
                let _ = tx_prev.send(Cmd::SkipLoad { forward: false });
            } else {
                let _ = tx_prev.send(Cmd::Prev);
            }
        });
    }
    {
        let tx_play = tx.clone();
        play.connect_clicked(move |_| {
            let _ = tx_play.send(Cmd::PlayPause);
        });
    }
    {
        let tx_next = tx.clone();
        next.connect_clicked(move |_| {
            if LOADING.load(Ordering::SeqCst) {
                let _ = new_play_token();
                let _ = tx_next.send(Cmd::SkipLoad { forward: true });
            } else {
                let _ = tx_next.send(Cmd::Next);
            }
        });
    }

    Rc::new(Miniplayer {
        window,
        title,
        artist,
        lyric,
        next_lyric,
        time,
        progress,
        play_icon,
        seeking,
        last_title: RefCell::new("Nothing playing".to_string()),
        last_artist: RefCell::new("—".to_string()),
        last_lyric: RefCell::new(String::from("\u{0}")),
        last_next: RefCell::new(String::from("\u{0}")),
        last_time: RefCell::new(String::from("\u{0}")),
        last_playing: Cell::new(false),
    })
}

fn build_ui(app: &gtk::Application, state: Arc<Mutex<UiState>>, tx: Sender<Cmd>) {
    let (
        initial_theme,
        initial_fps,
        initial_search_limit,
        initial_no_easter,
        initial_no_account,
        initial_bloated,
        initial_og_gui,
        initial_quality,
        initial_sensitive_ears,
        initial_quiet,
        initial_quiet_progress,
        initial_quiet_tilt,
    ) = {
        let s = state.lock().unwrap();
        (
            s.theme.clone(),
            s.fps_limit.clamp(1, 240),
            s.search_limit.clamp(1, SEARCH_LIMIT),
            s.no_easter_eggs,
            s.no_account,
            s.bloated,
            s.og_gui,
            s.quality.clone(),
            s.sensitive_ears,
            s.quiet_mode,
            s.quiet_progress,
            s.quiet_tilt,
        )
    };

    let win = gtk::ApplicationWindow::builder()
        .application(app)
        .title(DEVICE_NAME)
        .default_width(1180)
        .default_height(800)
        .build();

    install_symbolic_icons();
    start_gpu_monitor();

    // The transparent theme needs an RGBA visual plus app-paintable, otherwise
    // its alpha is ignored. Opaque themes must leave app-paintable off or GTK
    // skips drawing their background and the window comes up fully clear.
    if let Some(screen) = gtk::prelude::GtkWindowExt::screen(&win) {
        if let Some(visual) = screen.rgba_visual() {
            win.set_visual(Some(&visual));
        }
    }
    let transparent_active = Rc::new(Cell::new(initial_theme == "transparent" && !initial_og_gui));
    win.set_app_paintable(transparent_active.get());
    let apply_transparency: Rc<dyn Fn(bool)> = {
        let win = win.clone();
        let transparent_active = transparent_active.clone();
        Rc::new(move |on: bool| {
            transparent_active.set(on);
            win.set_app_paintable(on);
            win.queue_draw();
        })
    };

    let header = gtk::HeaderBar::new();
    let header_title = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    header_title.set_valign(gtk::Align::Center);
    let header_dot = gtk::Box::new(gtk::Orientation::Horizontal, 0);
    header_dot.style_context().add_class("rustify-dot");
    header_dot.set_valign(gtk::Align::Center);
    let header_name = gtk::Label::new(Some(DEVICE_NAME));
    header_name.style_context().add_class("rustify-title");
    header_title.pack_start(&header_dot, false, false, 0);
    header_title.pack_start(&header_name, false, false, 0);
    header.set_custom_title(Some(&header_title));
    header.set_show_close_button(true);
    win.set_titlebar(Some(&header));

    let root = gtk::Box::new(gtk::Orientation::Vertical, 0);

    // search row
    let search = gtk::SearchEntry::new();
    search.set_placeholder_text(Some("Search YouTube Music"));
    search.set_hexpand(true);
    let search_btn = gtk::Button::with_label("Search");
    search_btn.style_context().add_class("suggested-action");
    let search_row = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    search_row.style_context().add_class("rustify-search");
    search_row.set_margin_top(4);
    search_row.set_margin_bottom(4);
    search_row.set_margin_start(8);
    search_row.set_margin_end(16);
    search_row.pack_start(&search, true, true, 0);
    search_row.pack_start(&search_btn, false, false, 0);
    root.pack_start(&search_row, false, false, 0);

    // result list
    let list = gtk::ListBox::new();
    list.set_selection_mode(gtk::SelectionMode::Single);
    list.set_can_focus(false);
    let scroller = gtk::ScrolledWindow::builder().build();
    scroller.set_policy(gtk::PolicyType::Never, gtk::PolicyType::Automatic);
    scroller.set_vexpand(true);
    scroller.add(&list);

    // login gate: shown in place of results when a search is attempted
    // without a YouTube Music session
    let gate_title = gtk::Label::new(None);
    gate_title.set_markup("<span size='large' weight='bold'>Log in to search</span>");
    let gate_sub = gtk::Label::new(None);
    gate_sub.set_markup("<span alpha='65%'>A YouTube Music session is required to search and play music.</span>");
    let gate_login = gtk::Button::with_label("Login");
    gate_login.style_context().add_class("suggested-action");
    gate_login.style_context().add_class("rustify-login");
    gate_login.set_halign(gtk::Align::Center);
    let gate_box = gtk::Box::new(gtk::Orientation::Vertical, 10);
    gate_box.style_context().add_class("rustify-gate");
    gate_box.set_valign(gtk::Align::Center);
    gate_box.set_halign(gtk::Align::Center);
    gate_box.pack_start(&gate_title, false, false, 0);
    gate_box.pack_start(&gate_sub, false, false, 0);
    gate_box.pack_start(&gate_login, false, false, 4);

    let results_stack = gtk::Stack::new();
    results_stack.add_named(&scroller, "results");
    results_stack.add_named(&gate_box, "gate");
    // shown while the newest query is still in flight; the worker clears
    // SEARCHING when that query (and not an older one) reports back
    let search_spinner = gtk::Spinner::new();
    search_spinner.set_size_request(34, 34);
    let search_spinner_label = gtk::Label::new(None);
    search_spinner_label.set_markup("<span alpha='65%'>Searching…</span>");
    let searching_page = gtk::Box::new(gtk::Orientation::Vertical, 10);
    searching_page.set_valign(gtk::Align::Center);
    searching_page.set_halign(gtk::Align::Center);
    searching_page.pack_start(&search_spinner, false, false, 0);
    searching_page.pack_start(&search_spinner_label, false, false, 0);
    results_stack.add_named(&searching_page, "searching");
    results_stack.set_visible_child_name("results");
    root.pack_start(&results_stack, true, true, 0);

    let start_search: std::rc::Rc<dyn Fn(String)> = {
        let tx_search = tx.clone();
        let state_search = state.clone();
        let results_search = results_stack.clone();
        std::rc::Rc::new(move |query: String| {
            let gen = new_search_gen();
            if let Ok(mut s) = state_search.lock() {
                s.status = "Searching…".to_string();
            }
            results_search.set_visible_child_name("searching");
            let _ = tx_search.send(Cmd::Search { query, gen });
        })
    };

    // Abort whichever track is still loading. The token bump kills any yt-dlp
    // child immediately; the worker then stops the old stream if it already
    // started. Both the main player and the quiet-mode footer share this.
    let cancel_load: std::rc::Rc<dyn Fn()> = {
        let state_cancel = state.clone();
        let tx_cancel = tx.clone();
        std::rc::Rc::new(move || {
            let old = current_play_token();
            let token = new_play_token();
            dl_end(old);
            if let Ok(mut s) = state_cancel.lock() {
                s.playing = false;
                s.status = "Cancelled.".to_string();
            }
            let _ = tx_cancel.send(Cmd::CancelLoad { token });
        })
    };

    // Next/prev normally just queue a command. While a track is loading the
    // worker is blocked inside play_current, so bump the token first: that
    // aborts the fetch and lets the queued skip run right away.
    let request_skip: std::rc::Rc<dyn Fn(bool)> = {
        let tx_skip = tx.clone();
        std::rc::Rc::new(move |forward| {
            if LOADING.load(Ordering::SeqCst) {
                let _ = new_play_token();
                let _ = tx_skip.send(Cmd::SkipLoad { forward });
            } else {
                let _ = tx_skip.send(if forward { Cmd::Next } else { Cmd::Prev });
            }
        })
    };

    // now playing
    let title = gtk::Label::new(None);
    title.style_context().add_class("rustify-np-title");
    title.set_ellipsize(gtk::pango::EllipsizeMode::End);
    title.set_max_width_chars(48);
    title.set_xalign(0.0);
    let artist = gtk::Label::new(None);
    artist.style_context().add_class("rustify-np-artist");
    artist.set_ellipsize(gtk::pango::EllipsizeMode::End);
    artist.set_max_width_chars(56);
    artist.set_xalign(0.0);

    let progress = gtk::Scale::with_range(gtk::Orientation::Horizontal, 0.0, 1000.0, 1.0);
    progress.set_draw_value(false);
    progress.set_hexpand(true);
    let times = gtk::Label::new(None);
    times.style_context().add_class("rustify-time");
    times.set_xalign(1.0);

    let shuffle = gtk::ToggleButton::new();
    let shuffle_icon = gtk::Image::from_icon_name(
        Some("media-playlist-shuffle-symbolic"),
        gtk::IconSize::LargeToolbar,
    );
    shuffle.set_image(Some(&shuffle_icon));
    shuffle.style_context().add_class("rustify-transport");
    shuffle.set_tooltip_text(Some("Shuffle playlist"));
    shuffle.style_context().add_class("rustify-repeat");
    shuffle.set_active(state.lock().map(|s| s.shuffle).unwrap_or(false));
    let prev = gtk::Button::from_icon_name(
        Some("media-skip-backward-symbolic"),
        gtk::IconSize::LargeToolbar,
    );
    prev.style_context().add_class("rustify-transport");
    let play = gtk::Button::new();
    let play_icon = gtk::Image::from_icon_name(
        Some("media-playback-start-symbolic"),
        gtk::IconSize::LargeToolbar,
    );
    play.set_image(Some(&play_icon));
    play.style_context().add_class("rustify-play");
    let next = gtk::Button::from_icon_name(
        Some("media-skip-forward-symbolic"),
        gtk::IconSize::LargeToolbar,
    );
    next.style_context().add_class("rustify-transport");
    let repeat = gtk::ToggleButton::new();
    let repeat_icon = gtk::Image::from_icon_name(
        Some("media-playlist-repeat-symbolic"),
        gtk::IconSize::LargeToolbar,
    );
    repeat.set_image(Some(&repeat_icon));
    repeat.style_context().add_class("rustify-transport");
    repeat.style_context().add_class("rustify-repeat");
    repeat.set_tooltip_text(Some("Repeat current track / playlist"));
    play.set_size_request(64, -1);
    let controls = gtk::Box::new(gtk::Orientation::Horizontal, 18);
    controls.set_halign(gtk::Align::Center);
    controls.pack_start(&shuffle, false, false, 0);
    controls.pack_start(&prev, false, false, 0);
    controls.pack_start(&play, false, false, 0);
    controls.pack_start(&next, false, false, 0);
    controls.pack_start(&repeat, false, false, 0);

    let vol_icon = gtk::Image::from_icon_name(
        Some("audio-volume-medium-symbolic"),
        gtk::IconSize::Button,
    );
    let volume = gtk::Scale::with_range(gtk::Orientation::Horizontal, 0.0, 100.0, 1.0);
    volume.set_value(70.0);
    volume.set_size_request(140, -1);
    volume.set_draw_value(false);
    // the readout label is right next to it; skip GtkScale's hover tooltip
    volume.set_has_tooltip(false);
    // reserve a fixed-width slot so the readout ticking 9% -> 100% never
    // nudges the slider sideways mid-drag
    let vol_pct = gtk::Label::new(Some("70%"));
    vol_pct.style_context().add_class("rustify-time");
    vol_pct.set_width_chars(4);
    vol_pct.set_xalign(1.0);
    let vol_row = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    vol_row.pack_start(&vol_icon, false, false, 0);
    vol_row.pack_start(&volume, false, false, 0);
    vol_row.pack_start(&vol_pct, false, false, 0);
    vol_row.set_visible(!initial_sensitive_ears);

    let time_row = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    time_row.pack_start(&progress, true, true, 0);
    time_row.pack_start(&times, false, false, 0);

    let info = gtk::Box::new(gtk::Orientation::Vertical, 4);
    info.set_valign(gtk::Align::Center);
    info.pack_start(&title, false, false, 0);
    info.pack_start(&artist, false, false, 0);
    info.pack_start(&time_row, false, false, 4);
    info.pack_start(&controls, false, false, 2);

    let status = gtk::Label::new(None);
    status.style_context().add_class("rustify-status");
    status.set_ellipsize(gtk::pango::EllipsizeMode::End);
    status.set_max_width_chars(80);
    status.set_xalign(0.0);

    let bar = gtk::Box::new(gtk::Orientation::Horizontal, 16);
    bar.set_margin_top(12);
    bar.set_margin_bottom(12);
    bar.set_margin_start(16);
    bar.set_margin_end(16);
    bar.pack_start(&info, true, true, 0);

    // volume lives in the lowest row, pinned to the bottom-right corner of
    // the player, instead of floating level with the track title
    vol_row.set_valign(gtk::Align::Center);
    vol_row.set_margin_end(4);
    let footer = gtk::Box::new(gtk::Orientation::Horizontal, 12);
    footer.pack_end(&vol_row, false, false, 0);

    // bottom-left: download the current song into the imports folder
    let download_btn = gtk::Button::new();
    download_btn.style_context().add_class("flat");
    download_btn.style_context().add_class("rustify-download");
    download_btn.set_tooltip_text(Some("Download the current song to the imports folder"));
    download_btn.set_valign(gtk::Align::Center);
    {
        let content = gtk::Box::new(gtk::Orientation::Horizontal, 6);
        let icon = download_glyph();
        let label = gtk::Label::new(Some("Download"));
        content.pack_start(&icon, false, false, 0);
        content.pack_start(&label, false, false, 0);
        download_btn.add(&content);
    }
    {
        let tx_dl = tx.clone();
        download_btn.connect_clicked(move |_| {
            let _ = tx_dl.send(Cmd::DownloadCurrent);
        });
    }
    footer.pack_start(&download_btn, false, false, 0);

    // minimize control: a down arrow at the top-left of the expanded player
    let collapse_btn =
        gtk::Button::from_icon_name(Some("pan-down-symbolic"), gtk::IconSize::Button);
    collapse_btn.style_context().add_class("rustify-np-minimize");
    collapse_btn.set_tooltip_text(Some("Minimize player"));
    collapse_btn.set_halign(gtk::Align::Start);
    collapse_btn.set_valign(gtk::Align::Center);
    let cancel_btn = gtk::Button::from_icon_name(
        Some("window-close-symbolic"),
        gtk::IconSize::Button,
    );
    cancel_btn.style_context().add_class("rustify-cancel");
    cancel_btn.set_tooltip_text(Some("Cancel loading"));
    cancel_btn.set_halign(gtk::Align::End);
    cancel_btn.set_valign(gtk::Align::Center);
    cancel_btn.set_margin_end(8);
    cancel_btn.set_no_show_all(true);
    cancel_btn.set_visible(false);
    {
        let cancel_load = cancel_load.clone();
        cancel_btn.connect_clicked(move |_| cancel_load());
    }
    let np_header = gtk::Box::new(gtk::Orientation::Horizontal, 0);
    np_header.pack_start(&collapse_btn, false, false, 0);
    np_header.pack_end(&cancel_btn, false, false, 0);

    let expanded_box = gtk::Box::new(gtk::Orientation::Vertical, 2);
    expanded_box.pack_start(&np_header, false, false, 0);
    expanded_box.pack_start(&bar, false, false, 0);
    expanded_box.pack_start(&footer, false, false, 0);

    // collapsed bar: song name on the left, pause/play button on the right
    let mini_title = gtk::Label::new(Some("Nothing playing"));
    mini_title.style_context().add_class("rustify-np-title");
    mini_title.set_ellipsize(gtk::pango::EllipsizeMode::End);
    mini_title.set_xalign(0.0);
    mini_title.set_hexpand(true);
    let mini_play = gtk::Button::new();
    let mini_play_icon = gtk::Image::from_icon_name(
        Some("media-playback-start-symbolic"),
        gtk::IconSize::Button,
    );
    mini_play.set_image(Some(&mini_play_icon));
    mini_play.style_context().add_class("rustify-transport");
    mini_play.set_tooltip_text(Some("Play / pause"));
    mini_play.set_size_request(36, 36);
    mini_play.set_valign(gtk::Align::Center);
    let expand_btn =
        gtk::Button::from_icon_name(Some("pan-up-symbolic"), gtk::IconSize::Button);
    expand_btn.style_context().add_class("rustify-np-minimize");
    expand_btn.set_tooltip_text(Some("Expand player"));
    expand_btn.set_valign(gtk::Align::Center);
    let mini_bar = gtk::Box::new(gtk::Orientation::Horizontal, 10);
    mini_bar.set_valign(gtk::Align::Center);
    mini_bar.pack_start(&expand_btn, false, false, 0);
    mini_bar.pack_start(&mini_title, true, true, 0);
    mini_bar.pack_end(&mini_play, false, false, 0);

    // plain strip that replaces the whole player while a song is downloading
    let dl_bar = gtk::ProgressBar::new();
    dl_bar.set_show_text(false);
    dl_bar.set_valign(gtk::Align::Center);
    dl_bar.set_hexpand(true);
    dl_bar.style_context().add_class("rustify-dlbar");
    dl_bar.set_margin_top(22);
    dl_bar.set_margin_bottom(22);
    dl_bar.set_no_show_all(true);
    dl_bar.hide();

    let bottom = gtk::Box::new(gtk::Orientation::Vertical, 2);
    bottom.style_context().add_class("rustify-player");
    bottom.pack_start(&expanded_box, false, false, 0);
    bottom.pack_start(&mini_bar, false, false, 0);
    bottom.pack_start(&dl_bar, false, false, 0);

    // start expanded; the compact bar stays hidden until the arrow is pressed
    mini_bar.set_no_show_all(true);
    mini_bar.hide();
    let collapsed = std::rc::Rc::new(std::cell::Cell::new(false));
    let toggle_min = {
        let collapsed = collapsed.clone();
        let expanded_box = expanded_box.clone();
        let mini_bar = mini_bar.clone();
        let bottom = bottom.clone();
        std::rc::Rc::new(move || {
            let c = !collapsed.get();
            collapsed.set(c);
            if c {
                bottom.style_context().add_class("rustify-player-mini");
                expanded_box.set_no_show_all(true);
                expanded_box.hide();
                mini_bar.set_no_show_all(false);
                mini_bar.show_all();
            } else {
                bottom.style_context().remove_class("rustify-player-mini");
                mini_bar.set_no_show_all(true);
                mini_bar.hide();
                expanded_box.set_no_show_all(false);
                expanded_box.show_all();
            }
        })
    };
    {
        let toggle_min = toggle_min.clone();
        collapse_btn.connect_clicked(move |_| toggle_min());
    }
    {
        let toggle_min = toggle_min.clone();
        expand_btn.connect_clicked(move |_| toggle_min());
    }

    // gray sidebar column on the left holding the memory readout
    let mem_head = gtk::Label::new(None);
    mem_head.set_markup("<span size='small' weight='bold' alpha='70%' rise='-1024'>MEMORY USAGE</span>");
    mem_head.set_xalign(0.0);
    let mem_value = gtk::Label::new(None);
    mem_value.set_markup("<span size='large' weight='bold'>0.0</span><span size='small'> MB</span>");
    mem_value.set_xalign(0.0);
    let mem_bar = gtk::LevelBar::new();
    const MEM_BAR_MAX: f64 = 128.0;
    mem_bar.set_min_value(0.0);
    mem_bar.set_max_value(MEM_BAR_MAX);
    mem_bar.set_size_request(-1, 8);
    mem_bar.set_hexpand(true);

    let mem_section = gtk::Box::new(gtk::Orientation::Vertical, 4);
    mem_section.style_context().add_class("rustify-meter");
    mem_section.set_margin_top(10);
    mem_section.set_margin_bottom(10);
    mem_section.set_margin_start(12);
    mem_section.set_margin_end(12);
    mem_section.set_valign(gtk::Align::Start);
    mem_section.pack_start(&mem_head, false, false, 0);
    mem_section.pack_start(&mem_value, false, false, 0);
    mem_section.pack_start(&mem_bar, false, false, 4);
    mem_section.show();

    // the spinning app icon lives on the home screen, above the wordmark
    let logo_area = gtk::DrawingArea::new();
    logo_area.set_size_request(200, 200);
    logo_area.set_halign(gtk::Align::Center);

    // FPS readout + limiter, hidden until enabled in developer options
    let fps_head = gtk::Label::new(None);
    fps_head.set_markup("<span size='small' weight='bold' alpha='70%' rise='-1024'>FRAMES / SEC</span>");
    fps_head.set_xalign(0.0);
    let fps_value = gtk::Label::new(None);
    fps_value.set_markup("<span size='large' weight='bold'>0.0</span><span size='small'> fps</span>");
    fps_value.set_xalign(0.0);
    let fps_cap_label = gtk::Label::new(None);
    fps_cap_label.set_markup(&format!(
        "<span size='x-small' alpha='60%'>cap {}</span>",
        initial_fps
    ));
    fps_cap_label.set_xalign(0.0);
    let fps_entry = gtk::Entry::new();
    fps_entry.set_text(&initial_fps.to_string());
    fps_entry.set_width_chars(5);
    fps_entry.set_tooltip_text(Some("Frame-rate limit (1-240). Press Enter to apply."));
    fps_entry.set_placeholder_text(Some("240"));

    // frame ticks are drained through this tiny canvas, so the fps the app
    // reports is the real paint rate, not the timer rate
    let fps_area = gtk::DrawingArea::new();
    fps_area.set_size_request(8, 8);

    let fps_section = gtk::Box::new(gtk::Orientation::Vertical, 4);
    fps_section.style_context().add_class("rustify-meter");
    fps_section.set_margin_top(6);
    fps_section.set_margin_bottom(10);
    fps_section.set_margin_start(12);
    fps_section.set_margin_end(12);
    fps_section.set_valign(gtk::Align::Start);
    fps_section.pack_start(&fps_head, false, false, 0);
    fps_section.pack_start(&fps_value, false, false, 0);
    fps_section.pack_start(&fps_cap_label, false, false, 2);
    let fps_hint = gtk::Label::new(None);
    fps_hint.set_markup("<span size='x-small' alpha='60%'>limit</span>");
    fps_hint.set_xalign(0.0);
    fps_section.pack_start(&fps_hint, false, false, 4);
    fps_section.pack_start(&fps_entry, false, false, 0);
    fps_section.pack_start(&fps_area, false, false, 4);
    fps_section.set_no_show_all(true);
    fps_section.hide();

    let side = gtk::Box::new(gtk::Orientation::Vertical, 0);
    side.style_context().add_class("rustify-sidebar");
    side.set_size_request(SIDEBAR_WIDTH, -1);
    side.set_halign(gtk::Align::Fill);

    // brand block at the top of the rail
    let brand_mark = gtk::Box::new(gtk::Orientation::Horizontal, 0);
    brand_mark.style_context().add_class("rustify-brand-mark");
    brand_mark.set_valign(gtk::Align::Center);
    let brand_icon = gtk::DrawingArea::new();
    brand_icon.set_size_request(30, 30);
    {
        let state_brand = state.clone();
        let color_pix = tux_pixbuf(30);
        let gray_pix = color_pix.as_ref().and_then(grayscale_pixbuf);
        brand_icon.connect_draw(move |area, cr| {
            let mono = state_brand
                .lock()
                .map(|s| s.og_gui || s.theme == "slate")
                .unwrap_or(false);
            let pix = if mono {
                gray_pix.as_ref().or(color_pix.as_ref())
            } else {
                color_pix.as_ref()
            };
            if let Some(p) = pix {
                use gtk::gdk::prelude::GdkContextExt;
                let alloc = area.allocation();
                let x = (alloc.width() as f64 - p.width() as f64) / 2.0;
                let y = (alloc.height() as f64 - p.height() as f64) / 2.0;
                cr.set_source_pixbuf(p, x, y);
                let _ = cr.paint();
            }
            gtk::glib::Propagation::Proceed
        });
        // the hidden developer section is revealed by fifteen taps on the
        // tux, not by any search query
        brand_icon.add_events(gtk::gdk::EventMask::BUTTON_PRESS_MASK);
        let state_taps = state.clone();
        let taps = std::rc::Rc::new(std::cell::Cell::new(0u32));
        brand_icon.connect_button_press_event(move |_, ev| {
            if ev.button() != 1 {
                return gtk::glib::Propagation::Proceed;
            }
            let n = taps.get() + 1;
            if n < 15 {
                taps.set(n);
                return gtk::glib::Propagation::Proceed;
            }
            taps.set(0);
            if let Ok(mut s) = state_taps.lock() {
                s.dev_reveal_soon = true;
                s.status = "Dev options enabled.".to_string();
            }
            gtk::glib::Propagation::Stop
        });
    }
    brand_icon.add_tick_callback(|area, _| {
        area.queue_draw();
        gtk::glib::ControlFlow::Continue
    });
    brand_mark.set_center_widget(Some(&brand_icon));
    let brand_text = gtk::Box::new(gtk::Orientation::Vertical, 0);
    brand_text.set_valign(gtk::Align::Center);
    let brand_name = gtk::Label::new(None);
    brand_name.set_markup("<span weight='bold' size='12pt'>Rustify</span>");
    brand_name.set_xalign(0.0);
    let brand_sub = gtk::Label::new(None);
    brand_sub.set_markup("<span size='x-small' alpha='45%'>linux</span>");
    brand_sub.set_xalign(0.0);
    brand_text.pack_start(&brand_name, false, false, 0);
    brand_text.pack_start(&brand_sub, false, false, 0);
    // top-right control: collapse the rail down to its icons
    let compact_flag = std::rc::Rc::new(std::cell::Cell::new(false));
    let compact_toggle = sidebar_toggle(compact_flag.clone());
    let brand = gtk::Box::new(gtk::Orientation::Horizontal, 10);
    brand.style_context().add_class("rustify-brand");
    brand.pack_start(&brand_mark, false, false, 0);
    brand.pack_start(&brand_text, true, true, 0);
    brand.pack_end(&compact_toggle, false, false, 0);
    side.pack_start(&brand, false, false, 0);

    let nav_label = gtk::Label::new(None);
    nav_label.set_markup("<span size='x-small' weight='bold' alpha='45%'>LIBRARY</span>");
    nav_label.set_xalign(0.0);
    nav_label.set_margin_top(14);
    nav_label.set_margin_bottom(6);
    nav_label.set_margin_start(14);
    side.pack_start(&nav_label, false, false, 0);

    let nav_box = gtk::Box::new(gtk::Orientation::Vertical, 4);
    nav_box.style_context().add_class("rustify-navbox");
    side.pack_start(&nav_box, false, false, 0);

    let side_footer = gtk::Box::new(gtk::Orientation::Vertical, 6);
    side_footer.style_context().add_class("rustify-sidefooter");
    side_footer.pack_start(&mem_section, false, false, 0);
    side_footer.pack_start(&fps_section, false, false, 0);
    // bottom stack: meters stay above the settings entry, and the settings
    // entry rides outside the footer so collapsing the rail keeps it visible
    let side_bottom = gtk::Box::new(gtk::Orientation::Vertical, 0);
    side_bottom.pack_start(&side_footer, false, false, 0);
    side.pack_end(&side_bottom, false, false, 0);

    // home button pinned to the bottom-left corner; flips to the home screen
    let home_btn = gtk::Button::new();
    home_btn.style_context().add_class("flat");
    home_btn.style_context().add_class("rustify-nav");
    home_btn.set_tooltip_text(Some("Home"));
    let home_label = gtk::Label::new(Some("Home"));
    home_label.set_xalign(0.0);
    let home_content = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    {
        let icon = gtk::Image::from_icon_name(Some("go-home-symbolic"), gtk::IconSize::Button);
        home_content.pack_start(&icon, false, false, 0);
        home_content.pack_start(&home_label, false, false, 0);
        home_btn.add(&home_content);
    }
    home_btn.set_halign(gtk::Align::Fill);

    // playlists entry, revealed once a YouTube Music session is available
    let playlists_nav = gtk::Button::new();
    playlists_nav.style_context().add_class("flat");
    playlists_nav.style_context().add_class("rustify-nav");
    playlists_nav.set_tooltip_text(Some("Your YouTube Music playlists"));
    let playlists_label = gtk::Label::new(Some("Playlists"));
    playlists_label.set_xalign(0.0);
    let playlists_content = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    {
        let icon = gtk::Image::from_icon_name(Some("view-list-symbolic"), gtk::IconSize::Button);
        playlists_content.pack_start(&icon, false, false, 0);
        playlists_content.pack_start(&playlists_label, false, false, 0);
        playlists_nav.add(&playlists_content);
    }
    playlists_nav.set_halign(gtk::Align::Fill);

    // imports entry: always available, plays mp3s straight from disk
    let imports_nav = gtk::Button::new();
    imports_nav.style_context().add_class("flat");
    imports_nav.style_context().add_class("rustify-nav");
    imports_nav.set_tooltip_text(Some("MP3 files from the imports folder"));
    let imports_label = gtk::Label::new(Some("Imports"));
    imports_label.set_xalign(0.0);
    let imports_content = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    {
        let icon = gtk::Image::from_icon_name(Some(FILE_UPLOAD_ICON_NAME), gtk::IconSize::Button);
        imports_content.pack_start(&icon, false, false, 0);
        imports_content.pack_start(&imports_label, false, false, 0);
        imports_nav.add(&imports_content);
    }
    imports_nav.set_halign(gtk::Align::Fill);

    // lyrics entry: shows Genius lyrics for the current track
    let lyrics_nav = gtk::Button::new();
    lyrics_nav.style_context().add_class("flat");
    lyrics_nav.style_context().add_class("rustify-nav");
    lyrics_nav.set_tooltip_text(Some("Lyrics for the current song"));
    let lyrics_label = gtk::Label::new(Some("Lyrics"));
    lyrics_label.set_xalign(0.0);
    let lyrics_content = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    {
        let icon = gtk::Image::from_icon_name(
            Some("audio-input-microphone-symbolic"),
            gtk::IconSize::Button,
        );
        lyrics_content.pack_start(&icon, false, false, 0);
        lyrics_content.pack_start(&lyrics_label, false, false, 0);
        lyrics_nav.add(&lyrics_content);
    }
    lyrics_nav.set_halign(gtk::Align::Fill);

    nav_box.pack_start(&home_btn, false, false, 0);
    nav_box.pack_start(&imports_nav, false, false, 0);
    nav_box.pack_start(&playlists_nav, false, false, 0);
    nav_box.pack_start(&lyrics_nav, false, false, 0);

    // quiet mode rail: a single tall queue list. Hidden until "stop annoying
    // me" is flipped, then it takes the whole rail under the queue heading.
    let quiet_head = gtk::Label::new(None);
    quiet_head.set_markup("<span size='x-small' weight='bold' alpha='45%'>QUEUE</span>");
    quiet_head.set_xalign(0.0);
    quiet_head.set_margin_top(14);
    quiet_head.set_margin_bottom(6);
    quiet_head.set_margin_start(14);
    let quiet_list = gtk::ListBox::new();
    quiet_list.set_selection_mode(gtk::SelectionMode::None);
    quiet_list.set_can_focus(false);
    let quiet_scroller = gtk::ScrolledWindow::builder().build();
    quiet_scroller.set_policy(gtk::PolicyType::Never, gtk::PolicyType::Automatic);
    quiet_scroller.set_vexpand(true);
    quiet_scroller.add(&quiet_list);
    let quiet_queue_page = gtk::Box::new(gtk::Orientation::Vertical, 0);
    quiet_queue_page.pack_start(&quiet_head, false, false, 0);
    quiet_queue_page.pack_start(&quiet_scroller, true, true, 0);

    let quiet_pl_head = gtk::Label::new(None);
    quiet_pl_head.set_markup("<span size='x-small' weight='bold' alpha='45%'>PLAYLISTS</span>");
    quiet_pl_head.set_xalign(0.0);
    quiet_pl_head.set_margin_top(14);
    quiet_pl_head.set_margin_bottom(6);
    quiet_pl_head.set_margin_start(14);
    let quiet_pl_list = gtk::ListBox::new();
    quiet_pl_list.set_selection_mode(gtk::SelectionMode::None);
    quiet_pl_list.set_can_focus(false);
    let quiet_pl_scroller = gtk::ScrolledWindow::builder().build();
    quiet_pl_scroller.set_policy(gtk::PolicyType::Never, gtk::PolicyType::Automatic);
    quiet_pl_scroller.set_vexpand(true);
    quiet_pl_scroller.add(&quiet_pl_list);
    let quiet_pl_page = gtk::Box::new(gtk::Orientation::Vertical, 0);
    quiet_pl_page.pack_start(&quiet_pl_head, false, false, 0);
    quiet_pl_page.pack_start(&quiet_pl_scroller, true, true, 0);

    let quiet_stack = gtk::Stack::new();
    quiet_stack.set_transition_type(gtk::StackTransitionType::Crossfade);
    quiet_stack.set_transition_duration(120);
    quiet_stack.add_named(&quiet_queue_page, "queue");
    quiet_stack.add_named(&quiet_pl_page, "playlists");
    quiet_stack.set_visible_child_name("queue");
    let quiet_side = gtk::Box::new(gtk::Orientation::Vertical, 0);
    quiet_side.pack_start(&quiet_stack, true, true, 0);
    quiet_side.set_no_show_all(true);
    quiet_side.hide();
    side.pack_start(&quiet_side, true, true, 0);

    // handles the compact toggle flips: nav labels hide and their icon rows
    // recentre so the rail reads as a column of icons
    let nav_labels = [
        home_label.clone(),
        imports_label.clone(),
        playlists_label.clone(),
        lyrics_label.clone(),
    ];
    let nav_contents = [
        home_content.clone(),
        imports_content.clone(),
        playlists_content.clone(),
        lyrics_content.clone(),
    ];

    // render-loop state
    let fps_limit = std::rc::Rc::new(std::cell::Cell::new(initial_fps));
    let frame_gen = std::rc::Rc::new(std::cell::Cell::new(0u64));
    let frame_last = std::rc::Rc::new(std::cell::Cell::new(0u64));
    let frame_when = std::rc::Rc::new(std::cell::RefCell::new(std::time::Instant::now()));
    // shared with the logo canvas and the settings toggle
    let bloat_flag = std::rc::Rc::new(std::cell::Cell::new(initial_bloated));

    // the app icon, rasterized once, for the spinning-logo canvas
    let logo_pix: Option<gtk::gdk_pixbuf::Pixbuf> = {
        let exe_dir = std::env::current_exe()
            .ok()
            .and_then(|p| p.parent().map(|d| d.to_path_buf()));
        let mut candidates: Vec<PathBuf> = Vec::new();
        if let Some(dir) = exe_dir.as_ref() {
            candidates.push(dir.join("../../rustify.svg"));
            candidates.push(dir.join("../rustify.svg"));
            candidates.push(dir.join("rustify.svg"));
        }
        if let Some(home) = std::env::var("HOME").ok().map(PathBuf::from) {
            let base = home.join("Desktop/rustify");
            candidates.push(base.join("rustifysource/rustify.svg"));
            candidates.push(base.join("rustify.svg"));
        }
        candidates
            .iter()
            .find_map(|p| gtk::gdk_pixbuf::Pixbuf::from_file_at_size(p, 116, 116).ok())
    };
    let logo_gray = logo_pix.as_ref().and_then(grayscale_pixbuf);
    // transparent theme only: the same icon flattened to white and black
    let logo_bw = logo_pix.as_ref().and_then(black_white_pixbuf);

    // sidebar frame tick: counts real paint frames for the fps readout
    {
        let fg = frame_gen.clone();
        fps_area.connect_draw(move |_, _cr| {
            fg.set(fg.get() + 1);
            gtk::glib::Propagation::Proceed
        });
    }

    // keep the fps canvas repainting at the configured cap while it is on
    // screen, so the readout reflects the real paint rate rather than 0
    {
        let fps_limit = fps_limit.clone();
        let last_tick = std::rc::Rc::new(std::cell::RefCell::new(std::time::Instant::now()));
        let accum = std::rc::Rc::new(std::cell::RefCell::new(std::time::Duration::ZERO));
        fps_area.add_tick_callback(move |area, _clock| {
            if !area.is_mapped() {
                *last_tick.borrow_mut() = std::time::Instant::now();
                *accum.borrow_mut() = std::time::Duration::ZERO;
                return gtk::glib::ControlFlow::Continue;
            }
            let fps = fps_limit.get().clamp(1, 240) as f64;
            let interval = std::time::Duration::from_secs_f64(1.0 / fps);
            let now = std::time::Instant::now();
            let delta = {
                let mut lt = last_tick.borrow_mut();
                let d = now.saturating_duration_since(*lt);
                *lt = now;
                d
            };
            let due = {
                let mut acc = accum.borrow_mut();
                *acc = acc.saturating_add(delta);
                if *acc >= interval {
                    *acc = acc.saturating_sub(interval).min(interval);
                    true
                } else {
                    false
                }
            };
            if due {
                area.queue_draw();
            }
            gtk::glib::ControlFlow::Continue
        });
    }

    // refresh the fps readout once a second from the paint counter
    {
        let fps_value = fps_value.clone();
        let frame_gen = frame_gen.clone();
        let frame_last = frame_last.clone();
        let frame_when = frame_when.clone();
        gtk::glib::timeout_add_seconds_local(1, move || {
            let now = std::time::Instant::now();
            let frames = frame_gen.get();
            let elapsed = {
                let mut when = frame_when.borrow_mut();
                let e = now.saturating_duration_since(*when).as_secs_f64();
                *when = now;
                e.max(0.001)
            };
            let delta = frames.saturating_sub(frame_last.get());
            frame_last.set(frames);
            fps_value.set_markup(&format!(
                "<span size='large' weight='bold'>{:.1}</span><span size='small'> fps</span>",
                delta as f64 / elapsed
            ));
            gtk::glib::ControlFlow::Continue
        });
    }

    // home logo: a slow wall-clock spin wrapped in a breathing accent halo,
    // so the hero has motion even with bloated mode off
    {
        let logo_pix = logo_pix.clone();
        let logo_gray = logo_gray.clone();
        let logo_bw = logo_bw.clone();
        let bloat_flag = bloat_flag.clone();
        let state_glow = state.clone();
        let spin_epoch = std::time::Instant::now();
        logo_area.connect_draw(move |_, cr| {
            let t = spin_epoch.elapsed().as_secs_f64();
            let bloated = bloat_flag.get();
            let angle = t * if bloated { 2.4 } else { 0.55 };
            let (theme, og) = state_glow
                .lock()
                .map(|s| (s.theme.clone(), s.og_gui))
                .unwrap_or_else(|_| ("rustify".to_string(), false));
            let mono = og || theme == "slate";
            // the transparent theme is the only one that paints the home logo
            // in strict white and black
            let transparent_logo = !og && theme == "transparent";
            let (ar, ag, ab) = match if og { "slate" } else { theme.as_str() } {
                "slate" => (0.82, 0.82, 0.82),
                "mint" => (0.06, 0.73, 0.51),
                "light" => (0.10, 0.10, 0.11),
                "discord" => (0.35, 0.40, 0.95),
                "transparent" => (0.0, 0.0, 0.0),
                _ => (0.66, 0.33, 0.97),
            };
            const LOGO_W: f64 = 200.0;
            let cx = LOGO_W / 2.0;
            if !og {
                let breathe = 0.5 + 0.5 * (t * 1.3).sin();
                let radius = 88.0 + 8.0 * breathe as f64;
                let halo = gtk::cairo::RadialGradient::new(cx, cx, 6.0, cx, cx, radius);
                halo.add_color_stop_rgba(0.0, ar, ag, ab, 0.30 + 0.10 * breathe as f64);
                halo.add_color_stop_rgba(0.52, ar, ag, ab, 0.10);
                halo.add_color_stop_rgba(1.0, ar, ag, ab, 0.0);
                let _ = cr.set_source(&halo);
                cr.arc(cx, cx, radius, 0.0, 2.0 * std::f64::consts::PI);
                let _ = cr.fill();

                // thin orbit ring, fading in and out with the halo
                cr.set_source_rgba(ar, ag, ab, 0.10 + 0.10 * breathe as f64);
                cr.set_line_width(1.0);
                cr.arc(cx, cx, 82.0, 0.0, 2.0 * std::f64::consts::PI);
                let _ = cr.stroke();
            }

            let _ = cr.save();
            cr.translate(cx, cx);
            cr.rotate(angle);
            if bloated {
                let pulse = 1.0 + 0.08 * (t * 3.2).sin();
                cr.scale(pulse, pulse);
            }
            let active_logo = if transparent_logo {
                logo_bw.as_ref().or(logo_pix.as_ref())
            } else if mono {
                logo_gray.as_ref().or(logo_pix.as_ref())
            } else {
                logo_pix.as_ref()
            };
            match active_logo {
                Some(pix) => {
                    let pw = pix.width() as f64;
                    let ph = pix.height() as f64;
                    use gtk::gdk::prelude::GdkContextExt;
                    cr.set_source_pixbuf(pix, -pw / 2.0, -ph / 2.0);
                    let _ = cr.paint();
                }
                None => {
                    // fallback gear: ring + spokes, always available
                    cr.set_source_rgba(ar, ag, ab, 0.95);
                    cr.arc(0.0, 0.0, 44.0, 0.0, 2.0 * std::f64::consts::PI);
                    cr.set_line_width(12.0);
                    let _ = cr.stroke();
                    for i in 0..4 {
                        let a = angle * 4.0 + i as f64 * std::f64::consts::PI / 2.0;
                        cr.move_to(0.0, 0.0);
                        cr.line_to(44.0 * a.cos(), 44.0 * a.sin());
                        cr.set_line_width(8.0);
                        let _ = cr.stroke();
                    }
                }
            }
            let _ = cr.restore();
            gtk::glib::Propagation::Proceed
        });
    }

    // Logo animation: redraw on the frame clock while the home view is mapped.
    // The fixed 240 fps ceiling never throttles a normal display, so this just
    // keeps the logo spinning at the panel's refresh rate.
    {
        let fps_limit = fps_limit.clone();
        let last_tick =
            std::rc::Rc::new(std::cell::RefCell::new(std::time::Instant::now()));
        let accum = std::rc::Rc::new(std::cell::RefCell::new(std::time::Duration::ZERO));
        logo_area.add_tick_callback(move |area, _clock| {
            let fps = fps_limit.get().clamp(1, 240) as f64;
            let interval = std::time::Duration::from_secs_f64(1.0 / fps);
            let now = std::time::Instant::now();
            let delta = {
                let mut lt = last_tick.borrow_mut();
                let d = now.saturating_duration_since(*lt);
                *lt = now;
                d
            };
            let due = {
                let mut acc = accum.borrow_mut();
                *acc = acc.saturating_add(delta);
                if *acc >= interval {
                    *acc = acc.saturating_sub(interval).min(interval);
                    true
                } else {
                    false
                }
            };
            if due {
                area.queue_draw();
            }
            gtk::glib::ControlFlow::Continue
        });
    }

    let css = gtk::CssProvider::new();
    let initial_css = theme_css_og(&initial_theme, initial_og_gui);
    css.load_from_data(initial_css.as_bytes()).expect("rustify css");
    gtk::StyleContext::add_provider_for_screen(
        &gtk::gdk::Screen::default().expect("no default screen"),
        &css,
        gtk::STYLE_PROVIDER_PRIORITY_APPLICATION,
    );

    // bloated-mode sheet, added to the screen only while the toggle is on
    let bloat_css = gtk::CssProvider::new();
    let _ = bloat_css.load_from_data(BLOAT_CSS.as_bytes());

    // refresh the memory readout once per second
    {
        let mem_value = mem_value.clone();
        let mem_bar = mem_bar.clone();
        gtk::glib::timeout_add_seconds_local(1, move || {
            // glib keeps freed arena pages mapped; hand the empty ones back to
            // the kernel so the readout (and the real footprint) stays honest
            #[cfg(target_env = "gnu")]
            unsafe {
                malloc_trim(0);
            }

            // memory: only the pages this process alone holds
            let mb = rustify_private_kb() as f64 / 1024.0;
            mem_value.set_markup(&format!(
                "<span size='large' weight='bold'>{:.1}</span><span size='small'> MB</span>",
                mb
            ));
            mem_bar.set_value(mb.min(MEM_BAR_MAX));

            gtk::glib::ControlFlow::Continue
        });
    }

    // Hidden developer options, revealed by tapping the sidebar tux fifteen
    // times.
    // The first switch lifts the login requirement so search and playback run
    // anonymously; playlists still need an account. The second re-enables the
    // FPS overlay in the sidebar. The third holds 1 GiB of resident memory to
    // exercise the readout.
    let dev_section = gtk::Box::new(gtk::Orientation::Vertical, 8);
    dev_section.set_no_show_all(!initial_no_account);
    dev_section.hide();
    let no_account_switch = gtk::Switch::new();
    no_account_switch.set_active(initial_no_account);
    no_account_switch.set_halign(gtk::Align::End);
    let fps_overlay_switch = gtk::Switch::new();
    fps_overlay_switch.set_halign(gtk::Align::End);
    let mem_test_switch = gtk::Switch::new();
    mem_test_switch.set_halign(gtk::Align::End);
    mem_test_switch.set_tooltip_text(Some("Allocate and hold 1 GiB of memory"));
    let og_gui_switch = gtk::Switch::new();
    og_gui_switch.set_active(initial_og_gui);
    og_gui_switch.set_halign(gtk::Align::End);
    og_gui_switch.set_tooltip_text(Some("Classic square GUI for the Slate theme"));

    // shared handles for the memory test allocation
    let mem_test_hold: Arc<Mutex<Option<Vec<u8>>>> = Arc::new(Mutex::new(None));
    let mem_test_wanted = Arc::new(AtomicBool::new(false));
    let mem_test_pending = Arc::new(AtomicBool::new(false));

    {
        let dev_head = gtk::Label::new(None);
        dev_head.set_markup("<span size='x-small' weight='bold' alpha='50%'>DEVELOPER OPTIONS</span>");
        dev_head.set_xalign(0.0);
        let no_account_label = gtk::Label::new(Some("No account requiry"));
        no_account_label.set_xalign(0.0);
        let no_account_row = gtk::Box::new(gtk::Orientation::Horizontal, 8);
        no_account_row.pack_start(&no_account_label, true, true, 0);
        no_account_row.pack_end(&no_account_switch, false, false, 0);
        let fps_overlay_label = gtk::Label::new(Some("FPS overlay"));
        fps_overlay_label.set_xalign(0.0);
        let fps_overlay_row = gtk::Box::new(gtk::Orientation::Horizontal, 8);
        fps_overlay_row.pack_start(&fps_overlay_label, true, true, 0);
        fps_overlay_row.pack_end(&fps_overlay_switch, false, false, 0);
        let mem_test_label = gtk::Label::new(Some("Memory test (1 GB)"));
        mem_test_label.set_xalign(0.0);
        let mem_test_row = gtk::Box::new(gtk::Orientation::Horizontal, 8);
        mem_test_row.pack_start(&mem_test_label, true, true, 0);
        mem_test_row.pack_end(&mem_test_switch, false, false, 0);
        let og_gui_label = gtk::Label::new(Some("OG GUI"));
        og_gui_label.set_xalign(0.0);
        let og_gui_row = gtk::Box::new(gtk::Orientation::Horizontal, 8);
        og_gui_row.pack_start(&og_gui_label, true, true, 0);
        og_gui_row.pack_end(&og_gui_switch, false, false, 0);
        dev_section.pack_start(&dev_head, false, false, 0);
        dev_section.pack_start(&no_account_row, false, false, 0);
        dev_section.pack_start(&fps_overlay_row, false, false, 0);
        dev_section.pack_start(&mem_test_row, false, false, 0);
        dev_section.pack_start(&og_gui_row, false, false, 0);
        {
            let state_dev = state.clone();
            let results_dev = results_stack.clone();
            no_account_switch.connect_active_notify(move |sw| {
                if let Ok(mut st) = state_dev.lock() {
                    st.no_account = sw.is_active();
                }
                if sw.is_active() {
                    results_dev.set_visible_child_name("results");
                }
            });
        }
        {
            let fps_section = fps_section.clone();
            fps_overlay_switch.connect_active_notify(move |sw| {
                if sw.is_active() {
                    fps_section.set_no_show_all(false);
                    fps_section.show_all();
                } else {
                    fps_section.hide();
                    fps_section.set_no_show_all(true);
                }
            });
        }
        {
            let hold = mem_test_hold.clone();
            let wanted = mem_test_wanted.clone();
            let pending = mem_test_pending.clone();
            mem_test_switch.connect_active_notify(move |sw| {
                if sw.is_active() {
                    wanted.store(true, Ordering::SeqCst);
                    if pending.swap(true, Ordering::SeqCst) {
                        return;
                    }
                    let hold = hold.clone();
                    let wanted = wanted.clone();
                    let pending = pending.clone();
                    std::thread::spawn(move || {
                        const SIZE: usize = 1024 * 1024 * 1024;
                        let mut buf = vec![0u8; SIZE];
                        // touch one byte per page so the allocation becomes
                        // real resident memory instead of lazy zero pages
                        let mut i = 0;
                        while i < SIZE {
                            buf[i] = 0xA5;
                            i += 4096;
                        }
                        if wanted.load(Ordering::SeqCst) {
                            if let Ok(mut slot) = hold.lock() {
                                *slot = Some(buf);
                            }
                        }
                        pending.store(false, Ordering::SeqCst);
                    });
                } else {
                    wanted.store(false, Ordering::SeqCst);
                    if let Ok(mut slot) = hold.lock() {
                        *slot = None;
                    }
                }
            });
        }
        {
            let css = css.clone();
            let state_og = state.clone();
            let apply_transparency = apply_transparency.clone();
            og_gui_switch.connect_active_notify(move |sw| {
                let on = sw.is_active();
                let theme = if let Ok(mut st) = state_og.lock() {
                    st.og_gui = on;
                    st.theme.clone()
                } else {
                    String::from("rustify")
                };
                apply_transparency(!on && theme == "transparent");
                css.load_from_data(theme_css_og(&theme, on).as_bytes())
                    .expect("theme css");
            });
        }
    }

    // FPS cap entry: applies to the render ticks and persists in settings
    {
        let fps_limit = fps_limit.clone();
        let fps_cap_label = fps_cap_label.clone();
        let state_fps = state.clone();
        fps_entry.connect_activate(move |entry| {
            if let Ok(v) = entry.text().trim().parse::<u64>() {
                let v = v.clamp(1, 240);
                fps_limit.set(v);
                entry.set_text(&v.to_string());
                fps_cap_label.set_markup(&format!(
                    "<span size='x-small' alpha='60%'>cap {}</span>",
                    v
                ));
                if let Ok(mut st) = state_fps.lock() {
                    st.fps_limit = v;
                }
                persist_settings(&state_fps);
            }
        });
    }

    // home screen: wordmark + centered search bar; searching flips back to
    // the main view, where the results are listed
    let home_view = gtk::Box::new(gtk::Orientation::Vertical, 0);
    home_view.style_context().add_class("rustify-hero");

    let home_center = gtk::Box::new(gtk::Orientation::Vertical, 6);
    home_center.set_halign(gtk::Align::Center);
    home_center.set_valign(gtk::Align::Center);

    let probe = gtk::Label::new(None);
    let probe_layout = probe.create_pango_layout(Some("Rustify"));
    probe_layout.set_markup("<span size='34pt' weight='heavy'>Rustify</span>");
    let (wm_w, wm_h) = probe_layout.pixel_size();

    let home_wordmark = gtk::DrawingArea::new();
    home_wordmark.set_size_request(wm_w + 64, wm_h + 22);
    home_wordmark.set_halign(gtk::Align::Center);

    let tilt_target = Rc::new(Cell::new(0.0f64));
    let tilt_cur = Rc::new(Cell::new(0.0f64));
    let sink_target = Rc::new(Cell::new(0.0f64));
    let sink_cur = Rc::new(Cell::new(0.0f64));
    let press_target = Rc::new(Cell::new(0.0f64));
    let press_cur = Rc::new(Cell::new(0.0f64));

    home_wordmark.add_events(
        gtk::gdk::EventMask::POINTER_MOTION_MASK
            | gtk::gdk::EventMask::ENTER_NOTIFY_MASK
            | gtk::gdk::EventMask::LEAVE_NOTIFY_MASK,
    );
    {
        let target = tilt_target.clone();
        let sink = sink_target.clone();
        let press = press_target.clone();
        home_wordmark.connect_motion_notify_event(move |area, ev| {
            let (x, y) = ev.position();
            let w = area.allocated_width().max(1) as f64;
            let h = area.allocated_height().max(1) as f64;
            target.set(((x - w * 0.5) / (w * 0.5)).clamp(-1.0, 1.0));
            sink.set(((y - h * 0.5) / (h * 0.5)).clamp(-1.0, 1.0));
            press.set(1.0);
            gtk::glib::Propagation::Proceed
        });
    }
    {
        let press = press_target.clone();
        home_wordmark.connect_enter_notify_event(move |_, _| {
            press.set(1.0);
            gtk::glib::Propagation::Proceed
        });
    }
    {
        let press = press_target.clone();
        home_wordmark.connect_leave_notify_event(move |_, _| {
            press.set(0.0);
            gtk::glib::Propagation::Proceed
        });
    }

    let began = std::time::Instant::now();
    {
        let area = home_wordmark.clone();
        let target = tilt_target.clone();
        let cur = tilt_cur.clone();
        let st = sink_target.clone();
        let sc = sink_cur.clone();
        let pt = press_target.clone();
        let pc = press_cur.clone();
        gtk::glib::timeout_add_local(Duration::from_millis(16), move || {
            if !area.is_mapped() {
                return gtk::glib::ControlFlow::Continue;
            }
            cur.set(cur.get() + (target.get() - cur.get()) * 0.20);
            sc.set(sc.get() + (st.get() - sc.get()) * 0.20);
            pc.set(pc.get() + (pt.get() - pc.get()) * 0.14);
            area.queue_draw();
            gtk::glib::ControlFlow::Continue
        });
    }
    {
        let cur = tilt_cur.clone();
        let sc = sink_cur.clone();
        let pc = press_cur.clone();
        home_wordmark.connect_draw(move |area, cr| {
            let base = area.style_context().color(gtk::StateFlags::NORMAL);
            let lum = 0.2126 * base.red() as f64
                + 0.7152 * base.green() as f64
                + 0.0722 * base.blue() as f64;
            let (dr, dg, db, br, bg, bb) = if lum < 0.5 {
                (
                    base.red() as f64,
                    base.green() as f64,
                    base.blue() as f64,
                    0.82,
                    0.82,
                    0.82,
                )
            } else {
                (
                    base.red() as f64 * 0.78,
                    base.green() as f64 * 0.78,
                    base.blue() as f64 * 0.78,
                    base.red() as f64,
                    base.green() as f64,
                    base.blue() as f64,
                )
            };
            let cycle = 4.2f64;
            let sweep = 1.7f64;
            let p = began.elapsed().as_secs_f64() % cycle;
            let phase = if p < sweep { -0.22 + (p / sweep) * 1.44 } else { -9.0 };
            let text = "Rustify";
            let n = text.chars().count() as f64;
            let mut markup = String::with_capacity(320);
            markup.push_str("<span size='34pt' weight='heavy'>");
            for (i, ch) in text.chars().enumerate() {
                let ci = (i as f64 + 0.5) / n;
                let k = if phase > -5.0 {
                    let d = (ci - phase) / 0.17;
                    (-(d * d)).exp() * 0.95
                } else {
                    0.0
                };
                let r = (dr * (1.0 - k) + br * k) * 255.0;
                let g = (dg * (1.0 - k) + bg * k) * 255.0;
                let b = (db * (1.0 - k) + bb * k) * 255.0;
                markup.push_str(&format!(
                    "<span foreground='#{:02x}{:02x}{:02x}'>{}</span>",
                    r.clamp(0.0, 255.0) as u8,
                    g.clamp(0.0, 255.0) as u8,
                    b.clamp(0.0, 255.0) as u8,
                    ch
                ));
            }
            markup.push_str("</span>");

            let layout = area.create_pango_layout(Some("Rustify"));
            layout.set_markup(&markup);
            let (tw, th) = layout.pixel_size();
            let (tw, th) = (tw.max(1), th.max(1));
            let pad = 8i32;
            let sw_i = tw + pad * 2;
            let sh_i = th + pad * 2;
            let sw = sw_i as usize;
            let sh = sh_i as usize;
            let mut source = gtk::cairo::ImageSurface::create(
                gtk::cairo::Format::ARgb32,
                sw_i,
                sh_i,
            )
            .expect("wordmark surface");
            {
                let scr = gtk::cairo::Context::new(&source).expect("wordmark ctx");
                scr.move_to(pad as f64, pad as f64);
                unsafe {
                    pango_cairo_show_layout(scr.to_raw_none(), layout.to_glib_none().0);
                }
            }
            source.flush();

            let w = area.allocated_width() as f64;
            let h = area.allocated_height() as f64;
            let nx = cur.get();
            let ny = sc.get();
            let press = pc.get();
            let ox = (w - sw_i as f64) * 0.5 + nx * 2.0 * press;
            let oy = (h - sh_i as f64) * 0.5 + ny * 2.0 * press;

            if press < 0.003 {
                let _ = cr.set_source_surface(&source, ox, oy);
                let _ = cr.paint();
                return gtk::glib::Propagation::Proceed;
            }

            let sstride = source.stride() as usize;
            let mut src = vec![0u8; sw * sh * 4];
            {
                let sdata = source.data().expect("wordmark read");
                let row = sw * 4;
                for y in 0..sh {
                    src[y * row..(y + 1) * row]
                        .copy_from_slice(&sdata[y * sstride..y * sstride + row]);
                }
            }

            let mut out = gtk::cairo::ImageSurface::create(
                gtk::cairo::Format::ARgb32,
                sw_i,
                sh_i,
            )
            .expect("wordmark out");
            let ostride = out.stride() as usize;
            {
                let mut odata = out.data().expect("wordmark write");
                let cxp = pad as f64 + (nx * 0.5 + 0.5) * tw as f64;
                let cyp = pad as f64 + (ny * 0.5 + 0.5) * th as f64;
                let sigma = th as f64 * 0.28;
                let rb = th as f64 * 0.72;
                let sigb = th as f64 * 0.46;
                let dent = 0.42 * press;
                let bulge = 0.14 * press;
                let row = sw * 4;
                for py in 0..sh {
                    let dy = py as f64 + 0.5 - cyp;
                    let drow = py * ostride;
                    for px in 0..sw {
                        let dx = px as f64 + 0.5 - cxp;
                        let r = (dx * dx + dy * dy).sqrt();
                        let q1 = r / sigma;
                        let q2 = (r - rb) / sigb;
                        let scale = (1.0 - dent * (-(q1 * q1)).exp()
                            + bulge * (-(q2 * q2)).exp())
                        .clamp(0.35, 2.0);
                        let sxf = cxp + dx / scale - 0.5;
                        let syf = cyp + dy / scale - 0.5;
                        let x0 = sxf.floor() as i64;
                        let y0 = syf.floor() as i64;
                        let tx = sxf - x0 as f64;
                        let ty = syf - y0 as f64;
                        let mut px4 = [0u8; 4];
                        if x0 >= 0 && y0 >= 0 && x0 + 1 < sw as i64 && y0 + 1 < sh as i64 {
                            let i00 = (y0 as usize * sw + x0 as usize) * 4;
                            let i10 = i00 + 4;
                            let i01 = i00 + row;
                            let i11 = i01 + 4;
                            let w00 = (1.0 - tx) * (1.0 - ty);
                            let w10 = tx * (1.0 - ty);
                            let w01 = (1.0 - tx) * ty;
                            let w11 = tx * ty;
                            for c in 0..4 {
                                let v = src[i00 + c] as f64 * w00
                                    + src[i10 + c] as f64 * w10
                                    + src[i01 + c] as f64 * w01
                                    + src[i11 + c] as f64 * w11;
                                px4[c] = v.clamp(0.0, 255.0) as u8;
                            }
                        }
                        let d = drow + px * 4;
                        odata[d..d + 4].copy_from_slice(&px4);
                    }
                }
            }

            let _ = cr.set_source_surface(&out, ox, oy);
            let _ = cr.paint();
            gtk::glib::Propagation::Proceed
        });
    }
    let home_tagline = gtk::Label::new(None);
    home_tagline.set_markup(
        "<span size='11pt' alpha='55%'>Spotify, but without the bloat slop o algo.</span>",
    );

    let home_badge = gtk::Box::new(gtk::Orientation::Horizontal, 0);
    home_badge.style_context().add_class("rustify-pill");
    let home_badge_label = gtk::Label::new(None);
    home_badge_label.set_markup("<span size='x-small'>NATIVE · FAST · RUST</span>");
    home_badge.set_center_widget(Some(&home_badge_label));

    let home_search = gtk::SearchEntry::new();
    home_search.set_placeholder_text(Some("Search songs, artists, albums…"));
    home_search.set_width_request(540);
    home_search.style_context().add_class("rustify-hero-search");
    home_search.set_margin_top(8);

    home_center.pack_start(&logo_area, false, false, 0);
    home_center.pack_start(&home_wordmark, false, false, 0);
    home_center.pack_start(&home_tagline, false, false, 0);
    home_center.pack_start(&home_badge, false, false, 6);
    home_center.pack_start(&home_search, false, false, 4);

    // auth: Login opens the webview sign-in. Once a session exists it is
    // replaced by Wipe User Data, which clears every byte the app persisted.
    let login_btn = gtk::Button::with_label("Login");
    login_btn.style_context().add_class("suggested-action");
    login_btn.style_context().add_class("rustify-login");
    let logout_btn = gtk::Button::with_label("Log Out");
    logout_btn.set_tooltip_text(Some("Sign out of YouTube Music"));
    let lucky_btn = gtk::Button::with_label("I'm Feeling Lucky");
    lucky_btn.style_context().add_class("suggested-action");
    lucky_btn.set_tooltip_text(Some("Play a random song"));
    let auth_row = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    auth_row.set_margin_top(18);
    auth_row.set_halign(gtk::Align::Fill);
    auth_row.pack_start(&login_btn, false, false, 0);
    auth_row.pack_start(&logout_btn, false, false, 0);
    auth_row.pack_end(&lucky_btn, false, false, 0);
    home_center.pack_start(&auth_row, false, false, 0);

    // The hero fills the first viewport; the recently-played carousel sits
    // underneath, so scrolling down reveals it. Horizontal scrolls on the
    // carousel itself move through the cards.
    let home_hero = gtk::Box::new(gtk::Orientation::Vertical, 0);
    home_hero.set_valign(gtk::Align::Center);
    home_hero.set_size_request(-1, 560);
    home_hero.pack_start(&home_center, false, false, 0);

    let recent_section = gtk::Box::new(gtk::Orientation::Vertical, 10);
    recent_section.set_margin_start(34);
    recent_section.set_margin_end(34);
    recent_section.set_margin_top(10);
    recent_section.set_margin_bottom(30);

    let recent_heading = gtk::Label::new(None);
    recent_heading.set_markup("<span size='large' weight='bold'>Recently played</span>");
    recent_heading.set_xalign(0.0);

    let stage_a = gtk::Box::new(gtk::Orientation::Horizontal, 16);
    let stage_b = gtk::Box::new(gtk::Orientation::Horizontal, 16);
    for stage in [&stage_a, &stage_b] {
        stage.set_halign(gtk::Align::Center);
        stage.set_valign(gtk::Align::Center);
    }
    let flow_pages: Rc<[gtk::Box; 2]> = Rc::new([stage_a, stage_b]);

    let flow_fixed = gtk::Fixed::new();
    flow_fixed.set_halign(gtk::Align::Center);
    flow_fixed.set_valign(gtk::Align::Center);
    flow_fixed.put(&flow_pages[0], 0, 0);
    flow_fixed.put(&flow_pages[1], 0, 0);
    flow_pages[1].set_no_show_all(true);
    flow_pages[1].hide();

    recent_section.pack_start(&recent_heading, false, false, 0);
    recent_section.pack_start(&flow_fixed, false, false, 0);

    let flow_center = Rc::new(Cell::new(0usize));
    let flow_scroll = Rc::new(Cell::new(0.0f64));
    let flow_live = Rc::new(Cell::new(0usize));
    let flow_anim = Rc::new(Cell::new(0u64));
    let flow_hit: Rc<std::cell::RefCell<Option<gtk::Widget>>> =
        Rc::new(std::cell::RefCell::new(None));

    let home_content = gtk::Box::new(gtk::Orientation::Vertical, 0);
    home_content.pack_start(&home_hero, false, false, 0);
    home_content.pack_start(&recent_section, false, false, 0);

    let home_scroll = gtk::ScrolledWindow::builder()
        .hscrollbar_policy(gtk::PolicyType::Never)
        .vscrollbar_policy(gtk::PolicyType::Automatic)
        .build();
    home_scroll.set_vexpand(true);
    home_scroll.add(&home_content);
    home_view.pack_start(&home_scroll, true, true, 0);

    flow_build(
        &flow_pages[0],
        &flow_fixed,
        &flow_pages,
        &flow_live,
        &flow_anim,
        &recent_section,
        &flow_center,
        &flow_scroll,
        &flow_hit,
        &tx,
    );

    {
        let hit_c = flow_hit.clone();
        let fixed_c = flow_fixed.clone();
        let pages_c = flow_pages.clone();
        let live_c = flow_live.clone();
        let anim_c = flow_anim.clone();
        let section_c = recent_section.clone();
        let center_c = flow_center.clone();
        let scroll_c = flow_scroll.clone();
        let tx_c = tx.clone();
        let sw_c = home_scroll.clone();
        home_scroll.add_events(
            gtk::gdk::EventMask::SCROLL_MASK | gtk::gdk::EventMask::SMOOTH_SCROLL_MASK,
        );
        home_scroll.connect_scroll_event(move |_, ev| {
            let within = match hit_c.borrow().as_ref() {
                Some(card) => match card.translate_coordinates(&sw_c, 0, 0) {
                    Some((cx, cy)) => {
                        let (x, y) = ev.position();
                        x >= cx as f64
                            && y >= cy as f64
                            && x < (cx + card.allocated_width()) as f64
                            && y < (cy + card.allocated_height()) as f64
                    }
                    None => false,
                },
                None => false,
            };
            if !within {
                return gtk::glib::Propagation::Proceed;
            }
            let n = load_history().len();
            if n == 0 {
                return gtk::glib::Propagation::Proceed;
            }
            let cur = center_c.get();
            let mut step = 0i32;
            match ev.direction() {
                gtk::gdk::ScrollDirection::Up | gtk::gdk::ScrollDirection::Left => step = -1,
                gtk::gdk::ScrollDirection::Down | gtk::gdk::ScrollDirection::Right => step = 1,
                gtk::gdk::ScrollDirection::Smooth => {
                    let (_, dy) = ev.delta();
                    let acc = scroll_c.get() + dy;
                    if acc <= -30.0 {
                        scroll_c.set(0.0);
                        step = -1;
                    } else if acc >= 30.0 {
                        scroll_c.set(0.0);
                        step = 1;
                    } else {
                        scroll_c.set(acc);
                    }
                }
                _ => {}
            }
            if step != 0 {
                let next = (cur as i32 + step).clamp(0, n as i32 - 1) as usize;
                if next != cur {
                    flow_show(
                        &fixed_c, &pages_c, &live_c, &anim_c, &section_c, &center_c,
                        &scroll_c, &hit_c, &tx_c, next, step,
                    );
                }
            }
            gtk::glib::Propagation::Stop
        });
    }

    // OG GUI home: strip it back to the logo and the search field only
    {
        let wordmark = home_wordmark.clone();
        let tagline = home_tagline.clone();
        let badge = home_badge.clone();
        let auth = auth_row.clone();
        let np_title = title.clone();
        let np_artist = artist.clone();
        let brand = brand.clone();
        let mem = mem_section.clone();
        let player = bottom.clone();
        let apply = move |og: bool| {
            wordmark.set_no_show_all(og);
            wordmark.set_visible(!og);
            tagline.set_no_show_all(og);
            tagline.set_visible(!og);
            badge.set_no_show_all(og);
            badge.set_visible(!og);
            auth.set_no_show_all(og);
            auth.set_visible(!og);
            np_title.set_no_show_all(og);
            np_title.set_visible(!og);
            np_artist.set_no_show_all(og);
            np_artist.set_visible(!og);
            brand.set_no_show_all(og);
            brand.set_visible(!og);
            mem.set_no_show_all(og);
            mem.set_visible(!og);
            player.set_no_show_all(og);
            player.set_visible(!og);
        };
        apply(initial_og_gui);
        og_gui_switch.connect_active_notify(move |sw| apply(sw.is_active()));
    }

    // playlists view: the user's YouTube Music library playlists
    let playlists_view = gtk::Box::new(gtk::Orientation::Vertical, 0);
    let pl_head = gtk::Label::new(None);
    pl_head.set_markup("<span size='x-large' weight='heavy'>Your playlists</span>");
    pl_head.set_xalign(0.0);
    let pl_head_row = gtk::Box::new(gtk::Orientation::Horizontal, 12);
    pl_head_row.set_margin_start(18);
    pl_head_row.set_margin_end(18);
    pl_head_row.set_margin_top(14);
    pl_head_row.set_margin_bottom(10);
    let pl_back = gtk::Button::from_icon_name(
        Some("go-previous-symbolic"),
        gtk::IconSize::Button,
    );
    let pl_titles = gtk::Box::new(gtk::Orientation::Vertical, 0);
    let pl_sub = gtk::Label::new(None);
    pl_sub.set_markup("<span size='x-small' alpha='50%'>From your YouTube Music library</span>");
    pl_sub.set_xalign(0.0);
    pl_titles.pack_start(&pl_head, false, false, 0);
    pl_titles.pack_start(&pl_sub, false, false, 0);
    pl_head_row.pack_start(&pl_back, false, false, 0);
    pl_head_row.pack_start(&pl_titles, false, false, 0);
    let pl_add = gtk::Button::with_label("New playlist");
    pl_add.style_context().add_class("suggested-action");
    pl_add.set_valign(gtk::Align::Center);
    pl_add.set_tooltip_text(Some("Create a playlist on YouTube Music"));
    pl_head_row.pack_end(&pl_add, false, false, 0);
    {
        let tx_add = tx.clone();
        let win_add = win.clone();
        pl_add.connect_clicked(move |_| {
            show_create_playlist_dialog(&win_add, tx_add.clone());
        });
    }
    let pl_list = gtk::ListBox::new();
    pl_list.set_selection_mode(gtk::SelectionMode::None);
    pl_list.set_can_focus(false);
    let pl_scroller = gtk::ScrolledWindow::builder().build();
    pl_scroller.set_policy(gtk::PolicyType::Never, gtk::PolicyType::Automatic);
    pl_scroller.set_vexpand(true);
    pl_scroller.add(&pl_list);
    playlists_view.pack_start(&pl_head_row, false, false, 0);
    playlists_view.pack_start(
        &gtk::Separator::new(gtk::Orientation::Horizontal),
        false,
        false,
        0,
    );
    playlists_view.pack_start(&pl_scroller, true, true, 0);

    // imports view: mp3 files dropped into the project's imports folder
    let imports_view = gtk::Box::new(gtk::Orientation::Vertical, 0);
    let imp_head = gtk::Label::new(None);
    imp_head.set_markup("<span size='x-large' weight='heavy'>Imports</span>");
    imp_head.set_xalign(0.0);
    let imp_titles = gtk::Box::new(gtk::Orientation::Vertical, 0);
    let imp_sub = gtk::Label::new(None);
    let imp_dir = imports_dir();
    imp_sub.set_markup(&format!(
        "<span size='x-small' alpha='50%'>MP3s from {}</span>",
        gtk::glib::markup_escape_text(&imp_dir.to_string_lossy())
    ));
    imp_sub.set_xalign(0.0);
    imp_sub.set_ellipsize(gtk::pango::EllipsizeMode::Middle);
    imp_titles.pack_start(&imp_head, false, false, 0);
    imp_titles.pack_start(&imp_sub, false, false, 0);
    let imp_back = gtk::Button::from_icon_name(
        Some("go-previous-symbolic"),
        gtk::IconSize::Button,
    );
    let imp_refresh = gtk::Button::from_icon_name(
        Some("view-refresh-symbolic"),
        gtk::IconSize::Button,
    );
    imp_refresh.set_tooltip_text(Some("Rescan the imports folder"));
    let imp_open = gtk::Button::from_icon_name(
        Some("folder-open-symbolic"),
        gtk::IconSize::Button,
    );
    imp_open.set_tooltip_text(Some("Open the imports folder"));
    {
        let open_dir = imp_dir.clone();
        imp_open.connect_clicked(move |_| {
            let uri = gtk::gio::File::for_path(&open_dir).uri();
            let _ = gtk::gio::AppInfo::launch_default_for_uri(
                &uri,
                None::<&gtk::gio::AppLaunchContext>,
            );
        });
    }
    let imp_head_row = gtk::Box::new(gtk::Orientation::Horizontal, 12);
    imp_head_row.set_margin_start(18);
    imp_head_row.set_margin_end(18);
    imp_head_row.set_margin_top(14);
    imp_head_row.set_margin_bottom(10);
    imp_head_row.pack_start(&imp_back, false, false, 0);
    imp_head_row.pack_start(&imp_titles, true, true, 0);
    imp_head_row.pack_end(&imp_refresh, false, false, 0);
    imp_head_row.pack_end(&imp_open, false, false, 0);
    {
        let tx_refresh = tx.clone();
        imp_refresh.connect_clicked(move |_| {
            let _ = tx_refresh.send(Cmd::ScanImports);
        });
    }
    let imp_list = gtk::ListBox::new();
    imp_list.set_selection_mode(gtk::SelectionMode::Single);
    imp_list.set_can_focus(false);
    {
        imp_list.drag_dest_set(
            gtk::DestDefaults::ALL,
            &[gtk::TargetEntry::new(
                IMPORT_DRAG_TARGET,
                gtk::TargetFlags::SAME_APP,
                0,
            )],
            gtk::gdk::DragAction::MOVE,
        );
        let drop_state = state.clone();
        imp_list.connect_drag_drop(|list, ctx, _x, _y, time| {
            let atom = gtk::gdk::Atom::intern(IMPORT_DRAG_TARGET);
            list.drag_get_data(ctx, &atom, time);
            true
        });
        imp_list.connect_drag_data_received(move |list, _ctx, _x, y, data, _info, _time| {
            if let Some(text) = data.text() {
                let id = text.as_str();
                reorder_import_row(list, id, y);
                persist_import_order(list, &drop_state);
            }
        });
    }
    let imp_scroller = gtk::ScrolledWindow::builder().build();
    imp_scroller.set_policy(gtk::PolicyType::Never, gtk::PolicyType::Automatic);
    imp_scroller.set_vexpand(true);
    imp_scroller.add(&imp_list);
    let imp_empty = gtk::Box::new(gtk::Orientation::Vertical, 6);
    imp_empty.set_valign(gtk::Align::Center);
    imp_empty.set_halign(gtk::Align::Center);
    let imp_empty_title = gtk::Label::new(None);
    imp_empty_title.set_markup("<span size='large' weight='bold'>No imports yet</span>");
    let imp_empty_sub = gtk::Label::new(None);
    imp_empty_sub.set_markup(
        "<span alpha='60%'>Put audio files (mp3) in the imports folder</span>",
    );
    imp_empty.pack_start(&imp_empty_title, false, false, 0);
    imp_empty.pack_start(&imp_empty_sub, false, false, 0);
    let imp_stack = gtk::Stack::new();
    imp_stack.add_named(&imp_scroller, "list");
    imp_stack.add_named(&imp_empty, "empty");
    imp_stack.set_visible_child_name("empty");
    imports_view.pack_start(&imp_head_row, false, false, 0);
    imports_view.pack_start(
        &gtk::Separator::new(gtk::Orientation::Horizontal),
        false,
        false,
        0,
    );
    imports_view.pack_start(&imp_stack, true, true, 0);

    // lyrics view: plain-text lyrics for whatever is currently playing
    let lyrics_view = gtk::Box::new(gtk::Orientation::Vertical, 0);
    let ly_head = gtk::Label::new(None);
    ly_head.set_markup("<span size='x-large' weight='heavy'>Lyrics</span>");
    ly_head.set_xalign(0.0);
    let ly_titles = gtk::Box::new(gtk::Orientation::Vertical, 0);
    let ly_sub = gtk::Label::new(None);
    ly_sub.set_markup("<span size='x-small' alpha='50%'>From Genius</span>");
    ly_sub.set_xalign(0.0);
    ly_sub.set_ellipsize(gtk::pango::EllipsizeMode::End);
    ly_titles.pack_start(&ly_head, false, false, 0);
    ly_titles.pack_start(&ly_sub, false, false, 0);
    let ly_back = gtk::Button::from_icon_name(
        Some("go-previous-symbolic"),
        gtk::IconSize::Button,
    );
    let ly_head_row = gtk::Box::new(gtk::Orientation::Horizontal, 12);
    ly_head_row.set_margin_start(18);
    ly_head_row.set_margin_end(18);
    ly_head_row.set_margin_top(14);
    ly_head_row.set_margin_bottom(10);
    ly_head_row.pack_start(&ly_back, false, false, 0);
    ly_head_row.pack_start(&ly_titles, true, true, 0);
    let miniplayer = build_miniplayer(&win, tx.clone());
    let ly_mini = gtk::Button::from_icon_name(
        Some("window-new-symbolic"),
        gtk::IconSize::Button,
    );
    ly_mini.style_context().add_class("flat");
    ly_mini.set_tooltip_text(Some("Miniplayer"));
    {
        let mini = miniplayer.clone();
        ly_mini.connect_clicked(move |_| mini.toggle());
    }
    ly_head_row.pack_end(&ly_mini, false, false, 0);
    let ly_box = gtk::Box::new(gtk::Orientation::Vertical, 0);
    ly_box.style_context().add_class("rustify-lyrics-body");
    ly_box.set_margin_start(18);
    ly_box.set_margin_end(18);
    ly_box.set_margin_top(6);
    ly_box.set_margin_bottom(16);
    ly_box.set_hexpand(true);
    let ly_label = gtk::Label::new(Some("Nothing playing."));
    ly_label.set_xalign(0.5);
    ly_label.set_yalign(0.0);
    ly_label.set_justify(gtk::Justification::Center);
    ly_label.set_line_wrap(true);
    ly_label.set_line_wrap_mode(gtk::pango::WrapMode::WordChar);
    ly_label.set_selectable(false);
    ly_label.set_valign(gtk::Align::Start);
    ly_label.set_hexpand(true);
    ly_label.style_context().add_class("rustify-lyrics");
    // plain lyrics have no timestamps, so derive a position from how far down
    // the click landed (the same fraction the guessed scroll uses)
    let ly_event = gtk::EventBox::new();
    ly_event.set_halign(gtk::Align::Fill);
    ly_event.set_hexpand(true);
    ly_event.add(&ly_label);
    {
        let click_state = state.clone();
        let click_tx = tx.clone();
        let click_event = ly_event.clone();
        ly_event.connect_button_press_event(move |_, ev| {
            if ev.button() != 1 {
                return gtk::glib::Propagation::Proceed;
            }
            let duration = click_state.lock().map(|s| s.duration_ms).unwrap_or(0);
            let height = click_event.allocation().height() as f64;
            if duration > 0 && height > 0.0 {
                let frac = (ev.position().1 / height).clamp(0.0, 1.0);
                let _ = click_tx.send(Cmd::Seek(frac));
            }
            gtk::glib::Propagation::Stop
        });
    }
    ly_box.pack_start(&ly_event, false, false, 0);
    // synced lyrics are one label per line so the current one can be
    // highlighted and scrolled into view as the song plays
    let ly_lines = gtk::Box::new(gtk::Orientation::Vertical, 8);
    ly_lines.set_halign(gtk::Align::Fill);
    ly_lines.set_valign(gtk::Align::Start);
    ly_lines.set_hexpand(true);
    ly_lines.hide();
    ly_box.pack_start(&ly_lines, false, false, 0);
    let ly_scroller = gtk::ScrolledWindow::builder().build();
    ly_scroller.set_policy(gtk::PolicyType::Never, gtk::PolicyType::Automatic);
    ly_scroller.set_vexpand(true);
    ly_scroller.add(&ly_box);
    lyrics_view.pack_start(&ly_head_row, false, false, 0);
    lyrics_view.pack_start(
        &gtk::Separator::new(gtk::Orientation::Horizontal),
        false,
        false,
        0,
    );
    lyrics_view.pack_start(&ly_scroller, true, true, 0);

    // settings view: replaces whatever tab is open while the cog is active
    let settings_view = gtk::Box::new(gtk::Orientation::Vertical, 0);
    let set_head = gtk::Label::new(None);
    set_head.set_markup("<span size='x-large' weight='heavy'>Settings</span>");
    set_head.set_xalign(0.0);
    let set_head_row = gtk::Box::new(gtk::Orientation::Horizontal, 12);
    set_head_row.set_margin_start(18);
    set_head_row.set_margin_top(14);
    set_head_row.set_margin_bottom(10);
    let set_back = gtk::Button::from_icon_name(
        Some("go-previous-symbolic"),
        gtk::IconSize::Button,
    );
    let set_titles = gtk::Box::new(gtk::Orientation::Vertical, 0);
    let set_sub = gtk::Label::new(None);
    set_sub.set_markup("<span size='x-small' alpha='50%'>change stuff</span>");
    set_sub.set_xalign(0.0);
    set_titles.pack_start(&set_head, false, false, 0);
    set_titles.pack_start(&set_sub, false, false, 0);
    set_head_row.pack_start(&set_back, false, false, 0);
    set_head_row.pack_start(&set_titles, false, false, 0);

    let set_body = gtk::Box::new(gtk::Orientation::Vertical, 8);
    set_body.style_context().add_class("rustify-settings-body");
    set_body.set_margin_top(6);
    set_body.set_margin_bottom(18);
    set_body.set_margin_start(18);
    set_body.set_margin_end(18);

    let sec_search = gtk::Label::new(None);
    sec_search.set_markup("<span size='x-small' weight='bold' alpha='50%'>SEARCH</span>");
    sec_search.set_xalign(0.0);

    let results_label = gtk::Label::new(None);
    results_label.set_markup("<span>Results per search</span>");
    results_label.set_xalign(0.0);
    let results_value = gtk::Label::new(None);
    results_value.set_markup(&format!(
        "<span alpha='60%'>{}</span>",
        initial_search_limit
    ));
    results_value.set_xalign(1.0);
    let results_row = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    results_row.pack_start(&results_label, true, true, 0);
    results_row.pack_end(&results_value, false, false, 0);

    let results_scale = gtk::Scale::with_range(
        gtk::Orientation::Horizontal,
        1.0,
        SEARCH_LIMIT as f64,
        1.0,
    );
    results_scale.set_draw_value(false);
    results_scale.set_digits(0);
    results_scale.set_hexpand(true);
    results_scale.set_value(initial_search_limit as f64);

    let eggs_label = gtk::Label::new(None);
    eggs_label.set_markup("<span>No easter eggs</span>");
    eggs_label.set_xalign(0.0);
    let eggs_switch = gtk::Switch::new();
    eggs_switch.set_active(initial_no_easter);
    eggs_switch.set_halign(gtk::Align::End);
    let eggs_row = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    eggs_row.pack_start(&eggs_label, true, true, 0);
    eggs_row.pack_end(&eggs_switch, false, false, 0);

    set_body.pack_start(&sec_search, false, false, 0);
    set_body.pack_start(&results_row, false, false, 4);
    set_body.pack_start(&results_scale, false, false, 0);
    set_body.pack_start(
        &gtk::Separator::new(gtk::Orientation::Horizontal),
        false,
        false,
        8,
    );
    set_body.pack_start(&eggs_row, false, false, 0);

    set_body.pack_start(
        &gtk::Separator::new(gtk::Orientation::Horizontal),
        false,
        false,
        8,
    );

    let sec_music = gtk::Label::new(None);
    sec_music.set_markup("<span size='x-small' weight='bold' alpha='50%'>MUSIC</span>");
    sec_music.set_xalign(0.0);

    let quality_label = gtk::Label::new(None);
    quality_label.set_markup("<span>Audio quality</span>");
    quality_label.set_xalign(0.0);
    let quality_combo = gtk::ComboBoxText::new();
    for (id, name) in QUALITY_IDS.iter().zip(QUALITY_NAMES.iter()) {
        quality_combo.append(Some(id), name);
    }
    quality_combo.set_active_id(Some(initial_quality.as_str()));
    quality_combo.set_valign(gtk::Align::Center);
    let quality_row = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    quality_row.pack_start(&quality_label, true, true, 0);
    quality_row.pack_end(&quality_combo, false, false, 0);

    let ears_label = gtk::Label::new(None);
    ears_label.set_markup("<span>Sensitive ears</span>");
    ears_label.set_xalign(0.0);
    let ears_switch = gtk::Switch::new();
    ears_switch.set_active(initial_sensitive_ears);
    ears_switch.set_halign(gtk::Align::End);
    ears_switch.set_tooltip_text(Some("Play everything at 15% volume and hide the volume slider"));
    let ears_row = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    ears_row.pack_start(&ears_label, true, true, 0);
    ears_row.pack_end(&ears_switch, false, false, 0);

    set_body.pack_start(&sec_music, false, false, 0);
    set_body.pack_start(&quality_row, false, false, 4);
    set_body.pack_start(&ears_row, false, false, 4);
    set_body.pack_start(
        &gtk::Separator::new(gtk::Orientation::Horizontal),
        false,
        false,
        8,
    );
    {
        let state_q = state.clone();
        quality_combo.connect_changed(move |combo| {
            if let Some(id) = combo.active_id() {
                let q = id.to_string();
                if let Ok(mut st) = state_q.lock() {
                    st.quality = q;
                }
                persist_settings(&state_q);
            }
        });
    }
    {
        let state_e = state.clone();
        let vol_row_e = vol_row.clone();
        let tx_e = tx.clone();
        ears_switch.connect_active_notify(move |sw| {
            let on = sw.is_active();
            if let Ok(mut st) = state_e.lock() {
                st.sensitive_ears = on;
            }
            vol_row_e.set_visible(!on);
            let _ = tx_e.send(Cmd::SetSensitiveEars(on));
            persist_settings(&state_e);
        });
    }

    let sec_themes = gtk::Label::new(None);
    sec_themes.set_markup("<span size='x-small' weight='bold' alpha='50%'>THEMES</span>");
    sec_themes.set_xalign(0.0);
    let theme_rustify = gtk::RadioButton::with_label("Rustify");
    let theme_slate = gtk::RadioButton::with_label_from_widget(&theme_rustify, "Slate");
    let theme_mint = gtk::RadioButton::with_label_from_widget(&theme_rustify, "Mint");
    let theme_light = gtk::RadioButton::with_label_from_widget(&theme_rustify, "Light");
    let theme_discord = gtk::RadioButton::with_label_from_widget(&theme_rustify, "Discord");
    match initial_theme.as_str() {
        "mint" => theme_mint.set_active(true),
        "light" => theme_light.set_active(true),
        "discord" => theme_discord.set_active(true),
        "slate" => theme_slate.set_active(true),
        _ => theme_rustify.set_active(true),
    }
    let themes_box = gtk::Box::new(gtk::Orientation::Vertical, 4);
    themes_box.set_halign(gtk::Align::Start);
    themes_box.pack_start(&theme_rustify, false, false, 0);
    themes_box.pack_start(&theme_slate, false, false, 0);
    themes_box.pack_start(&theme_mint, false, false, 0);
    themes_box.pack_start(&theme_light, false, false, 0);
    themes_box.pack_start(&theme_discord, false, false, 0);
    // user themes restored from settings
    {
        let existing = state
            .lock()
            .map(|s| s.custom_themes.clone())
            .unwrap_or_default();
        let mut restored: Option<gtk::RadioButton> = None;
        for custom in &existing {
            let radio = add_custom_theme_row(
                &themes_box,
                &theme_rustify,
                &custom.name,
                &state,
                &css,
                &apply_transparency,
            );
            if custom.name == initial_theme {
                restored = Some(radio.clone());
            }
        }
        if let Some(radio) = restored {
            radio.set_active(true);
        }
    }
    set_body.pack_start(&sec_themes, false, false, 4);
    set_body.pack_start(&themes_box, false, false, 0);

    let add_theme_btn = gtk::Button::with_label("Add theme");
    add_theme_btn.set_halign(gtk::Align::Start);
    add_theme_btn.set_tooltip_text(Some("Create a theme from a colour code"));
    set_body.pack_start(&add_theme_btn, false, false, 4);
    {
        let parent = win.clone();
        let state_add = state.clone();
        let css_add = css.clone();
        let apply_add = apply_transparency.clone();
        let group = theme_rustify.clone();
        let box_add = themes_box.clone();
        let trigger = add_theme_btn.clone();
        add_theme_btn.connect_clicked(move |_| {
            show_add_theme_dialog(
                &parent,
                &state_add,
                &group,
                &box_add,
                &css_add,
                &apply_add,
                &trigger,
            );
        });
    }

    set_body.pack_start(
        &gtk::Separator::new(gtk::Orientation::Horizontal),
        false,
        false,
        8,
    );
    let sec_extra = gtk::Label::new(None);
    sec_extra.set_markup("<span size='x-small' weight='bold' alpha='50%'>EXTRA</span>");
    sec_extra.set_xalign(0.0);
    let wipe_settings_btn = gtk::Button::with_label("Wipe User Data");
    wipe_settings_btn.style_context().add_class("destructive-action");
    wipe_settings_btn.set_tooltip_text(Some(
        "Delete the saved session, webview profile, cached audio and settings",
    ));
    let extra_row = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    extra_row.set_halign(gtk::Align::Start);
    extra_row.pack_start(&wipe_settings_btn, false, false, 0);

    let quiet_label = gtk::Label::new(None);
    quiet_label.set_markup("<span>stop annoying me</span>");
    quiet_label.set_xalign(0.0);
    let quiet_switch = gtk::Switch::new();
    quiet_switch.set_active(initial_quiet);
    quiet_switch.set_halign(gtk::Align::End);
    quiet_switch.set_tooltip_text(Some(
        "Strip the ui to a plain queue rail and one big now-playing card",
    ));
    let quiet_row = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    quiet_row.pack_start(&quiet_label, true, true, 0);
    quiet_row.pack_end(&quiet_switch, false, false, 0);
    {
        let state_q = state.clone();
        quiet_switch.connect_active_notify(move |sw| {
            if let Ok(mut st) = state_q.lock() {
                st.quiet_mode = sw.is_active();
            }
            persist_settings(&state_q);
        });
    }

    set_body.pack_start(&sec_extra, false, false, 4);
    set_body.pack_start(&quiet_row, false, false, 4);
    set_body.pack_start(&extra_row, false, false, 0);

    set_body.pack_start(
        &gtk::Separator::new(gtk::Orientation::Horizontal),
        false,
        false,
        8,
    );
    set_body.pack_start(&dev_section, false, false, 0);

    // radio toggles swap the stylesheet live and persist the choice; while the
    // OG GUI is on the theme still changes in state but the skin stays slate.
    {
        let css = css.clone();
        let state_theme = state.clone();
        let apply_transparency = apply_transparency.clone();
        theme_rustify.connect_toggled(move |btn| {
            if btn.is_active() {
                let og = state_theme.lock().map(|s| s.og_gui).unwrap_or(false);
                apply_transparency(false);
                css.load_from_data(theme_css_og("rustify", og).as_bytes())
                    .expect("rustify css");
                if let Ok(mut st) = state_theme.lock() {
                    st.theme = "rustify".to_string();
                    st.opaque_theme = "rustify".to_string();
                }
                persist_settings(&state_theme);
            }
        });
    }
    {
        let css = css.clone();
        let state_theme = state.clone();
        let apply_transparency = apply_transparency.clone();
        theme_slate.connect_toggled(move |btn| {
            if btn.is_active() {
                let og = state_theme.lock().map(|s| s.og_gui).unwrap_or(false);
                apply_transparency(false);
                css.load_from_data(theme_css_og("slate", og).as_bytes())
                    .expect("slate css");
                if let Ok(mut st) = state_theme.lock() {
                    st.theme = "slate".to_string();
                    st.opaque_theme = "slate".to_string();
                }
                persist_settings(&state_theme);
            }
        });
    }
    {
        let css = css.clone();
        let state_theme = state.clone();
        let apply_transparency = apply_transparency.clone();
        theme_mint.connect_toggled(move |btn| {
            if btn.is_active() {
                let og = state_theme.lock().map(|s| s.og_gui).unwrap_or(false);
                apply_transparency(false);
                css.load_from_data(theme_css_og("mint", og).as_bytes()).expect("mint css");
                if let Ok(mut st) = state_theme.lock() {
                    st.theme = "mint".to_string();
                    st.opaque_theme = "mint".to_string();
                }
                persist_settings(&state_theme);
            }
        });
    }
    {
        let css = css.clone();
        let state_theme = state.clone();
        let apply_transparency = apply_transparency.clone();
        theme_light.connect_toggled(move |btn| {
            if btn.is_active() {
                let og = state_theme.lock().map(|s| s.og_gui).unwrap_or(false);
                apply_transparency(false);
                css.load_from_data(theme_css_og("light", og).as_bytes())
                    .expect("light css");
                if let Ok(mut st) = state_theme.lock() {
                    st.theme = "light".to_string();
                    st.opaque_theme = "light".to_string();
                }
                persist_settings(&state_theme);
            }
        });
    }
    {
        let css = css.clone();
        let state_theme = state.clone();
        let apply_transparency = apply_transparency.clone();
        theme_discord.connect_toggled(move |btn| {
            if btn.is_active() {
                let og = state_theme.lock().map(|s| s.og_gui).unwrap_or(false);
                apply_transparency(false);
                css.load_from_data(theme_css_og("discord", og).as_bytes())
                    .expect("discord css");
                if let Ok(mut st) = state_theme.lock() {
                    st.theme = "discord".to_string();
                    st.opaque_theme = "discord".to_string();
                }
                persist_settings(&state_theme);
            }
        });
    }

    settings_view.pack_start(&set_head_row, false, false, 0);
    let set_scroller = gtk::ScrolledWindow::builder().build();
    set_scroller.set_policy(gtk::PolicyType::Never, gtk::PolicyType::Automatic);
    set_scroller.set_vexpand(true);
    set_scroller.add(&set_body);
    settings_view.pack_start(&set_scroller, true, true, 0);

    // controls write straight into the shared state the worker reads
    {
        let state_settings = state.clone();
        let results_value = results_value.clone();
        results_scale.connect_value_changed(move |s| {
            let n = (s.value().round() as usize).clamp(1, SEARCH_LIMIT);
            results_value.set_markup(&format!("<span alpha='60%'>{n}</span>"));
            if let Ok(mut st) = state_settings.lock() {
                st.search_limit = n;
            }
        });
    }
    {
        let state_settings = state.clone();
        eggs_switch.connect_active_notify(move |sw| {
            if let Ok(mut st) = state_settings.lock() {
                st.no_easter_eggs = sw.is_active();
            }
            if sw.is_active() {
                JUMPY_PLAY.store(false, Ordering::SeqCst);
            }
        });
    }

    // quiet mode: one big square cover, title/artist under it, transport under
    // that, volume pinned to the bottom-right corner. No tabs, no player bar.
    // quiet art is big, so it takes a much gentler tilt than the cards
    let q_tilt_on = Rc::new(Cell::new(initial_quiet_tilt));
    let q_cover = tilt_cover_area(320, 0.06, q_tilt_on.clone());
    let q_title = gtk::Label::new(Some("Nothing playing"));
    q_title.style_context().add_class("rustify-np-title");
    q_title.set_ellipsize(gtk::pango::EllipsizeMode::End);
    q_title.set_max_width_chars(48);
    q_title.set_justify(gtk::Justification::Center);
    q_title.set_xalign(0.5);
    let q_artist = gtk::Label::new(None);
    q_artist.style_context().add_class("rustify-np-artist");
    q_artist.set_ellipsize(gtk::pango::EllipsizeMode::End);
    q_artist.set_max_width_chars(56);
    q_artist.set_justify(gtk::Justification::Center);
    q_artist.set_xalign(0.5);

    let q_prev = gtk::Button::from_icon_name(
        Some("media-skip-backward-symbolic"),
        gtk::IconSize::LargeToolbar,
    );
    q_prev.style_context().add_class("rustify-transport");
    let q_play = gtk::Button::new();
    let q_play_icon = gtk::Image::from_icon_name(
        Some("media-playback-start-symbolic"),
        gtk::IconSize::LargeToolbar,
    );
    q_play.set_image(Some(&q_play_icon));
    q_play.style_context().add_class("rustify-play");
    q_play.set_size_request(64, -1);
    let q_next = gtk::Button::from_icon_name(
        Some("media-skip-forward-symbolic"),
        gtk::IconSize::LargeToolbar,
    );
    q_next.style_context().add_class("rustify-transport");
    let q_repeat = gtk::ToggleButton::new();
    let q_repeat_icon = gtk::Image::from_icon_name(
        Some("media-playlist-repeat-symbolic"),
        gtk::IconSize::LargeToolbar,
    );
    q_repeat.set_image(Some(&q_repeat_icon));
    q_repeat.style_context().add_class("rustify-transport");
    q_repeat.style_context().add_class("rustify-repeat");
    q_repeat.set_tooltip_text(Some("Repeat current track / queue"));
    {
        let state_rep = state.clone();
        q_repeat.connect_toggled(move |btn| {
            if let Ok(mut st) = state_rep.lock() {
                st.repeat = btn.is_active();
            }
        });
    }
    {
        let tx_prev = tx.clone();
        q_prev.connect_clicked(move |_| {
            if LOADING.load(Ordering::SeqCst) {
                let _ = new_play_token();
                let _ = tx_prev.send(Cmd::SkipLoad { forward: false });
            } else {
                let _ = tx_prev.send(Cmd::Prev);
            }
        });
    }
    {
        let tx_next = tx.clone();
        q_next.connect_clicked(move |_| {
            if LOADING.load(Ordering::SeqCst) {
                let _ = new_play_token();
                let _ = tx_next.send(Cmd::SkipLoad { forward: true });
            } else {
                let _ = tx_next.send(Cmd::Next);
            }
        });
    }
    {
        let tx_play = tx.clone();
        q_play.connect_clicked(move |_| {
            let _ = tx_play.send(Cmd::PlayPause);
        });
    }
    let q_controls = gtk::Box::new(gtk::Orientation::Horizontal, 18);
    q_controls.set_halign(gtk::Align::Center);
    q_controls.pack_start(&q_prev, false, false, 0);
    q_controls.pack_start(&q_play, false, false, 0);
    q_controls.pack_start(&q_next, false, false, 0);

    let q_progress = quiet_progress(tx.clone(), state.clone());
    let q_elapsed = gtk::Label::new(None);
    q_elapsed.set_markup("<span size='x-small' alpha='55%'>0:00</span>");
    q_elapsed.set_width_chars(4);
    q_elapsed.set_xalign(0.0);
    q_elapsed.set_valign(gtk::Align::Center);
    let q_total = gtk::Label::new(None);
    q_total.set_markup("<span size='x-small' alpha='55%'>0:00</span>");
    q_total.set_width_chars(4);
    q_total.set_xalign(1.0);
    q_total.set_valign(gtk::Align::Center);
    let q_progress_line = gtk::Box::new(gtk::Orientation::Horizontal, 10);
    q_progress_line.set_halign(gtk::Align::Center);
    q_progress_line.set_valign(gtk::Align::Center);
    q_progress_line.pack_start(&q_elapsed, false, false, 0);
    q_progress_line.pack_start(&q_progress.area, true, true, 0);
    q_progress_line.pack_end(&q_total, false, false, 0);
    q_progress_line.set_no_show_all(!initial_quiet_progress);
    q_progress_line.set_visible(initial_quiet_progress);

    let q_center = gtk::Box::new(gtk::Orientation::Vertical, 10);
    q_center.set_valign(gtk::Align::Center);
    q_center.set_halign(gtk::Align::Center);
    q_center.set_vexpand(true);
    q_center.set_margin_start(24);
    q_center.set_margin_end(24);
    q_center.pack_start(&q_cover, false, false, 0);
    q_center.pack_start(&q_title, false, false, 4);
    q_center.pack_start(&q_artist, false, false, 0);
    q_center.pack_start(&q_controls, false, false, 6);
    q_center.pack_start(&q_progress_line, false, false, 0);

    let q_vol_icon = gtk::Image::from_icon_name(
        Some("audio-volume-medium-symbolic"),
        gtk::IconSize::Button,
    );
    let q_volume = quiet_volume(tx.clone(), 70.0);
    let q_vol_row = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    q_vol_row.pack_start(&q_vol_icon, false, false, 0);
    q_vol_row.pack_start(&q_volume.area, false, false, 0);
    q_vol_row.set_halign(gtk::Align::End);
    let q_footer = gtk::Box::new(gtk::Orientation::Horizontal, 0);
    q_footer.pack_start(&q_repeat, false, false, 0);
    let q_cancel = gtk::Button::from_icon_name(
        Some("window-close-symbolic"),
        gtk::IconSize::Button,
    );
    q_cancel.style_context().add_class("rustify-cancel");
    q_cancel.set_tooltip_text(Some("Cancel loading"));
    q_cancel.set_valign(gtk::Align::Center);
    q_cancel.set_margin_start(6);
    q_cancel.set_no_show_all(true);
    q_cancel.set_visible(false);
    {
        let cancel_load = cancel_load.clone();
        q_cancel.connect_clicked(move |_| cancel_load());
    }
    q_footer.pack_start(&q_cancel, false, false, 0);
    q_footer.pack_end(&q_vol_row, false, false, 0);
    q_repeat.set_margin_start(0);
    q_footer.set_margin_start(10);
    q_footer.set_margin_end(24);
    q_footer.set_margin_bottom(12);

    let q_pl_btn = gtk::Button::from_icon_name(
        Some("view-list-symbolic"),
        gtk::IconSize::Button,
    );
    q_pl_btn.style_context().add_class("flat");
    q_pl_btn.style_context().add_class("rustify-nav");
    q_pl_btn.set_tooltip_text(Some("Show playlists"));
    q_pl_btn.set_halign(gtk::Align::Start);
    {
        let quiet_stack_c = quiet_stack.clone();
        let tx_pl = tx.clone();
        q_pl_btn.connect_clicked(move |_| {
            let cur = quiet_stack_c
                .visible_child_name()
                .map(|s| s.to_string())
                .unwrap_or_default();
            if cur == "playlists" {
                quiet_stack_c.set_visible_child_name("queue");
            } else {
                let _ = tx_pl.send(Cmd::ListPlaylists);
                quiet_stack_c.set_visible_child_name("playlists");
            }
        });
    }
    let q_edit_btn = gtk::Button::from_icon_name(
        Some("document-edit-symbolic"),
        gtk::IconSize::Button,
    );
    q_edit_btn.style_context().add_class("flat");
    q_edit_btn.style_context().add_class("rustify-nav");
    q_edit_btn.set_tooltip_text(Some("Stop annoying me settings"));
    let q_header = gtk::Box::new(gtk::Orientation::Horizontal, 0);
    q_header.set_margin_top(10);
    q_header.set_margin_start(10);
    q_header.set_margin_end(10);
    q_header.pack_start(&q_pl_btn, false, false, 0);
    q_header.pack_end(&q_edit_btn, false, false, 0);

    let q_sheet = gtk::Box::new(gtk::Orientation::Vertical, 0);
    q_sheet.style_context().add_class("rustify-quiet-sheet");
    q_sheet.set_size_request(300, -1);
    q_sheet.set_halign(gtk::Align::Fill);
    q_sheet.set_valign(gtk::Align::Fill);
    q_sheet.set_hexpand(true);
    q_sheet.set_vexpand(true);
    let q_sheet_body = gtk::Box::new(gtk::Orientation::Vertical, 12);
    q_sheet_body.set_margin_start(18);
    q_sheet_body.set_margin_end(18);
    q_sheet_body.set_margin_top(16);
    q_sheet_body.set_margin_bottom(16);
    q_sheet.pack_start(&q_sheet_body, true, true, 0);
    let q_sheet_head = gtk::Label::new(None);
    q_sheet_head.set_markup(
        "<span size='small' weight='bold' alpha='55%'>STOP ANNOYING ME</span>",
    );
    q_sheet_head.set_xalign(0.0);
    let q_sheet_close = gtk::Button::from_icon_name(
        Some("window-close-symbolic"),
        gtk::IconSize::Button,
    );
    q_sheet_close.style_context().add_class("flat");
    q_sheet_close.set_tooltip_text(Some("Close"));
    let q_sheet_top = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    q_sheet_top.pack_start(&q_sheet_head, true, true, 0);
    q_sheet_top.pack_end(&q_sheet_close, false, false, 0);
    q_sheet_body.pack_start(&q_sheet_top, false, false, 0);
    q_sheet_body.pack_start(
        &gtk::Separator::new(gtk::Orientation::Horizontal),
        false,
        false,
        2,
    );

    let q_prog_label = gtk::Label::new(Some("Progress bar"));
    q_prog_label.set_xalign(0.0);
    let q_prog_switch = gtk::Switch::new();
    q_prog_switch.set_active(initial_quiet_progress);
    q_prog_switch.set_halign(gtk::Align::End);
    q_prog_switch.set_tooltip_text(Some("Show a progress bar under the transport"));
    let q_prog_row = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    q_prog_row.pack_start(&q_prog_label, true, true, 0);
    q_prog_row.pack_end(&q_prog_switch, false, false, 0);
    {
        let state_p = state.clone();
        let prog = q_progress_line.clone();
        q_prog_switch.connect_active_notify(move |sw| {
            let on = sw.is_active();
            prog.set_no_show_all(!on);
            prog.set_visible(on);
            if let Ok(mut st) = state_p.lock() {
                st.quiet_progress = on;
            }
            persist_settings(&state_p);
        });
    }
    q_sheet_body.pack_start(&q_prog_row, false, false, 0);

    let q_tilt_label = gtk::Label::new(Some("Tilt effect"));
    q_tilt_label.set_xalign(0.0);
    let q_tilt_switch = gtk::Switch::new();
    q_tilt_switch.set_active(initial_quiet_tilt);
    q_tilt_switch.set_halign(gtk::Align::End);
    q_tilt_switch.set_tooltip_text(Some("Tilt the artwork under the pointer"));
    let q_tilt_row = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    q_tilt_row.pack_start(&q_tilt_label, true, true, 0);
    q_tilt_row.pack_end(&q_tilt_switch, false, false, 0);
    {
        let state_t = state.clone();
        let tilt = q_tilt_on.clone();
        q_tilt_switch.connect_active_notify(move |sw| {
            let on = sw.is_active();
            tilt.set(on);
            if let Ok(mut st) = state_t.lock() {
                st.quiet_tilt = on;
            }
            persist_settings(&state_t);
        });
    }
    q_sheet_body.pack_start(&q_tilt_row, false, false, 0);

    // EventBox wrapper gives the sheet its own event window, so clicks on the
    // panel itself never fall through to the scrim behind it.
    let q_sheet_wrap = gtk::EventBox::new();
    q_sheet_wrap.set_halign(gtk::Align::Fill);
    q_sheet_wrap.set_valign(gtk::Align::Fill);
    q_sheet_wrap.set_vexpand(true);
    q_sheet_wrap.add(&q_sheet);

    let q_sheet_revealer = gtk::Revealer::new();
    q_sheet_revealer.set_transition_type(gtk::RevealerTransitionType::SlideLeft);
    q_sheet_revealer.set_transition_duration(180);
    q_sheet_revealer.set_halign(gtk::Align::End);
    q_sheet_revealer.set_valign(gtk::Align::Fill);
    q_sheet_revealer.set_vexpand(true);
    q_sheet_revealer.add(&q_sheet_wrap);
    q_sheet_revealer.set_reveal_child(false);

    // Full-window scrim: dims the quiet page and closes the sheet on any click
    // that is not on the panel.
    let q_scrim = gtk::EventBox::new();
    q_scrim.style_context().add_class("rustify-quiet-scrim");
    q_scrim.set_halign(gtk::Align::Fill);
    q_scrim.set_valign(gtk::Align::Fill);
    q_scrim.set_hexpand(true);
    q_scrim.set_vexpand(true);
    q_scrim.set_no_show_all(true);
    q_scrim.hide();
    {
        let rev = q_sheet_revealer.clone();
        q_scrim.connect_button_press_event(move |_, _| {
            rev.set_reveal_child(false);
            gtk::glib::Propagation::Stop
        });
    }
    {
        let scrim = q_scrim.clone();
        q_sheet_revealer.connect_child_revealed_notify(move |rev| {
            if !rev.is_child_revealed() {
                scrim.set_no_show_all(true);
                scrim.hide();
            }
        });
    }
    {
        let rev = q_sheet_revealer.clone();
        let scrim = q_scrim.clone();
        q_edit_btn.connect_clicked(move |_| {
            let show = !rev.reveals_child();
            if show {
                scrim.set_no_show_all(false);
                scrim.show();
            }
            rev.set_reveal_child(show);
        });
    }
    {
        let rev = q_sheet_revealer.clone();
        q_sheet_close.connect_clicked(move |_| {
            rev.set_reveal_child(false);
        });
    }

    let quiet_base = gtk::Box::new(gtk::Orientation::Vertical, 0);
    quiet_base.pack_start(&q_header, false, false, 0);
    quiet_base.pack_start(&q_center, true, true, 0);
    quiet_base.pack_end(&q_footer, false, false, 0);
    let quiet_view = gtk::Overlay::new();
    quiet_view.add(&quiet_base);
    quiet_view.add_overlay(&q_scrim);
    quiet_view.add_overlay(&q_sheet_revealer);
    quiet_view.set_overlay_pass_through(&q_scrim, false);
    quiet_view.set_overlay_pass_through(&q_sheet_revealer, false);

    let stack = gtk::Stack::new();
    stack.set_transition_duration(140);
    stack.set_transition_type(gtk::StackTransitionType::Crossfade);
    stack.add_named(&root, "results");
    stack.add_named(&home_view, "home");
    stack.add_named(&playlists_view, "playlists");
    stack.add_named(&imports_view, "imports");
    stack.add_named(&lyrics_view, "lyrics");
    stack.add_named(&settings_view, "settings");
    stack.add_named(&quiet_view, "quiet");

    // bloated mode: a higher-priority sheet re-enables transitions everywhere
    // and the page stack slides instead of crossfading. Applied live and
    // persisted, so it stays on across restarts.
    let bloat_screen = gtk::gdk::Screen::default().expect("no default screen");
    let apply_bloat = {
        let bloat_css = bloat_css.clone();
        let bloat_screen = bloat_screen.clone();
        let stack_bloat = stack.clone();
        let bloat_flag = bloat_flag.clone();
        std::rc::Rc::new(move |on: bool| {
            if on {
                gtk::StyleContext::add_provider_for_screen(
                    &bloat_screen,
                    &bloat_css,
                    gtk::STYLE_PROVIDER_PRIORITY_APPLICATION + 1,
                );
                stack_bloat.set_transition_type(gtk::StackTransitionType::SlideLeftRight);
                stack_bloat.set_transition_duration(320);
            } else {
                gtk::StyleContext::remove_provider_for_screen(&bloat_screen, &bloat_css);
                stack_bloat.set_transition_type(gtk::StackTransitionType::Crossfade);
                stack_bloat.set_transition_duration(140);
            }
            bloat_flag.set(on);
        })
    };
    apply_bloat(initial_bloated);

    // settings lives at the bottom of the rail as a nav entry; pressing it
    // (or the back arrow inside settings) swaps the content stack back.
    // It sits outside the footer so it stays reachable when the rail is
    // collapsed to icons only (the footer itself is hidden in that mode).
    let settings_btn = gtk::Button::new();
    settings_btn.set_tooltip_text(Some("Settings"));
    settings_btn.style_context().add_class("flat");
    settings_btn.style_context().add_class("rustify-nav");
    settings_btn.style_context().add_class("rustify-settings");
    settings_btn.set_halign(gtk::Align::Fill);
    let settings_label = gtk::Label::new(Some("Settings"));
    settings_label.set_xalign(0.0);
    let settings_content = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    {
        let icon = gtk::Image::from_icon_name(
            Some("emblem-system-symbolic"),
            gtk::IconSize::Button,
        );
        settings_content.pack_start(&icon, false, false, 0);
        settings_content.pack_start(&settings_label, false, false, 0);
        settings_btn.add(&settings_content);
    }
    let stats_label = gtk::Label::new(None);
    stats_label.set_markup("<span size='x-small' alpha='45%'>—</span>");
    stats_label.set_ellipsize(gtk::pango::EllipsizeMode::End);
    stats_label.set_xalign(1.0);
    stats_label.set_tooltip_text(Some("Memory · CPU · GPU"));
    stats_label.set_visible(initial_quiet);
    let settings_row = gtk::Box::new(gtk::Orientation::Horizontal, 6);
    settings_row.pack_start(&settings_btn, true, true, 0);
    settings_row.pack_end(&stats_label, false, false, 0);
    side_bottom.pack_start(&settings_row, false, false, 0);

    let content = gtk::Overlay::new();
    content.add(&stack);

    let home_active = Rc::new(Cell::new(false));

    // the cog swaps the current page for settings; pressing it again (or the
    // back arrow inside settings) returns to the page that was open
    let last_page = Rc::new(std::cell::RefCell::new(String::from("home")));
    {
        let stack_c = stack.clone();
        let last_page = last_page.clone();
        settings_btn.connect_clicked(move |_| {
            let current = stack_c
                .visible_child_name()
                .map(|s| s.to_string())
                .unwrap_or_default();
            if current == "settings" {
                let back = last_page.borrow().clone();
                stack_c.set_visible_child_name(&back);
            } else {
                *last_page.borrow_mut() = if current.is_empty() {
                    "results".to_string()
                } else {
                    current
                };
                stack_c.set_visible_child_name("settings");
            }
        });
    }
    {
        let stack_c = stack.clone();
        let last_page = last_page.clone();
        set_back.connect_clicked(move |_| {
            let back = last_page.borrow().clone();
            stack_c.set_visible_child_name(&back);
        });
    }

    // back from the playlists view returns to the home screen
    {
        let stack_back = stack.clone();
        let home_ref_back = home_view.clone();
        let home_active_back = home_active.clone();
        pl_back.connect_clicked(move |_| {
            home_active_back.set(true);
            stack_back.set_visible_child(&home_ref_back);
        });
    }

    // A GtkPaned with a non-resizing first pane keeps the sidebar at a fixed
    // width no matter how wide the window gets; the stack takes all extra
    // space. A plain GtkBox lets the sidebar grow to its natural width once
    // the window is wide enough.
    let outer = gtk::Paned::new(gtk::Orientation::Horizontal);
    outer.set_wide_handle(false);
    outer.pack1(&side, false, false);
    // the transport bar lives outside the page stack so it stays visible on
    // the home, playlists and settings pages too
    let right_col = gtk::Box::new(gtk::Orientation::Vertical, 0);
    right_col.style_context().add_class("rustify-main");
    right_col.pack_start(&content, true, true, 0);
    right_col.pack_start(&bottom, false, false, 0);
    outer.pack2(&right_col, true, true);
    // shared rail width: the compact toggle moves it between full and icons-only
    let side_width = std::rc::Rc::new(std::cell::Cell::new(SIDEBAR_WIDTH));
    outer.set_position(SIDEBAR_WIDTH);
    {
        let side_width = side_width.clone();
        outer.connect_position_notify(move |paned| {
            let width = side_width.get();
            if paned.position() != width {
                paned.set_position(width);
            }
        });
    }

    // Compact sidebar: the top-right glyph shrinks the rail to icons only.
    {
        let side_w = side_width.clone();
        let outer_c = outer.clone();
        let side_c = side.clone();
        let brand_mark_c = brand_mark.clone();
        let brand_text_c = brand_text.clone();
        let nav_label_c = nav_label.clone();
        let footer_c = side_footer.clone();
        let nav_labels_c = nav_labels.clone();
        let nav_contents_c = nav_contents.clone();
        let settings_label_c = settings_label.clone();
        let settings_content_c = settings_content.clone();
        let stats_label_c = stats_label.clone();
        let state_c = state.clone();
        let toggle_c = compact_toggle.clone();
        let anim_gen = std::rc::Rc::new(std::cell::Cell::new(0u64));
        let apply: std::rc::Rc<dyn Fn(bool)> = std::rc::Rc::new(move |on| {
            let from = side_w.get() as f64;
            let to = if on {
                SIDEBAR_COMPACT_WIDTH
            } else {
                SIDEBAR_WIDTH
            } as f64;
            // bumping the generation aborts any animation still in flight so
            // rapid clicks retarget from the current width without fighting
            let gen = anim_gen.get().wrapping_add(1);
            anim_gen.set(gen);

            // Text dies at the start of a collapse. On expand it stays hidden
            // until the rail is wide enough, otherwise the labels' minimum
            // width would blow the pane open before the animation runs.
            if on {
                brand_mark_c.set_visible(false);
                brand_text_c.set_visible(false);
                nav_label_c.set_visible(false);
                footer_c.set_visible(false);
                for label in nav_labels_c.iter() {
                    label.set_visible(false);
                }
                for content in nav_contents_c.iter() {
                    content.set_halign(gtk::Align::Center);
                }
                // the cog stays visible in the rail; drop its label and centre
                // the icon like the other nav rows
                settings_label_c.set_visible(false);
                settings_content_c.set_halign(gtk::Align::Center);
                stats_label_c.set_visible(false);
                side_c.style_context().add_class("rustify-sidebar-compact");
            }
            toggle_c.queue_draw();

            let gen_check = anim_gen.clone();
            let side_w_t = side_w.clone();
            let side_t = side_c.clone();
            let outer_t = outer_c.clone();
            let brand_mark_t = brand_mark_c.clone();
            let brand_text_t = brand_text_c.clone();
            let nav_label_t = nav_label_c.clone();
            let footer_t = footer_c.clone();
            let nav_labels_t = nav_labels_c.clone();
            let nav_contents_t = nav_contents_c.clone();
            let settings_label_t = settings_label_c.clone();
            let settings_content_t = settings_content_c.clone();
            let stats_label_t = stats_label_c.clone();
            let state_t = state_c.clone();
            let start = std::time::Instant::now();
            let dur = Duration::from_millis(240);
            gtk::glib::timeout_add_local(Duration::from_millis(16), move || {
                if gen_check.get() != gen {
                    return gtk::glib::ControlFlow::Break;
                }
                let t = (start.elapsed().as_secs_f64() / dur.as_secs_f64()).min(1.0);
                let width = from + (to - from) * ease_out_back(t);
                let width = width
                    .clamp(
                        SIDEBAR_COMPACT_WIDTH as f64 - 6.0,
                        SIDEBAR_WIDTH as f64 + 6.0,
                    )
                    .round() as i32;
                side_w_t.set(width);
                side_t.set_size_request(width, -1);
                outer_t.set_position(width);

                if t >= 1.0 {
                    // settle exactly on target, then bring the text back
                    side_w_t.set(to as i32);
                    side_t.set_size_request(to as i32, -1);
                    outer_t.set_position(to as i32);
                    if !on {
                        brand_mark_t.set_visible(true);
                        brand_text_t.set_visible(true);
                        nav_label_t.set_visible(true);
                        footer_t.set_visible(true);
                        for label in nav_labels_t.iter() {
                            label.set_visible(true);
                        }
                        for content in nav_contents_t.iter() {
                            content.set_halign(gtk::Align::Fill);
                        }
                        settings_label_t.set_visible(true);
                        settings_content_t.set_halign(gtk::Align::Fill);
                        // the stats chip belongs to quiet mode only; expanding
                        // the rail must not bring it back when quiet is off
                        let quiet_now = state_t
                            .lock()
                            .map(|s| s.quiet_mode)
                            .unwrap_or(false);
                        stats_label_t.set_visible(quiet_now);
                        side_t
                            .style_context()
                            .remove_class("rustify-sidebar-compact");
                    }
                    return gtk::glib::ControlFlow::Break;
                }
                gtk::glib::ControlFlow::Continue
            });
        });
        let apply_click = apply.clone();
        let flag = compact_flag.clone();
        compact_toggle.connect_button_press_event(move |_, ev| {
            if ev.button() == 1 {
                let on = !flag.get();
                flag.set(on);
                apply_click(on);
                gtk::glib::Propagation::Stop
            } else {
                gtk::glib::Propagation::Proceed
            }
        });
    }

    // home button goes to the home screen from anywhere; if it is already
    // open, refresh it (clear the search box, re-focus, re-sync the session)
    let stack_btn = stack.clone();
    let home_ref = home_view.clone();
    let home_search_focus = home_search.clone();
    let login_refresh = login_btn.clone();
    let logout_refresh = logout_btn.clone();
    let nav_refresh = playlists_nav.clone();
    let logo_refresh = logo_area.clone();
    {
        let home_active = home_active.clone();
        home_btn.connect_clicked(move |_| {
            let on_home = stack_btn
                .visible_child_name()
                .map(|name| name == "home")
                .unwrap_or(false);
            if on_home {
                home_search_focus.set_text("");
                home_search_focus.grab_focus();
                let logged_in = yt_cookies_file().is_file();
                nav_refresh.set_visible(logged_in);
                login_refresh.set_visible(!logged_in);
                logout_refresh.set_visible(logged_in);
                home_ref.queue_draw();
                logo_refresh.queue_draw();
                return;
            }
            home_active.set(true);
            stack_btn.set_visible_child(&home_ref);
            home_search_focus.grab_focus();
        });
    }

    // home screen search bar: mirrors the query into the main search entry,
    // shows the results there, and flips back to that view
    {
        let start_home = start_search.clone();
        let entry = home_search.clone();
        let stack_search = stack.clone();
        let root_ref2 = root.clone();
        let main_search = search.clone();
        let home_active_search = home_active.clone();
        let results_gate = results_stack.clone();
        let state_gate = state.clone();
        home_search.connect_activate(move |_| {
            let text = entry.text().to_string();
            home_active_search.set(false);
            stack_search.set_visible_child(&root_ref2);
            main_search.set_text(&text);
            if text.trim().is_empty() {
                return;
            }
            if !is_local_query(&text) && account_required(&state_gate) {
                results_gate.set_visible_child_name("gate");
                return;
            }
            start_home(text);
        });
    }

    // startup intro: an opaque colour wash covers the client area from the
    // very first frame while "Welcome." is shown, holds, then fades out and
    // the live UI is revealed
    let intro_overlay = gtk::Overlay::new();
    intro_overlay.add(&outer);

    let intro_text = Rc::new(Cell::new(1.0f64));
    let intro_blur = Rc::new(Cell::new(1.0f64));
    let intro_area = gtk::DrawingArea::new();
    intro_area.set_halign(gtk::Align::Fill);
    intro_area.set_valign(gtk::Align::Fill);
    intro_area.set_no_show_all(true);
    intro_area.hide();
    {
        let intro_text = intro_text.clone();
        let intro_blur = intro_blur.clone();
        let state_intro = state.clone();
        intro_area.connect_draw(move |area, cr| {
            let alloc = area.allocation();
            let w = alloc.width() as f64;
            let h = alloc.height() as f64;
            let dim = intro_blur.get();
            let mono = state_intro
                .lock()
                .map(|s| s.og_gui || s.theme == "slate")
                .unwrap_or(false);
            if w > 1.0 && h > 1.0 {
                let (r0, g0, b0, r1, g1, b1, r2, g2, b2) = if mono {
                    (0.10, 0.10, 0.10, 0.07, 0.07, 0.07, 0.04, 0.04, 0.04)
                } else {
                    (0.16, 0.11, 0.22, 0.105, 0.075, 0.15, 0.07, 0.05, 0.10)
                };
                let base = gtk::cairo::LinearGradient::new(0.0, 0.0, 0.0, h);
                base.add_color_stop_rgb(0.0, r0, g0, b0);
                base.add_color_stop_rgb(0.55, r1, g1, b1);
                base.add_color_stop_rgb(1.0, r2, g2, b2);
                let _ = cr.set_source(&base);
                let _ = cr.paint_with_alpha(dim);

                let glow = gtk::cairo::RadialGradient::new(
                    w * 0.5,
                    h * 0.42,
                    0.0,
                    w * 0.5,
                    h * 0.42,
                    w * 0.7,
                );
                let (gr, gg, gb) = if mono {
                    (0.32, 0.32, 0.32)
                } else {
                    (0.24, 0.15, 0.34)
                };
                glow.add_color_stop_rgba(0.0, gr, gg, gb, 0.55 * dim);
                glow.add_color_stop_rgba(1.0, gr, gg, gb, 0.0);
                let _ = cr.set_source(&glow);
                let _ = cr.paint();
            }
            let alpha = intro_text.get();
            if alpha > 0.0 && w > 1.0 && h > 1.0 {
                cr.select_font_face(
                    "Inter",
                    gtk::cairo::FontSlant::Normal,
                    gtk::cairo::FontWeight::Bold,
                );
                cr.set_font_size((h * 0.14).max(24.0));
                if let Ok(ext) = cr.text_extents("Welcome.") {
                    cr.move_to(
                        (w - ext.width()) / 2.0 - ext.x_bearing(),
                        (h - ext.height()) / 2.0 - ext.y_bearing(),
                    );
                    cr.set_source_rgba(1.0, 1.0, 1.0, alpha);
                    let _ = cr.show_text("Welcome.");
                }
            }
            gtk::glib::Propagation::Proceed
        });
    }
    intro_overlay.add_overlay(&intro_area);
    intro_area.show();

    // layer for the "ilytommy" easter egg: the real play button is reparented
    // here so it can roam the whole window instead of the transport bar. It is
    // only mounted while the button is actually floating, otherwise a
    // full-window overlay child would eat every pointer event.
    let jump_fixed = gtk::Fixed::new();
    jump_fixed.set_hexpand(true);
    jump_fixed.set_vexpand(true);
    intro_overlay.add_overlay(&jump_fixed);
    intro_overlay.set_overlay_pass_through(&jump_fixed, true);

    win.add(&intro_overlay);
    win.show_all();
    // show_all reveals every child, including the stats chip next to the cog;
    // hide it again unless quiet mode is the saved state
    stats_label.set_visible(initial_quiet);
    // select after show_all: the stack only honours a child once it is visible,
    // otherwise it falls back to the first page (results)
stack.set_visible_child_name("home");
    if initial_quiet {
        brand.set_no_show_all(true);
        brand.hide();
        nav_label.set_no_show_all(true);
        nav_label.hide();
        nav_box.set_no_show_all(true);
        nav_box.hide();
        side_footer.set_no_show_all(true);
        side_footer.hide();
        quiet_side.set_no_show_all(false);
        quiet_side.show_all();
        bottom.set_no_show_all(true);
        bottom.hide();
        stack.set_visible_child_name("quiet");
    }
    if let Some(gdk_window) = intro_area.window() {
        gdk_window.raise();
    }
    start_intro_animation(intro_area.clone(), intro_text.clone(), intro_blur.clone());

    // cookies already exported? reveal the sidebar Playlists entry and swap
    // Login for Log Out.
    let logged_in = yt_cookies_file().is_file();
    playlists_nav.set_visible(logged_in);
    login_btn.set_visible(!logged_in);
    logout_btn.set_visible(logged_in);

    // login: open the YouTube Music sign-in webview; on success the cookie
    // jar is exported, Playlists appears, and Login becomes Log Out
    {
        let win_login = win.clone();
        let playlists_nav_c = playlists_nav.clone();
        let login_c = login_btn.clone();
        let logout_c = logout_btn.clone();
        let results_c = results_stack.clone();
        login_btn.connect_clicked(move |_| {
            let playlists_nav_cc = playlists_nav_c.clone();
            let login_cc = login_c.clone();
            let logout_cc = logout_c.clone();
            let results_cc = results_c.clone();
            open_login_window(&win_login, move || {
                playlists_nav_cc.set_visible(true);
                login_cc.set_visible(false);
                logout_cc.set_visible(true);
                results_cc.set_visible_child_name("results");
            });
        });
    }

    // the login gate button drives the same flow as the sidebar Login button
    {
        let login_trigger = login_btn.clone();
        gate_login.connect_clicked(move |_| {
            login_trigger.emit_clicked();
        });
    }

    // logout: drop the webview context, clear the exported session and flip
    // the home screen back to Login. Cached audio and settings are kept.
    {
        let stack_logout = stack.clone();
        let home_logout = home_view.clone();
        let login_c = login_btn.clone();
        let logout_c = logout_btn.clone();
        let nav_c = playlists_nav.clone();
        let results_c = results_stack.clone();
        let search_c = search.clone();
        let home_search_c = home_search.clone();
        let tx_logout = tx.clone();
        let win_logout = win.clone();
        logout_btn.connect_clicked(move |_| {
            let dialog = gtk::MessageDialog::builder()
                .transient_for(&win_logout)
                .modal(true)
                .message_type(gtk::MessageType::Warning)
                .text("Log out of YouTube Music?")
                .secondary_text("This will erase all account data.")
                .build();
            dialog.add_button("Cancel", gtk::ResponseType::Cancel);
            dialog.add_button("Log Out", gtk::ResponseType::Accept);
            if let Some(button) = dialog.widget_for_response(gtk::ResponseType::Accept) {
                button.style_context().add_class("destructive-action");
            }
            let stack_inner = stack_logout.clone();
            let home_inner = home_logout.clone();
            let login_inner = login_c.clone();
            let logout_inner = logout_c.clone();
            let nav_inner = nav_c.clone();
            let results_inner = results_c.clone();
            let search_inner = search_c.clone();
            let home_search_inner = home_search_c.clone();
            let tx_inner = tx_logout.clone();
            dialog.connect_response(move |dialog, resp| {
                dialog.close();
                if resp != gtk::ResponseType::Accept {
                    return;
                }
                drop_login_context();
                let _ = tx_inner.send(Cmd::Logout);
                login_inner.set_visible(true);
                logout_inner.set_visible(false);
                nav_inner.set_visible(false);
                search_inner.set_text("");
                home_search_inner.set_text("");
                stack_inner.set_visible_child(&home_inner);
                results_inner.set_visible_child_name("gate");
            });
            dialog.show_all();
        });
    }

    // "I'm Feeling Lucky": jump to the results view and let the worker pick a
    // random query, then a random track from the results, and play it
    {
        let tx_lucky = tx.clone();
        let stack_lucky = stack.clone();
        let root_lucky = root.clone();
        let results_lucky = results_stack.clone();
        let home_active_lucky = home_active.clone();
        lucky_btn.connect_clicked(move |_| {
            home_active_lucky.set(false);
            stack_lucky.set_visible_child(&root_lucky);
            results_lucky.set_visible_child_name("results");
            let _ = tx_lucky.send(Cmd::Lucky {
                token: new_play_token(),
            });
        });
    }

    // wipe: drop the webview context on this thread, then let the worker stop
    // playback, delete the whole cache root and settings folder, and reset
    // every piece of state
    {
        let win_wipe = win.clone();
        let login_c = login_btn.clone();
        let logout_c = logout_btn.clone();
        let nav_c = playlists_nav.clone();
        let stack_c = stack.clone();
        let root_c = root.clone();
        let home_active_c = home_active.clone();
        let search_c = search.clone();
        let home_search_c = home_search.clone();
        let results_c = results_stack.clone();
        let tx_wipe = tx.clone();
        let app_wipe = app.clone();
        wipe_settings_btn.connect_clicked(move |_| {
            let dialog = gtk::MessageDialog::builder()
                .transient_for(&win_wipe)
                .modal(true)
                .message_type(gtk::MessageType::Warning)
                .text("Wipe all user data?")
                .secondary_text(
                    "Removes the saved YouTube Music session, the webview profile, cached audio and settings. This cannot be undone.",
                )
                .build();
            dialog.add_button("Cancel", gtk::ResponseType::Cancel);
            dialog.add_button("Wipe", gtk::ResponseType::Accept);
            if let Some(button) = dialog.widget_for_response(gtk::ResponseType::Accept) {
                button.style_context().add_class("destructive-action");
            }
            let login_c = login_c.clone();
            let logout_c = logout_c.clone();
            let nav_c = nav_c.clone();
            let stack_c = stack_c.clone();
            let root_c = root_c.clone();
            let home_active_c = home_active_c.clone();
            let search_c = search_c.clone();
            let home_search_c = home_search_c.clone();
            let results_c = results_c.clone();
            let tx_wipe = tx_wipe.clone();
            let app_wipe = app_wipe.clone();
            dialog.connect_response(move |dialog, resp| {
                dialog.close();
                if resp != gtk::ResponseType::Accept {
                    return;
                }
                drop_login_context();
                let _ = tx_wipe.send(Cmd::WipeData);
                login_c.set_visible(true);
                logout_c.set_visible(false);
                nav_c.set_visible(false);
                search_c.set_text("");
                home_search_c.set_text("");
                home_active_c.set(false);
                stack_c.set_visible_child(&root_c);
                results_c.set_visible_child_name("results");

                // once the worker confirms the wipe is on disk, relaunch the
                // process so the app comes back with default state rather than
                // stale widgets, caches or persisted settings
                let app_wipe = app_wipe.clone();
                gtk::glib::timeout_add_local(Duration::from_millis(100), move || {
                    if !WIPE_DONE.swap(false, Ordering::SeqCst) {
                        return gtk::glib::ControlFlow::Continue;
                    }
                    if let Ok(exe) = std::env::current_exe() {
                        if let Ok(child) = std::process::Command::new("sh")
                            .arg("-c")
                            .arg("sleep 1; exec \"$1\"")
                            .arg("sh")
                            .arg(&exe)
                            .stdin(Stdio::null())
                            .stdout(Stdio::null())
                            .stderr(Stdio::null())
                            .spawn()
                        {
                            // this child must survive the shutdown sweep
                            RELAUNCH_PID.store(child.id(), Ordering::SeqCst);
                        }
                    }
                    app_wipe.quit();
                    gtk::glib::ControlFlow::Break
                });
            });
            dialog.show_all();
        });
    }

    // playlists: fetch the library and replace the current view
    {
        let tx_pl = tx.clone();
        let stack_pl = stack.clone();
        let pl_ref = playlists_view.clone();
        let home_active_pl = home_active.clone();
        playlists_nav.connect_clicked(move |_| {
            home_active_pl.set(false);
            let _ = tx_pl.send(Cmd::ListPlaylists);
            stack_pl.set_visible_child(&pl_ref);
        });
    }

    // imports: rescan the folder, then show the local files
    {
        let tx_imp = tx.clone();
        let stack_imp = stack.clone();
        let imp_ref = imports_view.clone();
        let home_active_imp = home_active.clone();
        imports_nav.connect_clicked(move |_| {
            home_active_imp.set(false);
            let _ = tx_imp.send(Cmd::ScanImports);
            stack_imp.set_visible_child(&imp_ref);
        });
    }
    {
        let stack_back = stack.clone();
        let home_ref_back = home_view.clone();
        let home_active_back = home_active.clone();
        imp_back.connect_clicked(move |_| {
            home_active_back.set(true);
            stack_back.set_visible_child(&home_ref_back);
        });
    }

    // lyrics: swap to the lyrics page; the text for the current track is
    // already being fetched whenever a song starts
    {
        let stack_ly = stack.clone();
        let ly_ref = lyrics_view.clone();
        let home_active_ly = home_active.clone();
        lyrics_nav.connect_clicked(move |_| {
            home_active_ly.set(false);
            stack_ly.set_visible_child(&ly_ref);
        });
    }
    {
        let stack_back = stack.clone();
        let home_ref_back = home_view.clone();
        let home_active_back = home_active.clone();
        ly_back.connect_clicked(move |_| {
            home_active_back.set(true);
            stack_back.set_visible_child(&home_ref_back);
        });
    }
    // watch the imports folder so dropped files show up without a refresh
    {
        let watched = imports_dir();
        let _ = std::fs::create_dir_all(&watched);
        let tx_watch = tx.clone();
        if let Ok(monitor) = gtk::gio::File::for_path(&watched)
            .monitor_directory(gtk::gio::FileMonitorFlags::NONE, gtk::gio::Cancellable::NONE)
        {
            monitor.connect_changed(move |_, _, _, _| {
                let _ = tx_watch.send(Cmd::ScanImports);
            });
            // keep the monitor alive for the whole session
            std::mem::forget(monitor);
        }
    }

    // populates the imports tab on launch, not only when it is opened
    let _ = tx.send(Cmd::ScanImports);

    if let Ok(query) = std::env::var("RUSTIFY_QUERY") {
        if !query.trim().is_empty() {
            search.set_text(&query);
            stack.set_visible_child(&root);
            if is_local_query(&query) || !account_required(&state) {
                start_search(query);
            } else {
                results_stack.set_visible_child_name("gate");
            }
        }
    }

    // wire actions
    {
        let start = start_search.clone();
        let entry = search.clone();
        let results_gate = results_stack.clone();
        let state_gate = state.clone();
        search.connect_activate(move |_| {
            let text = entry.text().to_string();
            if text.trim().is_empty() {
                return;
            }
            if !is_local_query(&text) && account_required(&state_gate) {
                results_gate.set_visible_child_name("gate");
                return;
            }
            start(text);
        });
    }
    {
        let start = start_search.clone();
        let entry = search.clone();
        let results_gate = results_stack.clone();
        let state_gate = state.clone();
        search_btn.connect_clicked(move |_| {
            let text = entry.text().to_string();
            if text.trim().is_empty() {
                return;
            }
            if !is_local_query(&text) && account_required(&state_gate) {
                results_gate.set_visible_child_name("gate");
                return;
            }
            start(text);
        });
    }
    {
        let request_skip = request_skip.clone();
        prev.connect_clicked(move |_| request_skip(false));
    }
    {
        let request_skip = request_skip.clone();
        next.connect_clicked(move |_| request_skip(true));
    }
    {
        let tx_play = tx.clone();
        play.connect_clicked(move |_| {
            let _ = tx_play.send(Cmd::PlayPause);
        });
    }
    {
        // the toggle paints itself via :checked; the worker reads the flag
        // from shared state when a track ends to decide what to loop
        let state_rep = state.clone();
        repeat.connect_toggled(move |btn| {
            if let Ok(mut st) = state_rep.lock() {
                st.repeat = btn.is_active();
            }
        });
    }
    {
        let tx_shuffle = tx.clone();
        let state_shuffle = state.clone();
        shuffle.connect_toggled(move |btn| {
            if let Ok(mut st) = state_shuffle.lock() {
                st.shuffle = btn.is_active();
            }
            persist_settings(&state_shuffle);
            let _ = tx_shuffle.send(Cmd::SetShuffle(btn.is_active()));
        });
    }
    {
        let tx_mini_play = tx.clone();
        mini_play.connect_clicked(move |_| {
            let _ = tx_mini_play.send(Cmd::PlayPause);
        });
    }
    {
        let tx_vol = tx.clone();
        volume.connect_value_changed(move |s| {
            vol_pct.set_text(&format!("{:.0}%", s.value()));
            let _ = tx_vol.send(Cmd::Volume(s.value()));
        });
    }
    let seeking = std::rc::Rc::new(std::cell::Cell::new(false));
    {
        let seeking = seeking.clone();
        progress.connect_button_press_event(move |_, _| {
            seeking.set(true);
            gtk::glib::Propagation::Proceed
        });
    }
    {
        let tx_seek = tx.clone();
        let state_seek = state.clone();
        let prog = progress.clone();
        let seeking = seeking.clone();
        progress.connect_button_release_event(move |_, _| {
            let frac = prog.value() / 1000.0;
            seeking.set(false);
            // move the visible position right away so the tick cannot snap
            // the slider back to the old spot while the worker seeks
            if let Ok(mut s) = state_seek.lock() {
                let target = (s.duration_ms as f64 * frac.clamp(0.0, 1.0)) as u32;
                s.pos_ms = target;
                s.seek_to_ms = Some(target);
            }
            let _ = tx_seek.send(Cmd::Seek(frac));
            gtk::glib::Propagation::Proceed
        });
    }

    // K / Space toggles playback, except while the ilytommy egg owns the
    // transport, and never while a text entry or the login webview has focus.
    {
        let tx_key = tx.clone();
        let win_key = win.clone();
        let win_focus = win_key.clone();
        win_key.connect_key_press_event(move |_, ev| {
            if JUMPY_PLAY.load(Ordering::SeqCst) {
                return gtk::glib::Propagation::Proceed;
            }
            if let Some(focus) = win_focus.focused_widget() {
                if focus.is::<gtk::Entry>() || focus.is::<webkit2gtk::WebView>() {
                    return gtk::glib::Propagation::Proceed;
                }
            }
            let key = ev.keyval();
            if key == gtk::gdk::keys::constants::k
                || key == gtk::gdk::keys::constants::K
                || key == gtk::gdk::keys::constants::space
            {
                let _ = tx_key.send(Cmd::PlayPause);
                return gtk::glib::Propagation::Stop;
            }
            gtk::glib::Propagation::Proceed
        });
    }

    // 150 ms refresh — touch a widget only when its data actually changed, so
    // an idle window does no string allocation and no Pango relayout.
    let tx_rows = tx.clone();
    let seeking_ui = seeking.clone();
    let last_results = std::cell::Cell::new(0u64);
    let last_playlists = std::cell::Cell::new(0u64);
    let last_imports = std::cell::Cell::new(0u64);
    let last_recent = std::cell::Cell::new(0u64);
    let last_lyrics = std::cell::Cell::new(0u64);
    let tick_lyrics_label = ly_label.clone();
    let tick_lyrics_sub = ly_sub.clone();
    let tick_lyrics_scroller = ly_scroller.clone();
    let tick_lyrics_lines = ly_lines.clone();
    let tick_lyrics_box = ly_box.clone();
    let tick_lyrics_event = ly_event.clone();
    let tick_miniplayer = miniplayer.clone();
    let tick_lyrics_synced: std::rc::Rc<std::cell::RefCell<Arc<Vec<LyricLine>>>> =
        std::rc::Rc::new(std::cell::RefCell::new(Arc::new(Vec::new())));
    let tick_lyric_widgets: std::rc::Rc<std::cell::RefCell<Vec<gtk::Label>>> =
        std::rc::Rc::new(std::cell::RefCell::new(Vec::new()));
    let tick_lyric_active = std::cell::Cell::new(usize::MAX);
    let tick_stack = stack.clone();
    let tick_root = root.clone();
    let tick_pl_list = pl_list.clone();
    let tick_imp_list = imp_list.clone();
    let tick_imp_stack = imp_stack.clone();
    let tick_imports_view = imports_view.clone();
    let tick_recent_fixed = flow_fixed.clone();
    let tick_recent_pages = flow_pages.clone();
    let tick_recent_live = flow_live.clone();
    let tick_recent_anim = flow_anim.clone();
    let tick_recent_section = recent_section.clone();
    let tick_recent_center = flow_center.clone();
    let tick_recent_scroll = flow_scroll.clone();
    let tick_recent_hit = flow_hit.clone();
    let tick_expanded = expanded_box.clone();
    let tick_mini = mini_bar.clone();
    let tick_dl_bar = dl_bar.clone();
    let tick_bar = bar.clone();
    let tick_footer = footer.clone();
    let tick_collapse = collapse_btn.clone();
    let tick_cancel = cancel_btn.clone();
    let tick_q_cancel = q_cancel.clone();
    let tick_bottom = bottom.clone();
    let tick_collapsed = collapsed.clone();
    let tick_last_page = last_page.clone();
    let tick_search_spinner = search_spinner.clone();
    let tick_results_stack = results_stack.clone();
    let last_searching = std::cell::Cell::new(false);
    let dl_bar_visible = std::rc::Rc::new(std::cell::Cell::new(false));
    let last_loading = std::cell::Cell::new(false);
    let tick_win = win.clone();
    let playing_seen = std::cell::Cell::new(false);
    let volume_busy = std::cell::Cell::new(false);
    let last_status = std::cell::RefCell::new(String::new());
    // sentinels so the first tick paints the placeholder text even when the
    // real value is empty (title/artist start blank in the state)
    let last_title = std::cell::RefCell::new(String::from("\u{0}"));
    let last_artist = std::cell::RefCell::new(String::from("\u{0}"));
    let last_times = std::cell::RefCell::new(String::new());
    let dev_section_tick = dev_section.clone();
    let mini_title_tick = mini_title.clone();
    let mini_play_icon_tick = mini_play_icon.clone();
    // rainbow easter egg state: a screen-level provider is added while active
    // and its sheet is rotated on a 33 ms timer
    let rainbow_css = gtk::CssProvider::new();
    let rainbow_screen = gtk::gdk::Screen::default().expect("no default screen");
    let rainbow_on = Rc::new(Cell::new(false));
    let rainbow_running = Rc::new(Cell::new(false));
    let tick_play = play.clone();
    let tick_controls = controls.clone();
    let tick_quiet_side = quiet_side.clone();
    let tick_quiet_list = quiet_list.clone();
    let tick_quiet_pl_list = quiet_pl_list.clone();
    let tick_quiet_stack = quiet_stack.clone();
    let tick_stats = stats_label.clone();
    let tick_compact = compact_flag.clone();
    let stats_last = std::cell::Cell::new(std::time::Instant::now());
    let stats_cpu = std::cell::Cell::new(rustify_cpu_ticks());
    let tick_quiet_title = q_title.clone();
    let tick_quiet_artist = q_artist.clone();
    let tick_quiet_cover = q_cover.clone();
    let tick_q_progress = q_progress.area.clone();
    let tick_q_prog_frac = q_progress.fraction.clone();
    let tick_q_prog_drag = q_progress.dragging.clone();
    let tick_q_elapsed = q_elapsed.clone();
    let tick_q_total = q_total.clone();
    let tick_q_pos = std::cell::Cell::new(u32::MAX);
    let tick_q_dur = std::cell::Cell::new(u32::MAX);
    let tick_quiet_play = q_play_icon.clone();
    let tick_quiet_volume = q_volume.clone();
    let tick_brand = brand.clone();
    let tick_nav_label = nav_label.clone();
    let tick_nav_box = nav_box.clone();
    let tick_side_footer = side_footer.clone();
    let last_quiet = std::cell::Cell::new(initial_quiet);
    let last_current = std::cell::RefCell::new(String::from("\u{0}"));
    let last_queue = std::cell::Cell::new(u64::MAX);
    let quiet_volume_busy = std::cell::Cell::new(false);
    let tick_jump_fixed = jump_fixed.clone();
    let tick_intro_overlay = intro_overlay.clone();
    let tick_css = css.clone();
    let tick_apply_transparency = apply_transparency.clone();
    let play_floating = std::cell::Cell::new(false);
    gtk::glib::timeout_add_local(Duration::from_millis(150), move || {
        let searching_now = SEARCHING.load(Ordering::SeqCst);
        if searching_now != last_searching.get() {
            last_searching.set(searching_now);
            if searching_now {
                tick_search_spinner.start();
                if tick_results_stack.visible_child_name().as_deref() != Some("gate") {
                    tick_results_stack.set_visible_child_name("searching");
                }
            } else {
                tick_search_spinner.stop();
                if tick_results_stack.visible_child_name().as_deref() == Some("searching") {
                    tick_results_stack.set_visible_child_name("results");
                }
            }
        }
        let jump_paused = !state.lock().map(|s| s.playing).unwrap_or(false);
        if JUMPY_PLAY.load(Ordering::SeqCst) && !jump_paused {
            if !play_floating.get() {
                if let Some(parent) = tick_play.parent() {
                    if let Ok(boxed) = parent.downcast::<gtk::Box>() {
                        boxed.remove(&tick_play);
                    }
                }
                tick_intro_overlay.set_overlay_pass_through(&tick_jump_fixed, false);
                tick_jump_fixed.put(&tick_play, 0, 0);
                tick_jump_fixed.show_all();
                play_floating.set(true);
            }
            let w = tick_win.allocated_width().max(320);
            let h = tick_win.allocated_height().max(240);
            let x = random_index((w - 72).max(1) as usize) as i32;
            let y = random_index((h - 72).max(1) as usize) as i32;
            tick_jump_fixed.move_(&tick_play, x, y);
        } else if play_floating.get() {
            tick_jump_fixed.remove(&tick_play);
            tick_intro_overlay.set_overlay_pass_through(&tick_jump_fixed, true);
            tick_controls.pack_start(&tick_play, false, false, 0);
            tick_controls.reorder_child(&tick_play, 2);
            tick_play.show();
            play_floating.set(false);
        }
        {
            let active = RAINBOW.load(Ordering::SeqCst);
            if active != rainbow_on.get() {
                rainbow_on.set(active);
                if active {
                    gtk::StyleContext::add_provider_for_screen(
                        &rainbow_screen,
                        &rainbow_css,
                        gtk::STYLE_PROVIDER_PRIORITY_USER,
                    );
                } else {
                    gtk::StyleContext::remove_provider_for_screen(&rainbow_screen, &rainbow_css);
                }
            }
            if active && !rainbow_running.get() {
                rainbow_running.set(true);
                let provider = rainbow_css.clone();
                let running = rainbow_running.clone();
                let start = std::time::Instant::now();
                gtk::glib::timeout_add_local(Duration::from_millis(33), move || {
                    if !RAINBOW.load(Ordering::SeqCst) {
                        running.set(false);
                        return gtk::glib::ControlFlow::Break;
                    }
                    let sheet = rainbow_sheet(start.elapsed().as_secs_f64());
                    let _ = provider.load_from_data(sheet.as_bytes());
                    gtk::glib::ControlFlow::Continue
                });
            }
        }
        let (
            status_new,
            title_new,
            artist_new,
            times_new,
            duration_ms,
            pos_ms,
            playing,
            volume_state,
            results_new,
            playlists_new,
            imports_new,
            recent_new,
            show_res,
            show_imports,
            dev_reveal,
            lyrics_new,
            theme_apply,
            quiet_mode,
            current_new,
            queue_new,
        ) = {
            let mut guard = state.lock().unwrap();

            let status_new = if guard.status != *last_status.borrow() {
                let v = guard.status.clone();
                *last_status.borrow_mut() = v.clone();
                Some(v)
            } else {
                None
            };
            let title_new = if guard.title != *last_title.borrow() {
                let v = guard.title.clone();
                *last_title.borrow_mut() = v.clone();
                Some(v)
            } else {
                None
            };
            let artist_new = if guard.artist != *last_artist.borrow() {
                let v = guard.artist.clone();
                *last_artist.borrow_mut() = v.clone();
                Some(v)
            } else {
                None
            };

            let duration_ms = guard.duration_ms;
            let pos_ms = guard.pos_ms;
            let times_new = if duration_ms > 0 {
                let t = format!("{} / {}", fmt_time(pos_ms), fmt_time(duration_ms));
                if t != *last_times.borrow() {
                    *last_times.borrow_mut() = t.clone();
                    Some(t)
                } else {
                    None
                }
            } else if !last_times.borrow().is_empty() {
                last_times.borrow_mut().clear();
                Some(String::new())
            } else {
                None
            };

            let results_new = if guard.results_serial != last_results.get() {
                last_results.set(guard.results_serial);
                Some(guard.results.clone())
            } else {
                None
            };

            let playlists_new = if guard.playlists_serial != last_playlists.get() {
                last_playlists.set(guard.playlists_serial);
                Some(guard.playlists.clone())
            } else {
                None
            };

            let imports_new = if guard.imports_serial != last_imports.get() {
                last_imports.set(guard.imports_serial);
                Some(guard.imports.clone())
            } else {
                None
            };

            let recent_new = if guard.recent_serial != last_recent.get() {
                last_recent.set(guard.recent_serial);
                true
            } else {
                false
            };

            let lyrics_new = if guard.lyrics_serial != last_lyrics.get() {
                last_lyrics.set(guard.lyrics_serial);
                Some((guard.lyrics.clone(), guard.lyrics_synced.clone()))
            } else {
                None
            };

            let current_new = if guard.current_id != *last_current.borrow() {
                let v = guard.current_id.clone();
                *last_current.borrow_mut() = v.clone();
                Some(v)
            } else {
                None
            };

            let queue_new = if guard.queue_serial != last_queue.get() {
                last_queue.set(guard.queue_serial);
                Some((guard.queue.clone(), guard.queue_cursor))
            } else {
                None
            };

            let quiet_mode = guard.quiet_mode;

            let show_res = guard.show_results_soon;
            if guard.show_results_soon {
                guard.show_results_soon = false;
            }
            let show_imports = guard.show_imports_soon;
            if guard.show_imports_soon {
                guard.show_imports_soon = false;
            }
            let dev_reveal = guard.dev_reveal_soon;
            if guard.dev_reveal_soon {
                guard.dev_reveal_soon = false;
            }
            let theme_apply = guard.theme_apply_soon;
            if guard.theme_apply_soon {
                guard.theme_apply_soon = false;
            }

            (
                status_new,
                title_new,
                artist_new,
                times_new,
                duration_ms,
                pos_ms,
                guard.playing,
                guard.volume,
                results_new,
                playlists_new,
                imports_new,
                recent_new,
                show_res,
                show_imports,
                dev_reveal,
                lyrics_new,
                theme_apply,
                quiet_mode,
                current_new,
                queue_new,
            )
        };

        if pos_ms != tick_q_pos.get() || duration_ms != tick_q_dur.get() {
            tick_q_pos.set(pos_ms);
            tick_q_dur.set(duration_ms);
            tick_q_elapsed.set_markup(&format!(
                "<span size='x-small' alpha='55%'>{}</span>",
                fmt_time(pos_ms)
            ));
            tick_q_total.set_markup(&format!(
                "<span size='x-small' alpha='55%'>{}</span>",
                fmt_time(duration_ms)
            ));
        }
        if !tick_q_prog_drag.get() {
            let frac = if duration_ms > 0 {
                (pos_ms as f64 / duration_ms as f64).clamp(0.0, 1.0)
            } else {
                0.0
            };
            if (frac - tick_q_prog_frac.get()).abs() > 0.0005 {
                tick_q_prog_frac.set(frac);
                tick_q_progress.queue_draw();
            }
        }

        if theme_apply {
            let (theme, og) = state
                .lock()
                .map(|s| (s.theme.clone(), s.og_gui))
                .unwrap_or_else(|_| (String::from("rustify"), false));
            tick_apply_transparency(theme == "transparent" && !og);
            let _ = tick_css.load_from_data(theme_css_og(&theme, og).as_bytes());
        }

        if quiet_mode != last_quiet.get() {
            last_quiet.set(quiet_mode);
            if quiet_mode {
                tick_brand.set_no_show_all(true);
                tick_brand.hide();
                tick_nav_label.set_no_show_all(true);
                tick_nav_label.hide();
                tick_nav_box.set_no_show_all(true);
                tick_nav_box.hide();
                tick_side_footer.set_no_show_all(true);
                tick_side_footer.hide();
                tick_quiet_side.set_no_show_all(false);
                tick_quiet_side.show_all();
                tick_quiet_stack.set_visible_child_name("queue");
                tick_bottom.set_no_show_all(true);
                tick_bottom.hide();
                tick_stack.set_visible_child_name("quiet");
                tick_stats.set_visible(!tick_compact.get());
            } else {
                tick_stats.set_visible(false);
                tick_brand.set_no_show_all(false);
                tick_brand.show_all();
                tick_nav_label.set_no_show_all(false);
                tick_nav_label.show_all();
                tick_nav_box.set_no_show_all(false);
                tick_nav_box.show_all();
                tick_side_footer.set_no_show_all(false);
                tick_side_footer.show_all();
                tick_quiet_side.hide();
                tick_quiet_side.set_no_show_all(true);
                tick_bottom.set_no_show_all(false);
                tick_bottom.show();
                if tick_collapsed.get() {
                    tick_expanded.hide();
                    tick_mini.set_no_show_all(false);
                    tick_mini.show_all();
                } else {
                    tick_mini.hide();
                    tick_expanded.set_no_show_all(false);
                    tick_expanded.show_all();
                }
                if tick_stack.visible_child_name().as_deref() == Some("quiet") {
                    tick_stack.set_visible_child_name("home");
                }
                // the cog remembers the page it replaced; a page that no
                // longer exists (quiet was just switched off) must not be
                // restored on the next cog press
                let stale_quiet = tick_last_page.borrow().as_str() == "quiet";
                if stale_quiet {
                    *tick_last_page.borrow_mut() = "home".to_string();
                }
            }
        }

        if let Some((items, cursor)) = queue_new {
            while let Some(child) = tick_quiet_list.children().first() {
                tick_quiet_list.remove(child);
            }
            for (idx, item) in items.iter().enumerate() {
                // only what is still ahead: the current track and everything
                // already played drop out of the rail
                if idx <= cursor {
                    continue;
                }
                let row = gtk::ListBoxRow::new();
                row.style_context().add_class("rustify-result-row");
                let line = gtk::Box::new(gtk::Orientation::Horizontal, 8);
                line.set_margin_top(6);
                line.set_margin_bottom(6);
                line.set_margin_start(12);
                line.set_margin_end(12);
                let num = gtk::Label::new(None);
                num.set_markup(&format!(
                    "<span size='x-small' alpha='40%'>{:02}</span>",
                    idx + 1
                ));
                num.set_width_chars(2);
                num.set_valign(gtk::Align::Center);
                let t = gtk::Label::new(None);
                if idx == cursor {
                    t.set_markup(&format!(
                        "<span weight='bold'>{}</span>",
                        gtk::glib::markup_escape_text(&item.title)
                    ));
                } else {
                    t.set_markup(&format!(
                        "<span alpha='75%'>{}</span>",
                        gtk::glib::markup_escape_text(&item.title)
                    ));
                }
                t.set_ellipsize(gtk::pango::EllipsizeMode::End);
                t.set_xalign(0.0);
                line.pack_start(&num, false, false, 0);
                line.pack_start(&t, true, true, 0);
                let evb = gtk::EventBox::new();
                evb.add(&line);
                let tx_q = tx_rows.clone();
                evb.connect_button_press_event(move |_, ev| {
                    if ev.button() == 1 {
                        let token = new_play_token();
                        let _ = tx_q.send(Cmd::PlayQueue { index: idx, token });
                    }
                    gtk::glib::Propagation::Proceed
                });
                row.add(&evb);
                tick_quiet_list.add(&row);
            }
            tick_quiet_list.show_all();
        }

        if title_new.is_some() || current_new.is_some() {
            let t = last_title.borrow().clone();
            let a = last_artist.borrow().clone();
            let text = if t.is_empty() { "Nothing playing" } else { &t };
            tick_quiet_title.set_text(text);
            tick_quiet_artist.set_text(if a.is_empty() { "—" } else { &a });
        }
        if let Some(id) = current_new {
            if id.is_empty() || id.starts_with("local:") {
                clear_tilt_cover(&tick_quiet_cover);
            } else {
                spawn_tilt_cover(&tick_quiet_cover, thumb_url(&id), 320);
            }
        }

        if dev_reveal {
            dev_section_tick.set_no_show_all(false);
            dev_section_tick.show_all();
        }

        if let Some(items) = results_new {
            while let Some(child) = list.children().first() {
                list.remove(child);
            }
            build_result_rows(
                &list,
                &items[..],
                tx_rows.clone(),
                RowSource::Results,
            );
            list.show_all();
            stagger_pop_rows(&list, 38, 190);
        }

        if let Some(rows) = playlists_new {
            while let Some(child) = tick_pl_list.children().first() {
                tick_pl_list.remove(child);
            }
            while let Some(child) = tick_quiet_pl_list.children().first() {
                tick_quiet_pl_list.remove(child);
            }
            for (idx, pl) in rows.iter().enumerate() {
                let row = gtk::ListBoxRow::new();
                row.style_context().add_class("rustify-result-row");
                let line = gtk::Box::new(gtk::Orientation::Horizontal, 12);
                line.set_margin_top(8);
                line.set_margin_bottom(8);
                line.set_margin_start(14);
                line.set_margin_end(14);
                let boxx = gtk::Box::new(gtk::Orientation::Vertical, 2);
                boxx.set_hexpand(true);
                boxx.set_valign(gtk::Align::Center);
                let t = gtk::Label::new(None);
                t.set_markup(&format!(
                    "<span weight='bold'>{}</span>",
                    gtk::glib::markup_escape_text(&pl.title)
                ));
                t.set_ellipsize(gtk::pango::EllipsizeMode::End);
                t.set_xalign(0.0);
                boxx.pack_start(&t, false, false, 0);
                if !pl.count.is_empty() {
                    let sub = gtk::Label::new(None);
                    sub.set_markup(&format!(
                        "<span size='small' alpha='65%'>{}</span>",
                        gtk::glib::markup_escape_text(&pl.count)
                    ));
                    sub.set_ellipsize(gtk::pango::EllipsizeMode::End);
                    sub.set_xalign(0.0);
                    boxx.pack_start(&sub, false, false, 0);
                }
                line.pack_start(&boxx, true, true, 0);
                let chevron = gtk::Label::new(None);
                chevron.set_markup("<span size='large' alpha='35%'>›</span>");
                chevron.style_context().add_class("rustify-chevron");
                chevron.set_valign(gtk::Align::Center);
                line.pack_end(&chevron, false, false, 0);
                let evb = gtk::EventBox::new();
                evb.add(&line);
                let tx_pl = tx_rows.clone();
                let menu_id = pl.id.clone();
                let menu_title = pl.title.clone();
                let menu_win = tick_win.clone();
                evb.connect_button_press_event(move |_, ev| {
                    match ev.button() {
                        1 => {
                            let _ = tx_pl.send(Cmd::OpenPlaylist {
                                index: idx,
                                token: new_play_token(),
                            });
                        }
                        3 => {
                            show_playlist_details(
                                &menu_win,
                                tx_pl.clone(),
                                menu_id.clone(),
                                menu_title.clone(),
                            );
                            return gtk::glib::Propagation::Stop;
                        }
                        _ => {}
                    }
                    gtk::glib::Propagation::Proceed
                });
                row.add(&evb);
                tick_pl_list.add(&row);

                let q_row = gtk::ListBoxRow::new();
                q_row.style_context().add_class("rustify-result-row");
                let q_line = gtk::Box::new(gtk::Orientation::Horizontal, 8);
                q_line.set_margin_top(6);
                q_line.set_margin_bottom(6);
                q_line.set_margin_start(12);
                q_line.set_margin_end(12);
                let q_box = gtk::Box::new(gtk::Orientation::Vertical, 0);
                q_box.set_hexpand(true);
                q_box.set_valign(gtk::Align::Center);
                let q_t = gtk::Label::new(None);
                q_t.set_markup(&format!(
                    "<span weight='bold'>{}</span>",
                    gtk::glib::markup_escape_text(&pl.title)
                ));
                q_t.set_ellipsize(gtk::pango::EllipsizeMode::End);
                q_t.set_xalign(0.0);
                q_box.pack_start(&q_t, false, false, 0);
                if !pl.count.is_empty() {
                    let q_sub = gtk::Label::new(None);
                    q_sub.set_markup(&format!(
                        "<span size='x-small' alpha='55%'>{}</span>",
                        gtk::glib::markup_escape_text(&pl.count)
                    ));
                    q_sub.set_ellipsize(gtk::pango::EllipsizeMode::End);
                    q_sub.set_xalign(0.0);
                    q_box.pack_start(&q_sub, false, false, 0);
                }
                q_line.pack_start(&q_box, true, true, 0);
                let q_evb = gtk::EventBox::new();
                q_evb.add(&q_line);
                {
                    let tx_qpl = tx_rows.clone();
                    let quiet_stack_q = tick_quiet_stack.clone();
                    q_evb.connect_button_press_event(move |_, ev| {
                        if ev.button() == 1 {
                            let _ = tx_qpl.send(Cmd::OpenPlaylist {
                                index: idx,
                                token: new_play_token(),
                            });
                            quiet_stack_q.set_visible_child_name("queue");
                        }
                        gtk::glib::Propagation::Proceed
                    });
                }
                q_row.add(&q_evb);
                tick_quiet_pl_list.add(&q_row);
            }
            tick_pl_list.show_all();
            tick_quiet_pl_list.show_all();
        }

        if let Some(items) = imports_new {
            while let Some(child) = tick_imp_list.children().first() {
                tick_imp_list.remove(child);
            }
            if items.is_empty() {
                tick_imp_stack.set_visible_child_name("empty");
            } else {
                build_result_rows(
                    &tick_imp_list,
                    &items[..],
                    tx_rows.clone(),
                    RowSource::Imports,
                );
                tick_imp_list.show_all();
                tick_imp_stack.set_visible_child_name("list");
            }
        }

        if recent_new {
            tick_recent_center.set(0);
            let page = tick_recent_pages[tick_recent_live.get()].clone();
            page.set_no_show_all(false);
            flow_build(
                &page,
                &tick_recent_fixed,
                &tick_recent_pages,
                &tick_recent_live,
                &tick_recent_anim,
                &tick_recent_section,
                &tick_recent_center,
                &tick_recent_scroll,
                &tick_recent_hit,
                &tx_rows,
            );
        }

        if let Some((text, synced)) = lyrics_new {
            if synced.is_empty() {
                while let Some(child) = tick_lyrics_lines.children().first() {
                    tick_lyrics_lines.remove(child);
                }
                tick_lyric_widgets.borrow_mut().clear();
                *tick_lyrics_synced.borrow_mut() = Arc::new(Vec::new());
                tick_lyrics_label.set_text(&text);
                tick_lyrics_label.show();
                tick_lyrics_event.show();
                tick_lyrics_lines.hide();
            } else {
                while let Some(child) = tick_lyrics_lines.children().first() {
                    tick_lyrics_lines.remove(child);
                }
                let mut widgets: Vec<gtk::Label> = Vec::with_capacity(synced.len());
                for line in synced.iter() {
                    let shown = if line.text.is_empty() { " " } else { &line.text };
                    let label = gtk::Label::new(Some(shown));
                    label.set_xalign(0.5);
                    label.set_yalign(0.0);
                    label.set_justify(gtk::Justification::Center);
                    label.set_line_wrap(true);
                    label.set_line_wrap_mode(gtk::pango::WrapMode::WordChar);
                    label.set_selectable(false);
                    label.set_hexpand(true);
                    label.style_context().add_class("rustify-lyric-line");
                    let holder = gtk::EventBox::new();
                    holder.set_halign(gtk::Align::Fill);
                    holder.set_hexpand(true);
                    holder.add(&label);
                    if duration_ms > 0 {
                        let tx_seek = tx_rows.clone();
                        let frac =
                            (line.at_ms as f64 / duration_ms as f64).clamp(0.0, 1.0);
                        holder.connect_button_press_event(move |_, ev| {
                            if ev.button() != 1 {
                                return gtk::glib::Propagation::Proceed;
                            }
                            let _ = tx_seek.send(Cmd::Seek(frac));
                            gtk::glib::Propagation::Stop
                        });
                    }
                    tick_lyrics_lines.pack_start(&holder, false, false, 0);
                    widgets.push(label);
                }
                tick_lyrics_lines.show_all();
                tick_lyrics_label.hide();
                tick_lyrics_event.hide();
                *tick_lyrics_synced.borrow_mut() = synced;
                *tick_lyric_widgets.borrow_mut() = widgets;
                tick_lyric_active.set(usize::MAX);
            }
            tick_lyrics_scroller.vadjustment().set_value(0.0);
        }

        // highlight and scroll the line that matches the playhead
        {
            let synced = tick_lyrics_synced.borrow().clone();
            if !synced.is_empty() {
                let active = lyric_index_at(&synced, pos_ms);
                let current = active.unwrap_or(usize::MAX);
                if current != tick_lyric_active.get() {
                    tick_lyric_active.set(current);
                    let widgets = tick_lyric_widgets.borrow();
                    for (i, widget) in widgets.iter().enumerate() {
                        if Some(i) == active {
                            widget.style_context().add_class("active");
                        } else {
                            widget.style_context().remove_class("active");
                        }
                    }
                    if let Some(widget) = active.and_then(|i| widgets.get(i)) {
                        scroll_lyrics_to(&tick_lyrics_scroller, &tick_lyrics_box, widget);
                    }
                }
            } else if tick_lyrics_label.is_visible() && playing && duration_ms > 0 {
                // no timing data: drift the plain lyrics from top to bottom over
                // the song's real length, easing toward the target so it looks
                // like a slow scroll instead of a jump every tick
                let frac = (pos_ms as f64 / duration_ms as f64).clamp(0.0, 1.0);
                let adj = tick_lyrics_scroller.vadjustment();
                let upper = (adj.upper() - adj.page_size()).max(adj.lower());
                let target = adj.lower() + (upper - adj.lower()) * frac;
                let current = adj.value();
                let next = current + (target - current) * 0.22;
                if (next - current).abs() > 0.25 {
                    adj.set_value(next.clamp(adj.lower(), upper));
                }
            }
        }

        if tick_miniplayer.is_open() {
            let plain = tick_lyrics_label.text();
            let synced = tick_lyrics_synced.borrow();
            tick_miniplayer.update(
                &last_title.borrow(),
                &last_artist.borrow(),
                pos_ms,
                duration_ms,
                playing,
                &plain,
                &synced[..],
            );
        }

        if show_res && !quiet_mode {
            tick_stack.set_visible_child(&tick_root);
        }
        if show_imports && !quiet_mode {
            tick_stack.set_visible_child(&tick_imports_view);
        }

        if title_new.is_some() || artist_new.is_some() {
            let t = last_title.borrow().clone();
            let a = last_artist.borrow().clone();
            let text = if t.is_empty() {
                "Nothing playing".to_string()
            } else if a.is_empty() {
                t
            } else {
                format!("{t} — {a}")
            };
            tick_lyrics_sub.set_markup(&format!(
                "<span size='x-small' alpha='50%'>{}</span>",
                gtk::glib::markup_escape_text(&text)
            ));
        }

        if let Some(t) = title_new {
            let text = if t.is_empty() { "Nothing playing" } else { &t };
            title.set_markup(&format!(
                "<span size='large' weight='bold'>{}</span>",
                gtk::glib::markup_escape_text(text)
            ));
            mini_title_tick.set_text(text);
        }
        if let Some(a) = artist_new {
            artist.set_markup(&format!(
                "<span alpha='70%'>{}</span>",
                gtk::glib::markup_escape_text(if a.is_empty() { "—" } else { &a })
            ));
        }

        let dl_frac = dl_snapshot();
        if let Some(frac) = dl_frac {
            // while a foreground download runs, swap the whole player out for
            // a single plain bar that fills with the download progress
            tick_dl_bar.set_fraction(frac);
            if !dl_bar_visible.get() {
                dl_bar_visible.set(true);
                // keep the header (and its cancel X) above the download bar;
                // only the track info and controls go away
                tick_expanded.set_no_show_all(false);
                tick_expanded.show();
                tick_bar.hide();
                tick_footer.hide();
                tick_collapse.set_no_show_all(true);
                tick_collapse.hide();
                tick_mini.hide();
                tick_dl_bar.set_no_show_all(false);
                tick_dl_bar.show();
                tick_bottom
                    .style_context()
                    .add_class("rustify-player-downloading");
            }
            if !seeking_ui.get() {
                progress.set_value(frac * 1000.0);
            }
            let pct = (frac * 100.0).round() as u32;
            let t = format!("Downloading {pct}%");
            if t != *last_times.borrow() {
                *last_times.borrow_mut() = t.clone();
                times.set_markup(&format!("<span alpha='60%'>{}</span>", t));
            }
        } else {
            if dl_bar_visible.get() {
                dl_bar_visible.set(false);
                tick_dl_bar.hide();
                tick_dl_bar.set_no_show_all(true);
                tick_collapse.set_no_show_all(false);
                tick_collapse.show();
                tick_bottom
                    .style_context()
                    .remove_class("rustify-player-downloading");
                if tick_collapsed.get() {
                    tick_expanded.hide();
                    tick_mini.set_no_show_all(false);
                    tick_mini.show_all();
                } else {
                    tick_expanded.set_no_show_all(false);
                    tick_expanded.show_all();
                }
            }
            if duration_ms > 0 {
                if !seeking_ui.get() {
                    let frac = (pos_ms as f64 / duration_ms as f64).clamp(0.0, 1.0);
                    progress.set_value(frac * 1000.0);
                }
            } else {
                progress.set_value(0.0);
            }
            if let Some(t) = times_new {
                if t.is_empty() {
                    times.set_markup("");
                } else {
                    times.set_markup(&format!("<span alpha='60%'>{}</span>", t));
                }
            }
        }

        if playing_seen.get() != playing {
            playing_seen.set(playing);
            let icon = if playing {
                "media-playback-pause-symbolic"
            } else {
                "media-playback-start-symbolic"
            };
            play_icon.set_icon_name(Some(icon));
            mini_play_icon_tick.set_icon_name(Some(icon));
            tick_quiet_play.set_icon_name(Some(icon));
        }

        if !volume_busy.get() && (volume.value() - volume_state).abs() > 1.0 {
            volume_busy.set(true);
            volume.set_value(volume_state);
            volume_busy.set(false);
        }
        if !quiet_volume_busy.get() && (tick_quiet_volume.value() - volume_state).abs() > 1.0 {
            quiet_volume_busy.set(true);
            tick_quiet_volume.set_value(volume_state);
            quiet_volume_busy.set(false);
        }

        if let Some(s) = status_new {
            // "Playing"/"Paused" are already conveyed by the transport icon;
            // don't clutter the player with the tiny status line for them
            if s == "Playing" || s == "Paused" {
                status.set_markup("");
                status.set_no_show_all(true);
                status.hide();
            } else {
                status.set_no_show_all(false);
                status.set_markup(&format!(
                    "<span size='small' alpha='55%'>{}</span>",
                    gtk::glib::markup_escape_text(&s)
                ));
                status.show();
            }
        }

        // the cancel X only exists while a song is actually being fetched
        let loading = last_status.borrow().starts_with("Loading ");
        if loading != last_loading.get() {
            last_loading.set(loading);
            tick_cancel.set_visible(loading);
            tick_q_cancel.set_visible(loading);
        }

        if stats_last.get().elapsed() >= Duration::from_millis(1000) {
            let now = std::time::Instant::now();
            let elapsed = now
                .duration_since(stats_last.replace(now))
                .as_secs_f64();
            let ticks = rustify_cpu_ticks();
            let delta = ticks.saturating_sub(stats_cpu.replace(ticks));
            // CLK_TCK is 100 on linux, so delta/elapsed is already a percent
            let cpu = (delta as f64 / elapsed.max(0.001)).clamp(0.0, 100.0);
            let mem_mb = rustify_private_kb() as f64 / 1024.0;
            let gpu = match gpu_busy_percent() {
                Some(v) => format!("{v}%"),
                None => "—".to_string(),
            };
            tick_stats.set_markup(&format!(
                "<span size='x-small' alpha='45%'>{:.0} MB · {:.0}% · {}</span>",
                mem_mb, cpu, gpu
            ));
        }

        gtk::glib::ControlFlow::Continue
    });
}

fn fmt_time(ms: u32) -> String {
    let total = ms / 1000;
    format!("{}:{:02}", total / 60, total % 60)
}

// Memory this process alone is holding: the unique set size, i.e. private
// clean + private dirty + private hugetlb. Unlike VmRSS it leaves out pages
// shared with other processes, so the sidebar reflects Rustify's own use.
fn rustify_private_kb() -> u64 {
    if let Ok(text) = std::fs::read_to_string("/proc/self/smaps_rollup") {
        let mut private = 0u64;
        for line in text.lines() {
            let rest = line
                .strip_prefix("Private_Clean:")
                .or_else(|| line.strip_prefix("Private_Dirty:"))
                .or_else(|| line.strip_prefix("Private_Hugetlb:"));
            if let Some(value) = rest
                .and_then(|r| r.split_whitespace().next())
                .and_then(|n| n.parse::<u64>().ok())
            {
                private += value;
            }
        }
        if private > 0 {
            return private;
        }
    }
    // fall back to the resident set if smaps_rollup is unavailable
    std::fs::read_to_string("/proc/self/status")
        .ok()
        .and_then(|text| {
            text.lines().find_map(|line| {
                line.strip_prefix("VmRSS:")
                    .and_then(|r| r.split_whitespace().next())
                    .and_then(|n| n.parse::<u64>().ok())
            })
        })
        .unwrap_or(0)
}

// Cumulative user+system cpu ticks for this process. /proc/self/stat puts the
// executable name in parens (it can contain spaces), so parse after the last
// ')'. State is field 3; utime/stime are fields 14/15, i.e. offsets 11/12.
fn rustify_cpu_ticks() -> u64 {
    let text = match std::fs::read_to_string("/proc/self/stat") {
        Ok(t) => t,
        Err(_) => return 0,
    };
    let rest = match text.rfind(')') {
        Some(i) => &text[i + 1..],
        None => return 0,
    };
    let fields: Vec<&str> = rest.split_whitespace().collect();
    let utime = fields
        .get(11)
        .and_then(|v| v.parse::<u64>().ok())
        .unwrap_or(0);
    let stime = fields
        .get(12)
        .and_then(|v| v.parse::<u64>().ok())
        .unwrap_or(0);
    utime + stime
}

// GPU busy sample. amdgpu/i915 expose a sysfs counter; nvidia only answers
// through nvidia-smi. That call costs tens of ms, so a background thread
// samples it once a second and the UI thread only reads the cached atomic.
const GPU_UNKNOWN: u32 = u32::MAX;
static GPU_BUSY: AtomicU32 = AtomicU32::new(GPU_UNKNOWN);

fn gpu_read_busy() -> Option<u32> {
    for card in 0..4 {
        for name in ["gpu_busy_percent", "gt_busy_percent"] {
            let path = format!("/sys/class/drm/card{card}/device/{name}");
            if let Ok(text) = std::fs::read_to_string(&path) {
                if let Ok(v) = text.trim().parse::<u32>() {
                    return Some(v);
                }
            }
        }
    }
    let out = std::process::Command::new("nvidia-smi")
        .args([
            "--query-gpu=utilization.gpu",
            "--format=csv,noheader,nounits",
        ])
        .output()
        .ok()?;
    if !out.status.success() {
        return None;
    }
    String::from_utf8_lossy(&out.stdout)
        .lines()
        .next()
        .and_then(|line| line.trim().parse::<u32>().ok())
}

fn start_gpu_monitor() {
    static ONCE: OnceLock<()> = OnceLock::new();
    ONCE.get_or_init(|| {
        std::thread::spawn(|| loop {
            let sample = gpu_read_busy().unwrap_or(GPU_UNKNOWN);
            GPU_BUSY.store(sample, Ordering::Relaxed);
            std::thread::sleep(Duration::from_secs(1));
        });
    });
}

fn gpu_busy_percent() -> Option<u32> {
    match GPU_BUSY.load(Ordering::Relaxed) {
        GPU_UNKNOWN => None,
        v => Some(v),
    }
}

fn smoothstep(t: f64) -> f64 {
    let t = t.clamp(0.0, 1.0);
    t * t * (3.0 - 2.0 * t)
}

// Slight overshoot at the end of travel: the rail slams past its target and
// springs back, so the collapse reads as a snap instead of a slide.
fn ease_out_back(t: f64) -> f64 {
    let t = t.clamp(0.0, 1.0);
    let c1 = 1.70158;
    let c3 = c1 + 1.0;
    let u = t - 1.0;
    1.0 + c3 * u * u * u + c1 * u * u
}

fn start_intro_animation(
    area: gtk::DrawingArea,
    text: Rc<Cell<f64>>,
    blur: Rc<Cell<f64>>,
) {
    const HOLD: f64 = 2.0;
    const FADE_OUT: f64 = 0.7;
    const UNBLUR: f64 = 1.0;
    let start = std::time::Instant::now();
    gtk::glib::timeout_add_local(Duration::from_millis(16), move || {
        let t = start.elapsed().as_secs_f64();
        let text_alpha = if t < HOLD {
            1.0
        } else if t < HOLD + FADE_OUT {
            1.0 - smoothstep((t - HOLD) / FADE_OUT)
        } else {
            0.0
        };
        text.set(text_alpha);

        let blur_alpha = if t < HOLD {
            1.0
        } else if t < HOLD + UNBLUR {
            1.0 - smoothstep((t - HOLD) / UNBLUR)
        } else {
            0.0
        };
        blur.set(blur_alpha);
        area.queue_draw();

        if t >= HOLD + UNBLUR {
            area.hide();
            return gtk::glib::ControlFlow::Break;
        }
        gtk::glib::ControlFlow::Continue
    });
}

fn yt_cookies_file() -> PathBuf {
    cache_root().join("cookies.txt")
}

fn yt_cookie_args() -> Vec<String> {
    let path = yt_cookies_file();
    if path.is_file() {
        vec!["--cookies".to_string(), path.to_string_lossy().into_owned()]
    } else {
        Vec::new()
    }
}

// True when the UI should demand a login before searching. A developer can
// lift that requirement with the "No account requiry" switch.
fn account_required(state: &Arc<Mutex<UiState>>) -> bool {
    if yt_cookies_file().is_file() {
        return false;
    }
    match state.lock() {
        Ok(s) => !s.no_account,
        Err(_) => true,
    }
}

// The only way to turn the transparent theme on. It is intentionally absent
// from settings, including the developer section, and it stays on across
// launches once used.
fn is_clear_query(query: &str) -> bool {
    query.trim().eq_ignore_ascii_case("let me be clear")
}

// Queries the app answers locally. They never need a YouTube session, so the
// login gate must let them through to the worker.
fn is_local_query(query: &str) -> bool {
    let q = query.trim();
    q.eq_ignore_ascii_case("let me be clear")
        || q.eq_ignore_ascii_case("didy")
        || q.eq_ignore_ascii_case("i love windows")
}

const LOGIN_COOKIE_URI: &str = "https://music.youtube.com/";

// One persistent WebContext for every sign-in window. It must outlive the
// WebView: the CookieManager belongs to the context's WebsiteDataManager, and
// dropping the context first made WebKit unref freed internals and crash right
// after login. Keeping it thread-local gives it process lifetime.
thread_local! {
    static LOGIN_CONTEXT: std::cell::RefCell<Option<(WebContext, WebsiteDataManager)>> =
        std::cell::RefCell::new(None);
}

fn login_context() -> WebContext {
    LOGIN_CONTEXT.with(|slot| {
        if let Some((context, _)) = slot.borrow().as_ref() {
            return context.clone();
        }
        let data_dir = cache_root().join("webview");
        let _ = std::fs::create_dir_all(&data_dir);
        let manager = WebsiteDataManager::builder()
            .base_data_directory(data_dir.to_string_lossy().into_owned())
            .base_cache_directory(data_dir.join("cache").to_string_lossy().into_owned())
            .build();
        let context = WebContext::with_website_data_manager(&manager);
        *slot.borrow_mut() = Some((context.clone(), manager));
        context
    })
}

// Release the WebKit context (and its profile files) before the wipe deletes
// the data directory. The next Login builds a fresh one.
fn drop_login_context() {
    LOGIN_CONTEXT.with(|slot| {
        let _ = slot.borrow_mut().take();
    });
}

// Embedded sign-in. The webview runs against a persistent data directory so
// the YouTube Music session survives restarts; on success the cookie jar is
// exported as a Netscape cookies.txt for yt-dlp and the caller is notified.
fn open_login_window<F: Fn() + 'static>(parent: &gtk::ApplicationWindow, on_success: F) {
    let dialog = gtk::Window::builder()
        .title("Sign in to YouTube Music")
        .default_width(540)
        .default_height(760)
        .transient_for(parent)
        .modal(true)
        .build();

    let header = gtk::HeaderBar::new();
    let cancel = gtk::Button::with_label("Cancel");
    header.pack_start(&cancel);
    let done = gtk::Button::with_label("Done");
    done.style_context().add_class("suggested-action");
    header.pack_end(&done);
    dialog.set_titlebar(Some(&header));
    {
        let dialog = dialog.clone();
        cancel.connect_clicked(move |_| dialog.close());
    }

    let context = login_context();
    let cookies = context.cookie_manager().expect("webview cookie manager");
    // Google's sign-in flow drops cookies across redirects and iframes; the
    // default "no third party" policy is too strict here.
    cookies.set_accept_policy(webkit2gtk::CookieAcceptPolicy::Always);

    let view = WebView::builder().web_context(&context).build();
    view.load_uri(LOGIN_COOKIE_URI);

    let hint = gtk::Label::new(Some(
        "Sign in with your Google account. Playlists unlock automatically.",
    ));
    hint.set_margin_top(6);
    hint.set_margin_bottom(6);
    hint.set_margin_start(12);
    hint.set_margin_end(12);
    hint.set_xalign(0.0);

    let content = gtk::Box::new(gtk::Orientation::Vertical, 0);
    content.pack_start(&hint, false, false, 0);
    content.pack_start(&view, true, true, 0);
    dialog.add(&content);
    dialog.show_all();

    let finished = Rc::new(Cell::new(false));
    {
        let finished = finished.clone();
        dialog.connect_destroy(move |_| finished.set(true));
    }
    let on_success = Rc::new(on_success);

    let complete: Rc<dyn Fn(Vec<Cookie>)> = {
        let finished = finished.clone();
        let on_success = on_success.clone();
        let dialog = dialog.clone();
        let hint = hint.clone();
        Rc::new(move |mut jar: Vec<Cookie>| {
            if finished.get() {
                return;
            }
            if !has_login_cookie(&mut jar) {
                hint.set_text("Not signed in yet — finish the Google sign-in first.");
                return;
            }
            if let Err(e) = write_cookie_file(jar) {
                eprintln!("cookie export failed: {e}");
                hint.set_text("Could not save the session; please try again.");
                return;
            }
            finished.set(true);
            // Never tear the WebView down from inside its own cookie callback;
            // let the main loop do it on the next idle turn.
            let dialog = dialog.clone();
            let on_success = on_success.clone();
            gtk::glib::idle_add_local_once(move || {
                on_success();
                dialog.close();
            });
        })
    };

    {
        let cookies = cookies.clone();
        let complete = complete.clone();
        done.connect_clicked(move |_| {
            let complete = complete.clone();
            cookies.cookies(
                LOGIN_COOKIE_URI,
                None::<&webkit2gtk::gio::Cancellable>,
                move |res| {
                    if let Ok(list) = res {
                        complete(list);
                    }
                },
            );
        });
    }

    {
        let cookies = cookies.clone();
        let complete = complete.clone();
        gtk::glib::timeout_add_seconds_local(1, move || {
            if finished.get() {
                return gtk::glib::ControlFlow::Break;
            }
            let complete = complete.clone();
            cookies.cookies(
                LOGIN_COOKIE_URI,
                None::<&webkit2gtk::gio::Cancellable>,
                move |res| {
                    if let Ok(mut list) = res {
                        if has_login_cookie(&mut list) {
                            complete(list);
                        }
                    }
                },
            );
            gtk::glib::ControlFlow::Continue
        });
    }
}

fn has_login_cookie(cookies: &mut [Cookie]) -> bool {
    cookies.iter_mut().any(|cookie| {
        let name = cookie.name().map(|n| n.to_string()).unwrap_or_default();
        name == "__Secure-3PAPISID"
    })
}

fn write_cookie_file(mut cookies: Vec<Cookie>) -> Result<(), String> {
    let path = yt_cookies_file();
    if let Some(dir) = path.parent() {
        let _ = std::fs::create_dir_all(dir);
    }
    let mut out = String::from("# Netscape HTTP Cookie File\n# Generated by Rustify\n\n");
    for cookie in cookies.iter_mut() {
        let domain = cookie.domain().map(|v| v.to_string()).unwrap_or_default();
        let name = cookie.name().map(|v| v.to_string()).unwrap_or_default();
        let value = cookie.value().map(|v| v.to_string()).unwrap_or_default();
        if domain.is_empty() || name.is_empty() {
            continue;
        }
        let path = cookie
            .path()
            .map(|v| v.to_string())
            .filter(|p| !p.is_empty())
            .unwrap_or_else(|| "/".to_string());
        let include_sub = if domain.starts_with('.') { "TRUE" } else { "FALSE" };
        let secure = if cookie.is_secure() { "TRUE" } else { "FALSE" };
        let expires = cookie.expires().map(|d| d.to_unix()).unwrap_or(0);
        let prefix = if cookie.is_http_only() { "#HttpOnly_" } else { "" };
        let name = name.replace(['\t', '\n', '\r'], "");
        let value = value.replace(['\t', '\n', '\r'], "");
        out.push_str(&format!(
            "{prefix}{domain}\t{include_sub}\t{path}\t{secure}\t{expires}\t{name}\t{value}\n"
        ));
    }
    std::fs::write(&path, out).map_err(|e| e.to_string())?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let _ = std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600));
    }
    Ok(())
}

// Rebuild the cookie header plus the __Secure-3PAPISID value used to sign
// authenticated YouTube Music InnerTube requests.
fn cookie_jar() -> Result<(String, String), String> {
    let path = yt_cookies_file();
    let text = std::fs::read_to_string(&path).map_err(|_| "not signed in".to_string())?;
    let mut header = String::new();
    let mut sapisid = None;
    for raw in text.lines() {
        if raw.trim().is_empty() {
            continue;
        }
        let line = if let Some(rest) = raw.strip_prefix("#HttpOnly_") {
            rest
        } else if raw.starts_with('#') {
            continue;
        } else {
            raw
        };
        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() < 7 {
            continue;
        }
        let domain = fields[0];
        if !(domain.contains("youtube.com") || domain.contains("google.com")) {
            continue;
        }
        let name = fields[5].trim();
        let value = fields[6].trim();
        if name.is_empty() {
            continue;
        }
        if !header.is_empty() {
            header.push_str("; ");
        }
        header.push_str(name);
        header.push('=');
        header.push_str(value);
        if name == "__Secure-3PAPISID" {
            sapisid = Some(value.to_string());
        }
    }
    let sapisid = sapisid.ok_or_else(|| "cookies missing __Secure-3PAPISID".to_string())?;
    Ok((header, sapisid))
}

const YTM_API_KEY: &str = "AIzaSyC9XL3ZjWddXya6X74dJoCTL-WEYFDNX30";
const YTM_CLIENT_VERSION: &str = "1.20260707.12.00";

fn ytm_post(
    client: &reqwest::blocking::Client,
    endpoint: &str,
    mut body: serde_json::Value,
) -> Result<serde_json::Value, String> {
    let (cookie_header, sapisid) = cookie_jar()?;
    let origin = "https://music.youtube.com";
    let ts = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_err(|e| e.to_string())?
        .as_secs()
        .to_string();
    let input = format!("{ts} {sapisid} {origin}");
    let digest = gtk::glib::compute_checksum_for_data(
        gtk::glib::ChecksumType::Sha1,
        input.as_bytes(),
    )
    .ok_or_else(|| "sha1 failed".to_string())?;
    let auth = format!("SAPISIDHASH {ts}_{digest}");

    let Some(obj) = body.as_object_mut() else {
        return Err("bad request body".to_string());
    };
    obj.insert(
        "context".to_string(),
        serde_json::json!({
            "client": {
                "clientName": "WEB_REMIX",
                "clientVersion": YTM_CLIENT_VERSION,
                "hl": "en",
                "gl": "US",
            }
        }),
    );
    let url = format!(
        "https://music.youtube.com/youtubei/v1/{endpoint}?key={YTM_API_KEY}&prettyPrint=false"
    );
    let resp = client
        .post(&url)
        .header(reqwest::header::CONTENT_TYPE, "application/json")
        .header(reqwest::header::COOKIE, cookie_header)
        .header(reqwest::header::AUTHORIZATION, auth)
        .header(reqwest::header::ORIGIN, origin)
        .header("X-Origin", origin)
        .header("X-Goog-AuthUser", "0")
        .header(reqwest::header::USER_AGENT, BROWSER_UA)
        .body(body.to_string())
        .send()
        .map_err(|e| e.to_string())?;
    if !resp.status().is_success() {
        let status = resp.status();
        let text = resp.text().unwrap_or_default();
        let detail = serde_json::from_str::<serde_json::Value>(&text)
            .ok()
            .and_then(|v| {
                v.get("error")
                    .and_then(|e| e.get("message"))
                    .and_then(|m| m.as_str())
                    .map(str::to_string)
            })
            .unwrap_or_else(|| text.chars().take(160).collect());
        return Err(format!("{endpoint} HTTP {status}: {detail}"));
    }
    let bytes = resp.bytes().map_err(|e| e.to_string())?;
    serde_json::from_slice(&bytes).map_err(|e| e.to_string())
}

fn ytm_browse(
    client: &reqwest::blocking::Client,
    browse_id: &str,
) -> Result<serde_json::Value, String> {
    ytm_post(
        client,
        "browse",
        serde_json::json!({ "browseId": browse_id }),
    )
}

// Delete a playlist from the signed-in YouTube Music account. The endpoint
// needs the same cookie + SAPISIDHASH signing as browsing; anonymous calls
// come back 401.
fn ytm_delete_playlist(
    client: &reqwest::blocking::Client,
    id: &str,
) -> Result<(), String> {
    let json = ytm_post(
        client,
        "playlist/delete",
        serde_json::json!({ "playlistId": id }),
    )?;
    if let Some(status) = json.get("status").and_then(|v| v.as_str()) {
        if status != "STATUS_SUCCEEDED" && status != "STATUS_QUEUED" {
            return Err(format!("playlist delete: {status}"));
        }
    }
    Ok(())
}

// Create a playlist on the signed-in YouTube Music account. Same cookie +
// SAPISIDHASH signing as the other library calls; private by default so a new
// playlist never goes public on its own.
// Append one video to a playlist on the signed-in account. YouTube Music takes
// this through the browse/edit_playlist endpoint with an ACTION_ADD_VIDEO step.
fn ytm_add_to_playlist(
    client: &reqwest::blocking::Client,
    playlist_id: &str,
    video_id: &str,
) -> Result<(), String> {
    let json = ytm_post(
        client,
        "browse/edit_playlist",
        serde_json::json!({
            "playlistId": playlist_id,
            "actions": [{
                "action": "ACTION_ADD_VIDEO",
                "addedVideoId": video_id,
            }],
        }),
    )?;
    if let Some(status) = json.get("status").and_then(|v| v.as_str()) {
        if status != "STATUS_SUCCEEDED" && status != "STATUS_QUEUED" {
            return Err(format!("add to playlist: {status}"));
        }
    }
    Ok(())
}

// A playlist edit needs the per-entry setVideoId to target one occurrence, so
// browse the playlist and match it by video id before issuing the removal.
fn find_set_video_id(node: &serde_json::Value, video_id: &str) -> Option<String> {
    match node {
        serde_json::Value::Object(map) => {
            if let Some(data) = map.get("playlistItemData") {
                if data.get("videoId").and_then(|v| v.as_str()) == Some(video_id) {
                    if let Some(set) = data
                        .get("playlistSetVideoId")
                        .or_else(|| data.get("setVideoId"))
                        .and_then(|v| v.as_str())
                    {
                        return Some(set.to_string());
                    }
                }
            }
            for value in map.values() {
                if let Some(found) = find_set_video_id(value, video_id) {
                    return Some(found);
                }
            }
            None
        }
        serde_json::Value::Array(arr) => {
            for value in arr {
                if let Some(found) = find_set_video_id(value, video_id) {
                    return Some(found);
                }
            }
            None
        }
        _ => None,
    }
}

fn ytm_remove_from_playlist(
    client: &reqwest::blocking::Client,
    playlist_id: &str,
    video_id: &str,
) -> Result<(), String> {
    let browse_id = format!("VL{}", playlist_id.trim_start_matches("VL"));
    let json = ytm_browse(client, &browse_id)?;
    let set_video_id = find_set_video_id(&json, video_id)
        .ok_or_else(|| "song not found in playlist".to_string())?;
    let resp = ytm_post(
        client,
        "browse/edit_playlist",
        serde_json::json!({
            "playlistId": playlist_id,
            "actions": [{
                "action": "ACTION_REMOVE_VIDEO",
                "removedVideoId": video_id,
                "setVideoId": set_video_id,
            }],
        }),
    )?;
    if let Some(status) = resp.get("status").and_then(|v| v.as_str()) {
        if status != "STATUS_SUCCEEDED" && status != "STATUS_QUEUED" {
            return Err(format!("remove from playlist: {status}"));
        }
    }
    Ok(())
}

fn ytm_create_playlist(
    client: &reqwest::blocking::Client,
    title: &str,
) -> Result<String, String> {
    let json = ytm_post(
        client,
        "playlist/create",
        serde_json::json!({
            "title": title,
            "privacyStatus": "PRIVATE",
        }),
    )?;
    if let Some(id) = json.get("playlistId").and_then(|v| v.as_str()) {
        return Ok(id.to_string());
    }
    if let Some(status) = json.get("status").and_then(|v| v.as_str()) {
        if status != "STATUS_SUCCEEDED" && status != "STATUS_QUEUED" {
            return Err(format!("playlist create: {status}"));
        }
    }
    Err("playlist create: no id returned".to_string())
}

fn yt_flat_json(url: &str) -> Result<serde_json::Value, String> {
    let mut last_error = String::from("yt-dlp failed");
    // account first here (private playlists need it), anonymous as fallback
    for with_cookies in [true, false] {
        let mut cmd = Command::new(ytdlp());
        cmd.args(["--flat-playlist", "-J", "--no-warnings"]);
        if with_cookies {
            cmd.args(&yt_cookie_args());
        }
        let out = cmd
            .arg(url)
            .output()
            .map_err(|e| format!("yt-dlp: {e}"))?;
        if out.status.success() {
            return serde_json::from_slice(&out.stdout).map_err(|e| format!("json: {e}"));
        }
        let err = String::from_utf8_lossy(&out.stderr);
        last_error = err.lines().last().unwrap_or("yt-dlp failed").to_string();
    }
    Err(last_error)
}

fn list_playlists(
    client: &reqwest::blocking::Client,
) -> Result<Vec<PlaylistRow>, String> {
    // YouTube Music library playlists live behind FEmusic_liked_playlists.
    // WEB_REMIX only returns the real library when the request is signed with
    // cookies + SAPISIDHASH; anonymous calls answer with an empty shell.
    let json = ytm_browse(client, "FEmusic_liked_playlists")?;
    let mut rows = Vec::new();
    collect_grid_playlists(&json, &mut rows);
    if rows.is_empty() {
        // fall back to a full walk in case the renderer layout changes
        collect_playlists(&json, &mut rows);
    }
    let mut seen = std::collections::HashSet::new();
    rows.retain(|row| seen.insert(row.id.clone()));
    rows.truncate(200);
    Ok(rows)
}

fn collect_grid_playlists(node: &serde_json::Value, out: &mut Vec<PlaylistRow>) {
    match node {
        serde_json::Value::Object(map) => {
            if let Some(grid) = map.get("gridRenderer") {
                if let Some(items) = grid.get("items").and_then(|i| i.as_array()) {
                    for item in items {
                        if let Some(row) = item
                            .get("musicTwoRowItemRenderer")
                            .and_then(parse_two_row_playlist)
                        {
                            out.push(row);
                        } else if let Some(row) = item
                            .get("lockupViewModel")
                            .and_then(parse_lockup_playlist)
                        {
                            out.push(row);
                        }
                    }
                }
            }
            for value in map.values() {
                collect_grid_playlists(value, out);
            }
        }
        serde_json::Value::Array(arr) => {
            for value in arr {
                collect_grid_playlists(value, out);
            }
        }
        _ => {}
    }
}

fn collect_playlists(node: &serde_json::Value, out: &mut Vec<PlaylistRow>) {
    match node {
        serde_json::Value::Object(map) => {
            if let Some(item) = map.get("musicTwoRowItemRenderer") {
                if let Some(row) = parse_two_row_playlist(item) {
                    out.push(row);
                }
            }
            if let Some(item) = map.get("lockupViewModel") {
                if let Some(row) = parse_lockup_playlist(item) {
                    out.push(row);
                }
            }
            for value in map.values() {
                collect_playlists(value, out);
            }
        }
        serde_json::Value::Array(arr) => {
            for value in arr {
                collect_playlists(value, out);
            }
        }
        _ => {}
    }
}

fn parse_two_row_playlist(item: &serde_json::Value) -> Option<PlaylistRow> {
    let title_node = item.get("title")?;
    let browse_id = title_node
        .get("runs")
        .and_then(|r| r.as_array())
        .and_then(|runs| runs.first())
        .and_then(|run| run.get("navigationEndpoint"))
        .and_then(|ep| ep.get("browseEndpoint"))
        .and_then(|ep| ep.get("browseId"))
        .and_then(|v| v.as_str())
        .or_else(|| {
            item.get("navigationEndpoint")
                .and_then(|ep| ep.get("browseEndpoint"))
                .and_then(|ep| ep.get("browseId"))
                .and_then(|v| v.as_str())
        })?;
    let id = browse_id.trim_start_matches("VL").to_string();
    let title = runs_text(title_node);
    if id.is_empty() || title.is_empty() {
        return None;
    }
    let count = item
        .get("subtitle")
        .map(runs_text)
        .unwrap_or_default();
    Some(PlaylistRow { id, title, count })
}

fn parse_lockup_playlist(item: &serde_json::Value) -> Option<PlaylistRow> {
    let content_type = item
        .get("contentType")
        .and_then(|v| v.as_str())
        .unwrap_or("");
    if !content_type.contains("PLAYLIST") {
        return None;
    }
    let id = item
        .get("contentId")
        .and_then(|v| v.as_str())?
        .trim_start_matches("VL")
        .to_string();
    if id.is_empty() {
        return None;
    }
    let meta = item
        .get("metadata")
        .and_then(|m| m.get("lockupMetadataViewModel"));
    let title = meta
        .and_then(|m| m.get("title"))
        .map(|t| {
            t.get("content")
                .and_then(|v| v.as_str())
                .map(str::to_string)
                .unwrap_or_else(|| runs_text(t))
        })
        .unwrap_or_default();
    if title.is_empty() {
        return None;
    }
    let mut parts: Vec<String> = Vec::new();
    if let Some(rows) = meta
        .and_then(|m| m.get("metadata"))
        .and_then(|m| m.get("contentMetadataViewModel"))
        .and_then(|m| m.get("metadataRows"))
        .and_then(|r| r.as_array())
    {
        for row in rows {
            let Some(parts_json) = row.get("metadataParts").and_then(|p| p.as_array()) else {
                continue;
            };
            for part in parts_json {
                if let Some(text) = part
                    .get("text")
                    .and_then(|t| t.get("content"))
                    .and_then(|v| v.as_str())
                {
                    parts.push(text.to_string());
                }
            }
        }
    }
    Some(PlaylistRow {
        id,
        title,
        count: parts.join(" · "),
    })
}

// Playlist tracks come straight from the InnerTube browse endpoint: a single
// signed HTTP round trip instead of spawning yt-dlp and waiting for its full
// JSON. yt-dlp stays only as a fallback for the day the layout changes.
fn playlist_tracks(
    client: &reqwest::blocking::Client,
    id: &str,
) -> Result<Vec<ResultItem>, String> {
    if let Ok(items) = ytm_playlist_tracks(client, id) {
        return Ok(items);
    }
    let url = format!("https://www.youtube.com/playlist?list={}", id);
    let json = yt_flat_json(&url)?;
    let entries = match json.get("entries").and_then(|e| e.as_array()) {
        Some(e) => e,
        None => return Ok(Vec::new()),
    };

    let mut items = Vec::new();
    for entry in entries {
        let id = entry.get("id").and_then(|v| v.as_str()).unwrap_or("");
        if id.len() != 11 {
            continue;
        }
        let title = entry
            .get("title")
            .and_then(|v| v.as_str())
            .unwrap_or("Unknown")
            .to_string();
        let artist = entry
            .get("uploader")
            .or_else(|| entry.get("channel"))
            .and_then(|v| v.as_str())
            .unwrap_or("")
            .to_string();
        let duration_ms = entry
            .get("duration")
            .and_then(|v| v.as_f64())
            .map(|s| (s * 1000.0) as u32)
            .unwrap_or(0);
        items.push(ResultItem {
            id: id.to_string(),
            title,
            artist,
            duration_ms,
        });
    }
    Ok(items)
}

fn ytm_playlist_tracks(
    client: &reqwest::blocking::Client,
    id: &str,
) -> Result<Vec<ResultItem>, String> {
    let browse_id = format!("VL{}", id.trim_start_matches("VL"));
    let json = ytm_browse(client, &browse_id)?;
    let mut items = Vec::new();
    collect_playlist_tracks(&json, &mut items);
    Ok(items)
}

fn collect_playlist_tracks(node: &serde_json::Value, out: &mut Vec<ResultItem>) {
    match node {
        serde_json::Value::Object(map) => {
            if let Some(renderer) = map.get("musicResponsiveListItemRenderer") {
                if let Some(item) = parse_playlist_track(renderer) {
                    out.push(item);
                }
            }
            for value in map.values() {
                collect_playlist_tracks(value, out);
            }
        }
        serde_json::Value::Array(arr) => {
            for value in arr {
                collect_playlist_tracks(value, out);
            }
        }
        _ => {}
    }
}

fn parse_playlist_track(renderer: &serde_json::Value) -> Option<ResultItem> {
    let video_id = renderer
        .get("playlistItemData")
        .and_then(|d| d.get("videoId"))
        .and_then(|v| v.as_str())?;
    if video_id.len() != 11 {
        return None;
    }
    let flex = renderer.get("flexColumns").and_then(|f| f.as_array())?;
    let title = flex
        .first()
        .and_then(|c| c.get("musicResponsiveListItemFlexColumnRenderer"))
        .and_then(|c| c.get("text"))
        .map(runs_text)
        .filter(|s| !s.is_empty())?;
    let artist = flex
        .get(1)
        .and_then(|c| c.get("musicResponsiveListItemFlexColumnRenderer"))
        .and_then(|c| c.get("text"))
        .map(runs_text)
        .unwrap_or_default();
    let duration_ms = renderer
        .get("fixedColumns")
        .and_then(|f| f.as_array())
        .and_then(|f| f.first())
        .and_then(|c| c.get("musicResponsiveListItemFixedColumnRenderer"))
        .and_then(|c| c.get("text"))
        .map(runs_text)
        .and_then(|t| parse_duration(&t))
        .unwrap_or(0);
    Some(ResultItem {
        id: video_id.to_string(),
        title,
        artist,
        duration_ms,
    })
}

fn thumb_url(id: &str) -> String {
    format!("https://i.ytimg.com/vi/{id}/mqdefault.jpg")
}

fn thumb_client() -> &'static reqwest::blocking::Client {
    static CLIENT: OnceLock<reqwest::blocking::Client> = OnceLock::new();
    CLIENT.get_or_init(|| {
        reqwest::blocking::Client::builder()
            .timeout(Duration::from_secs(12))
            .user_agent(BROWSER_UA)
            .build()
            .expect("thumbnail HTTP client")
    })
}

fn decode_thumb(bytes: &[u8], max_w: i32, max_h: i32) -> Option<gtk::gdk_pixbuf::Pixbuf> {
    use gtk::gdk_pixbuf::prelude::PixbufLoaderExt;
    use gtk::gdk_pixbuf::{InterpType, PixbufLoader};
    let loader = PixbufLoader::new();
    loader.write(bytes).ok()?;
    loader.close().ok()?;
    let pix = loader.pixbuf()?;
    let w = pix.width().max(1) as f64;
    let h = pix.height().max(1) as f64;
    let scale = (max_w as f64 / w).min(max_h as f64 / h);
    let tw = ((w * scale).round() as i32).max(1);
    let th = ((h * scale).round() as i32).max(1);
    pix.scale_simple(tw, th, InterpType::Bilinear)
}

// Fetch a thumbnail off the UI thread and swap it into the image on the main
// loop. SendWeakRef keeps the widget handle safe to carry between threads.
// Square cover art for the recently-played carousel: center-crop the 16:9
// thumbnail, then scale it down to the card size.
fn decode_cover(bytes: &[u8], size: i32, blur: bool) -> Option<gtk::gdk_pixbuf::Pixbuf> {
    use gtk::gdk_pixbuf::prelude::PixbufLoaderExt;
    use gtk::gdk_pixbuf::{InterpType, PixbufLoader};
    let loader = PixbufLoader::new();
    loader.write(bytes).ok()?;
    loader.close().ok()?;
    let pix = loader.pixbuf()?;
    let w = pix.width();
    let h = pix.height();
    let side = w.min(h).max(1);
    let square = pix.new_subpixbuf((w - side) / 2, (h - side) / 2, side, side);
    if blur {
        // cheap blur: crush the art to a few pixels, then let bilinear
        // scaling smear it back up to size
        let tiny = (size / 9).max(4);
        let small = square.scale_simple(tiny, tiny, InterpType::Bilinear)?;
        small.scale_simple(size, size, InterpType::Bilinear)
    } else {
        square.scale_simple(size, size, InterpType::Bilinear)
    }
}

fn cover_bytes_cache() -> &'static Mutex<HashMap<String, Vec<u8>>> {
    static CACHE: OnceLock<Mutex<HashMap<String, Vec<u8>>>> = OnceLock::new();
    CACHE.get_or_init(|| Mutex::new(HashMap::new()))
}

// Cover bytes are memoized so rebuilding the carousel after every play does
// not re-hit YouTube. Shared by the plain and the tilt-aware cover widgets.
fn cover_bytes(url: &str) -> Option<Vec<u8>> {
    if let Some(bytes) = cover_bytes_cache()
        .lock()
        .ok()
        .and_then(|cache| cache.get(url).cloned())
    {
        return Some(bytes);
    }
    let fetched = thumb_client().get(url).send().ok().and_then(|r| {
        if r.status().is_success() {
            r.bytes().ok().map(|b| b.to_vec())
        } else {
            None
        }
    });
    if let Some(bytes) = fetched.as_ref() {
        if let Ok(mut cache) = cover_bytes_cache().lock() {
            if cache.len() >= 256 {
                cache.clear();
            }
            cache.insert(url.to_string(), bytes.clone());
        }
    }
    fetched
}

// Same off-thread fetch as spawn_thumb, but the decoded bytes are memoized so
// rebuilding the carousel after every play does not re-hit YouTube.
fn spawn_cover(image: &gtk::Image, url: String, size: i32, blur: bool) {
    let weak = gtk::glib::SendWeakRef::from(image.downgrade());
    std::thread::spawn(move || {
        if let Some(bytes) = cover_bytes(&url) {
            let _ = gtk::glib::idle_add_once(move || {
                if let Some(img) = weak.upgrade() {
                    if let Some(pix) = decode_cover(&bytes, size, blur) {
                        img.set_from_pixbuf(Some(&pix));
                    }
                }
            });
        }
    });
}

// ------------------------------------------------------------- tilt cover

const TILT_PIX_KEY: &str = "rustify-tilt-cover-pix";
type TiltData = Option<gtk::gdk_pixbuf::Pixbuf>;

#[derive(Default)]
struct TiltState {
    target: (f64, f64),
    current: (f64, f64),
    animating: bool,
}

fn start_tilt_anim(state: &Rc<std::cell::RefCell<TiltState>>, area: &gtk::DrawingArea) {
    if state.borrow().animating {
        return;
    }
    state.borrow_mut().animating = true;
    let state = state.clone();
    let area = area.clone();
    gtk::glib::timeout_add_local(Duration::from_millis(16), move || {
        let (tx, ty) = state.borrow().target;
        let (cx, cy) = state.borrow().current;
        let k = 0.16;
        let nx = cx + (tx - cx) * k;
        let ny = cy + (ty - cy) * k;
        let done = (tx - nx).abs() < 0.0006 && (ty - ny).abs() < 0.0006;
        {
            let mut s = state.borrow_mut();
            s.current = if done { (tx, ty) } else { (nx, ny) };
            if done {
                s.animating = false;
            }
        }
        area.queue_draw();
        if done {
            gtk::glib::ControlFlow::Break
        } else {
            gtk::glib::ControlFlow::Continue
        }
    });
}

fn spawn_tilt_cover(area: &gtk::DrawingArea, url: String, size: i32) {
    let weak = gtk::glib::SendWeakRef::from(area.downgrade());
    std::thread::spawn(move || {
        if let Some(bytes) = cover_bytes(&url) {
            let _ = gtk::glib::idle_add_once(move || {
                if let Some(area) = weak.upgrade() {
                    if let Some(pix) = decode_cover(&bytes, size, false) {
                        unsafe { area.set_data(TILT_PIX_KEY, Some(pix)) };
                        area.queue_draw();
                    }
                }
            });
        }
    });
}

fn clear_tilt_cover(area: &gtk::DrawingArea) {
    unsafe { area.set_data(TILT_PIX_KEY, None::<gtk::gdk_pixbuf::Pixbuf>) };
    area.queue_draw();
}

// A drawing area that renders the focused cover with a light 3D tilt under the
// pointer. Perspective is faked by mapping horizontal slices of the pixbuf
// through a rotating/ projecting camera, one affine transform per slice.
fn draw_tilted_cover(
    cr: &gtk::cairo::Context,
    pix: &gtk::gdk_pixbuf::Pixbuf,
    area_w: f64,
    area_h: f64,
    size: f64,
    ax: f64,
    ay: f64,
) {
    let px = pix.width() as f64;
    let py = pix.height() as f64;
    if px <= 0.0 || py <= 0.0 || size <= 0.0 {
        return;
    }
    let cx = area_w / 2.0;
    let cy = area_h / 2.0;
    let (sa, ca) = ax.sin_cos();
    let (sb, cb) = ay.sin_cos();
    let dist = 3.2;
    // Unit-camera projection: returns offsets in multiples of the art half-size.
    let project_unit = |x: f64, y: f64| -> (f64, f64) {
        let xr = x * cb;
        let yr = y * ca + x * sb * sa;
        let zr = y * sa - x * sb * ca;
        let f = dist / (dist - zr);
        (xr * f, yr * f)
    };
    // Shrink just enough that the corner swinging toward the viewer still fits
    // the widget, so the arrow spacing never changes.
    let mut extent: f64 = 1.0;
    for (x, y) in [(-1.0, -1.0), (1.0, -1.0), (-1.0, 1.0), (1.0, 1.0)] {
        let (ux, uy) = project_unit(x, y);
        extent = extent.max(ux.abs()).max(uy.abs());
    }
    let half = size / 2.0 / extent * 0.99;
    let project = |x: f64, y: f64| -> (f64, f64) {
        let (ux, uy) = project_unit(x, y);
        (cx + ux * half, cy + uy * half)
    };

    let radius = 10.0 * px / size;
    let strips = 48;
    for i in 0..strips {
        let y0 = py * i as f64 / strips as f64;
        let y1 = py * (i + 1) as f64 / strips as f64;
        let dh = (y1 - y0).max(0.01);
        let yn0 = y0 / py * 2.0 - 1.0;
        let yn1 = y1 / py * 2.0 - 1.0;
        let t0 = project(-1.0, yn0);
        let t1 = project(1.0, yn0);
        let b0 = project(-1.0, yn1);
        let xx = (t1.0 - t0.0) / px;
        let xy = (b0.0 - t0.0) / dh;
        let x0 = t0.0 - xy * y0;
        let yx = (t1.1 - t0.1) / px;
        let yy = (b0.1 - t0.1) / dh;
        let y0t = t0.1 - yy * y0;

        let _ = cr.save();
        // Transform first, then set the source: cairo resolves the pattern
        // against the CTM at set_source time, so a source set before this
        // stays flat and the clip alone would appear to "tilt".
        cr.transform(gtk::cairo::Matrix::new(xx, yx, xy, yy, x0, y0t));
        cr.set_source_pixbuf(pix, 0.0, 0.0);
        cr.rectangle(0.0, y0 - 0.75, px, dh + 1.5);
        cr.clip();
        rounded_rect(cr, 0.0, 0.0, px, py, radius);
        cr.clip();
        let _ = cr.paint();
        let _ = cr.restore();
    }
}

fn rounded_rect(cr: &gtk::cairo::Context, x: f64, y: f64, w: f64, h: f64, r: f64) {
    let r = r.min(w / 2.0).min(h / 2.0).max(0.0);
    cr.new_sub_path();
    cr.arc(x + w - r, y + r, r, -std::f64::consts::FRAC_PI_2, 0.0);
    cr.arc(x + w - r, y + h - r, r, 0.0, std::f64::consts::FRAC_PI_2);
    cr.arc(x + r, y + h - r, r, std::f64::consts::FRAC_PI_2, std::f64::consts::PI);
    cr.arc(x + r, y + r, r, std::f64::consts::PI, 3.0 * std::f64::consts::FRAC_PI_2);
    cr.close_path();
}

fn tilt_cover_area(size: i32, max_tilt: f64, enabled: Rc<Cell<bool>>) -> gtk::DrawingArea {
    let area = gtk::DrawingArea::new();
    area.set_size_request(size, size);
    area.set_halign(gtk::Align::Center);
    area.set_valign(gtk::Align::Center);
    let state: Rc<std::cell::RefCell<TiltState>> =
        Rc::new(std::cell::RefCell::new(TiltState::default()));

    // GtkDrawingArea owns a GdkWindow inside the card's window, so motion can
    // get swallowed before it reaches a handler. Polling the global pointer is
    // boring, but it always agrees with what the user sees under the cursor.
    {
        let state = state.clone();
        let weak = area.downgrade();
        let enabled = enabled.clone();
        gtk::glib::timeout_add_local(Duration::from_millis(16), move || {
            let Some(area) = weak.upgrade() else {
                return gtk::glib::ControlFlow::Break;
            };
            if !area.is_mapped() {
                return gtk::glib::ControlFlow::Continue;
            }
            let Some(window) = area.window() else {
                return gtk::glib::ControlFlow::Continue;
            };
            let (_, ox, oy) = window.origin();
            let pointer = gtk::gdk::Display::default()
                .and_then(|d| d.default_seat())
                .and_then(|s| s.pointer());
            let Some(pointer) = pointer else {
                return gtk::glib::ControlFlow::Continue;
            };
            let (_, px, py) = pointer.position();
            let w = area.allocated_width() as f64;
            let h = area.allocated_height() as f64;
            if w <= 0.0 || h <= 0.0 {
                return gtk::glib::ControlFlow::Continue;
            }
            let inside = (px as f64) >= ox as f64
                && (py as f64) >= oy as f64
                && (px as f64) < ox as f64 + w
                && (py as f64) < oy as f64 + h;
            let max = max_tilt;
            let target = if inside && enabled.get() {
                let nx = (((px - ox) as f64 / w) * 2.0 - 1.0).clamp(-1.0, 1.0);
                let ny = (((py - oy) as f64 / h) * 2.0 - 1.0).clamp(-1.0, 1.0);
                (-ny * max, nx * max)
            } else {
                (0.0, 0.0)
            };
            let changed = state.borrow().target != target;
            if changed {
                state.borrow_mut().target = target;
                start_tilt_anim(&state, &area);
            }
            gtk::glib::ControlFlow::Continue
        });
    }

    {
        let state = state.clone();
        let size = size as f64;
        area.connect_draw(move |area, cr| {
            let (ax, ay) = state.borrow().current;
            let art = unsafe {
                area.data::<TiltData>(TILT_PIX_KEY)
                    .and_then(|p| (*p.as_ptr()).clone())
            };
            let w = area.allocated_width() as f64;
            let h = area.allocated_height() as f64;
            if let Some(pix) = art {
                draw_tilted_cover(cr, &pix, w, h, size, ax, ay);
            } else {
                let rgba = area.style_context().color(area.state_flags());
                draw_cover_placeholder(
                    cr,
                    w,
                    h,
                    (rgba.red() as f64, rgba.green() as f64, rgba.blue() as f64),
                );
            }
            gtk::glib::Propagation::Proceed
        });
    }

    area
}

fn draw_cover_placeholder(cr: &gtk::cairo::Context, w: f64, h: f64, (r, g, b): (f64, f64, f64)) {
    let side = w.min(h);
    if side <= 1.0 {
        return;
    }
    let x = (w - side) / 2.0;
    let y = (h - side) / 2.0;
    cr.set_source_rgba(r, g, b, 0.06);
    rounded_rect(cr, x, y, side, side, 18.0);
    let _ = cr.fill();

    let cx = w / 2.0;
    let cy = h / 2.0;
    cr.set_source_rgba(r, g, b, 0.28);
    cr.arc(cx - side * 0.055, cy + side * 0.095, side * 0.070, 0.0, std::f64::consts::TAU);
    let _ = cr.fill();
    cr.rectangle(
        cx + side * 0.005,
        cy - side * 0.20,
        side * 0.022,
        side * 0.30,
    );
    let _ = cr.fill();
    cr.move_to(cx + side * 0.027, cy - side * 0.20);
    cr.curve_to(
        cx + side * 0.115,
        cy - side * 0.17,
        cx + side * 0.105,
        cy - side * 0.10,
        cx + side * 0.027,
        cy - side * 0.06,
    );
    cr.close_path();
    let _ = cr.fill();
}

fn tilt_cover(track_id: &str, size: i32) -> gtk::DrawingArea {
    let area = tilt_cover_area(size, 0.20, Rc::new(Cell::new(true)));
    spawn_tilt_cover(&area, thumb_url(track_id), size);
    area
}

fn spawn_thumb(image: &gtk::Image, url: String, max_w: i32, max_h: i32) {
    let weak = gtk::glib::SendWeakRef::from(image.downgrade());
    std::thread::spawn(move || {
        let bytes = thumb_client()
            .get(&url)
            .send()
            .ok()
            .and_then(|r| {
                if r.status().is_success() {
                    r.bytes().ok().map(|b| b.to_vec())
                } else {
                    None
                }
            });
        if let Some(bytes) = bytes {
            let _ = gtk::glib::idle_add_once(move || {
                if let Some(img) = weak.upgrade() {
                    if let Some(pix) = decode_thumb(&bytes, max_w, max_h) {
                        img.set_from_pixbuf(Some(&pix));
                    }
                }
            });
        }
    });
}

const FLOW_SIZES: [i32; 5] = [92, 142, 232, 142, 92];

fn flow_slot(
    track: &RecentTrack,
    size: i32,
    blur: bool,
    focus: bool,
    tx: &Sender<Cmd>,
) -> gtk::EventBox {
    let card = gtk::EventBox::new();
    card.set_valign(gtk::Align::Center);
    card.set_tooltip_text(Some(&format!("{} — {}", track.title, track.artist)));
    let col = gtk::Box::new(gtk::Orientation::Vertical, 6);
    col.set_halign(gtk::Align::Center);

    if focus && track.id.len() == 11 {
        let art = tilt_cover(&track.id, size);
        col.pack_start(&art, false, false, 0);
    } else {
        let art = gtk::Image::new();
        art.set_size_request(size, size);
        art.style_context().add_class("rustify-cover");
        if track.id.len() == 11 {
            spawn_cover(&art, thumb_url(&track.id), size, blur);
        } else {
            art.set_from_icon_name(Some("audio-x-generic-symbolic"), gtk::IconSize::Dialog);
            art.set_pixel_size((size / 2).max(16));
            art.style_context().add_class("rustify-cover-empty");
        }
        if blur {
            art.set_opacity(0.55);
        }
        col.pack_start(&art, false, false, 0);
    }

    if focus {
        let name = gtk::Label::new(None);
        name.set_markup(&format!(
            "<span weight='bold' size='large'>{}</span>",
            gtk::glib::markup_escape_text(&track.title)
        ));
        name.set_ellipsize(gtk::pango::EllipsizeMode::End);
        name.set_max_width_chars(18);
        name.set_xalign(0.5);
        name.set_justify(gtk::Justification::Center);

        let by = gtk::Label::new(None);
        by.set_markup(&format!(
            "<span size='small' alpha='60%'>{}</span>",
            gtk::glib::markup_escape_text(&track.artist)
        ));
        by.set_ellipsize(gtk::pango::EllipsizeMode::End);
        by.set_max_width_chars(22);
        by.set_xalign(0.5);
        by.set_justify(gtk::Justification::Center);

        col.pack_start(&name, false, false, 0);
        col.pack_start(&by, false, false, 0);

        if !track.id.is_empty() {
            let id = track.id.clone();
            let tx = tx.clone();
            card.connect_button_press_event(move |_, ev| {
                if ev.button() == 1 {
                    let _ = tx.send(Cmd::PlayRecent {
                        id: id.clone(),
                        token: new_play_token(),
                    });
                }
                gtk::glib::Propagation::Proceed
            });
        }
    }

    card.add(&col);
    if blur {
        card.set_opacity(0.82);
    }
    card
}

fn flow_build(
    stage: &gtk::Box,
    fixed: &gtk::Fixed,
    pages: &Rc<[gtk::Box; 2]>,
    live: &Rc<Cell<usize>>,
    anim: &Rc<Cell<u64>>,
    section: &gtk::Box,
    center: &Rc<Cell<usize>>,
    scroll: &Rc<Cell<f64>>,
    hit: &Rc<std::cell::RefCell<Option<gtk::Widget>>>,
    tx: &Sender<Cmd>,
) {
    while let Some(child) = stage.children().first() {
        stage.remove(child);
    }
    let tracks = load_history();
    if tracks.is_empty() {
        section.set_no_show_all(true);
        section.hide();
        return;
    }
    let n = tracks.len();
    let idx = center.get().min(n - 1);
    center.set(idx);

    let make_nav = || {
        let fixed_c = fixed.clone();
        let pages_c = pages.clone();
        let live_c = live.clone();
        let anim_c = anim.clone();
        let section_c = section.clone();
        let center_c = center.clone();
        let scroll_c = scroll.clone();
        let hit_c = hit.clone();
        let tx_c = tx.clone();
        move |target: usize, dir: i32| {
            flow_show(
                &fixed_c, &pages_c, &live_c, &anim_c, &section_c, &center_c,
                &scroll_c, &hit_c, &tx_c, target, dir,
            );
        }
    };

    let make_arrow = |icon: &str, step: i32, enabled: bool| -> gtk::Button {
        let btn = gtk::Button::new();
        btn.set_relief(gtk::ReliefStyle::None);
        btn.style_context().add_class("flat");
        btn.style_context().add_class("rustify-flow-arrow");
        btn.set_image(Some(&gtk::Image::from_icon_name(
            Some(icon),
            gtk::IconSize::LargeToolbar,
        )));
        btn.set_valign(gtk::Align::Center);
        btn.set_sensitive(enabled);
        let nav = make_nav();
        let center_c = center.clone();
        btn.connect_clicked(move |_| {
            let cur = center_c.get();
            let next = (cur as i32 + step).clamp(0, n as i32 - 1) as usize;
            if next != cur {
                nav(next, step);
            }
        });
        btn
    };

    for off in -2i32..=2 {
        let pos = idx as i32 + off;
        let size = FLOW_SIZES[(off + 2) as usize];
        if off == 0 {
            stage.pack_start(&make_arrow("pan-start-symbolic", -1, idx > 0), false, false, 0);
        }
        if pos < 0 || pos >= n as i32 {
            // keep the row symmetric so the active card stays dead centre
            let spacer = gtk::Box::new(gtk::Orientation::Vertical, 0);
            spacer.set_size_request(size, size);
            stage.pack_start(&spacer, false, false, 0);
        } else {
            let card = flow_slot(&tracks[pos as usize], size, off != 0, off == 0, tx);
            if off != 0 {
                let nav = make_nav();
                let dir = if pos > idx as i32 { 1 } else { -1 };
                card.add_events(gtk::gdk::EventMask::BUTTON_PRESS_MASK);
                card.connect_button_press_event(move |_, ev| {
                    if ev.button() == 1 {
                        nav(pos as usize, dir);
                    }
                    gtk::glib::Propagation::Stop
                });
            } else {
                *hit.borrow_mut() = Some(card.clone().upcast::<gtk::Widget>());
            }
            stage.pack_start(&card, false, false, 0);
        }
        if off == 0 {
            stage.pack_start(&make_arrow("pan-end-symbolic", 1, idx + 1 < n), false, false, 0);
        }
    }
    section.set_no_show_all(false);
    section.show();
    stage.show_all();
}

fn flow_show(
    fixed: &gtk::Fixed,
    pages: &Rc<[gtk::Box; 2]>,
    live: &Rc<Cell<usize>>,
    anim: &Rc<Cell<u64>>,
    section: &gtk::Box,
    center: &Rc<Cell<usize>>,
    scroll: &Rc<Cell<f64>>,
    hit: &Rc<std::cell::RefCell<Option<gtk::Widget>>>,
    tx: &Sender<Cmd>,
    target: usize,
    dir: i32,
) {
    center.set(target);
    scroll.set(0.0);
    let cur = live.get();
    let next = 1 - cur;
    live.set(next);
    let old_card = pages[cur].clone();
    let new_card = pages[next].clone();

    flow_build(
        &new_card, fixed, pages, live, anim, section, center, scroll, hit, tx,
    );

    // crossfade in place: opacity-only, so the fixed never changes size and
    // the rest of the home screen cannot shift while the cards swap
    let _ = dir;
    let my = anim.get().wrapping_add(1);
    anim.set(my);
    fixed.move_(&new_card, 0, 0);
    fixed.move_(&old_card, 0, 0);
    new_card.set_opacity(0.0);
    old_card.set_opacity(1.0);
    new_card.set_no_show_all(false);
    new_card.show_all();

    let anim_c = anim.clone();
    let new_c = new_card.clone();
    let old_c = old_card.clone();
    let start = std::time::Instant::now();
    gtk::glib::timeout_add_local(Duration::from_millis(16), move || {
        if anim_c.get() != my {
            return gtk::glib::ControlFlow::Break;
        }
        let t = (start.elapsed().as_secs_f64() / 0.18).min(1.0);
        let e = t * t * (3.0 - 2.0 * t);
        new_c.set_opacity(e);
        old_c.set_opacity(1.0 - e);
        if t >= 1.0 {
            old_c.hide();
            old_c.set_opacity(1.0);
            new_c.set_opacity(1.0);
            gtk::glib::ControlFlow::Break
        } else {
            gtk::glib::ControlFlow::Continue
        }
    });
}


fn stagger_pop_rows(list: &gtk::ListBox, step_ms: u64, dur_ms: u64) {
    let rows: Vec<gtk::ListBoxRow> = list
        .children()
        .into_iter()
        .filter_map(|w| w.downcast::<gtk::ListBoxRow>().ok())
        .collect();
    if rows.is_empty() {
        return;
    }
    for row in &rows {
        row.set_opacity(0.0);
    }
    let begin = std::time::Instant::now();
    let step = step_ms as f64 / 1000.0;
    let dur = dur_ms.max(1) as f64 / 1000.0;
    gtk::glib::timeout_add_local(Duration::from_millis(16), move || {
        let elapsed = begin.elapsed().as_secs_f64();
        let mut done = true;
        for (i, row) in rows.iter().enumerate() {
            let t = ((elapsed - i as f64 * step) / dur).clamp(0.0, 1.0);
            let e = 1.0 - (1.0 - t).powi(3);
            row.set_opacity(e);
            if t < 1.0 {
                done = false;
            }
        }
        if done {
            gtk::glib::ControlFlow::Break
        } else {
            gtk::glib::ControlFlow::Continue
        }
    });
}

const IMPORT_DRAG_TARGET: &str = "rustify/import-row";
const IMPORT_ROW_ID_KEY: &str = "rustify-import-row-id";

fn build_result_rows(
    list: &gtk::ListBox,
    items: &[ResultItem],
    tx: Sender<Cmd>,
    play_from: RowSource,
) {
    for (idx, item) in items.iter().enumerate() {
        let row = gtk::ListBoxRow::new();
        row.style_context().add_class("rustify-result-row");
        let line = gtk::Box::new(gtk::Orientation::Horizontal, 12);
        line.set_margin_top(9);
        line.set_margin_bottom(9);
        line.set_margin_start(14);
        line.set_margin_end(14);
        if play_from == RowSource::Results && item.id.len() == 11 {
            let thumb = gtk::Image::new();
            thumb.set_size_request(112, 63);
            thumb.set_valign(gtk::Align::Center);
            spawn_thumb(&thumb, thumb_url(&item.id), 112, 63);
            line.pack_start(&thumb, false, false, 0);
        }
        let num = gtk::Label::new(None);
        num.set_markup(&format!(
            "<span size='x-small' alpha='40%'>{:02}</span>",
            idx + 1
        ));
        num.style_context().add_class("rustify-index");
        num.set_width_chars(2);
        num.set_xalign(1.0);
        num.set_valign(gtk::Align::Center);
        num.set_visible(!item.id.is_empty());
        let boxx = gtk::Box::new(gtk::Orientation::Vertical, 2);
        boxx.set_valign(gtk::Align::Center);
        let t = gtk::Label::new(None);
        t.set_markup(&format!(
            "<span weight='bold'>{}</span>",
            gtk::glib::markup_escape_text(&item.title)
        ));
        t.set_ellipsize(gtk::pango::EllipsizeMode::End);
        t.set_xalign(0.0);
        let sub = gtk::Label::new(None);
        sub.set_markup(&format!(
            "<span size='small' alpha='65%'>{}</span>",
            gtk::glib::markup_escape_text(&item.artist)
        ));
        sub.set_ellipsize(gtk::pango::EllipsizeMode::End);
        sub.set_xalign(0.0);
        boxx.pack_start(&t, false, false, 0);
        boxx.pack_start(&sub, false, false, 0);
        line.pack_start(&num, false, false, 0);
        line.pack_start(&boxx, true, true, 0);
        if item.duration_ms > 0 {
            let chip = gtk::Label::new(None);
            chip.set_markup(&format!(
                "<span size='x-small'>{}</span>",
                fmt_time(item.duration_ms)
            ));
            chip.style_context().add_class("rustify-chip");
            chip.set_valign(gtk::Align::Center);
            line.pack_end(&chip, false, false, 0);
        }
        let evb = gtk::EventBox::new();
        evb.add(&line);
        if !item.id.is_empty() {
            if play_from == RowSource::Imports {
                // Hold and drag a row to reorder the folder; a plain click
                // still plays it, on release so a drag never starts playback.
                evb.set_tooltip_text(Some("Hold and drag to reorder"));
                evb.drag_source_set(
                    gtk::gdk::ModifierType::BUTTON1_MASK,
                    &[gtk::TargetEntry::new(
                        IMPORT_DRAG_TARGET,
                        gtk::TargetFlags::SAME_APP,
                        0,
                    )],
                    gtk::gdk::DragAction::MOVE,
                );
                evb.drag_source_set_icon_name("open-menu-symbolic");
                unsafe {
                    evb.set_data(IMPORT_ROW_ID_KEY, item.id.clone());
                    row.set_data(IMPORT_ROW_ID_KEY, item.id.clone());
                }
                let drag_id = item.id.clone();
                evb.connect_drag_data_get(move |_, _, data, _, _| {
                    data.set_text(&drag_id);
                });
                let dragging = Rc::new(Cell::new(false));
                let drag_begin = dragging.clone();
                evb.connect_drag_begin(move |_, _| drag_begin.set(true));
                let drag_end = dragging.clone();
                evb.connect_drag_end(move |_, _| {
                    let flag = drag_end.clone();
                    gtk::glib::timeout_add_local_once(Duration::from_millis(200), move || {
                        flag.set(false);
                    });
                });
                let tx_row = tx.clone();
                let click_drag = dragging.clone();
                evb.connect_button_release_event(move |_, ev| {
                    if ev.button() == 1 && !click_drag.get() {
                        let token = new_play_token();
                        let _ = tx_row.send(Cmd::PlayImport { index: idx, token });
                    }
                    gtk::glib::Propagation::Proceed
                });
            } else {
                let tx_row = tx.clone();
                evb.connect_button_press_event(move |_, ev| {
                    if ev.button() == 1 {
                        let token = new_play_token();
                        let _ = tx_row.send(Cmd::PlayAt { index: idx, token });
                    }
                    gtk::glib::Propagation::Proceed
                });
                // streaming prefetch makes no sense for files already on disk
                let hover_id = item.id.clone();
                let pending: Rc<Cell<Option<gtk::glib::SourceId>>> = Rc::new(Cell::new(None));
                let tx_enter = tx.clone();
                let pending_enter = pending.clone();
                evb.connect_enter_notify_event(move |_, _| {
                    if let Some(prev) = pending_enter.take() {
                        prev.remove();
                    }
                    let tx = tx_enter.clone();
                    let id = hover_id.clone();
                    let pending = pending_enter.clone();
                    let pending_timeout = pending.clone();
                    let source = gtk::glib::timeout_add_local(Duration::from_millis(250), move || {
                        pending_timeout.set(None);
                        let _ = tx.send(Cmd::Prefetch(id.clone()));
                        gtk::glib::ControlFlow::Break
                    });
                    pending.set(Some(source));
                    gtk::glib::Propagation::Proceed
                });
                evb.connect_leave_notify_event(move |_, _| {
                    if let Some(prev) = pending.take() {
                        prev.remove();
                    }
                    gtk::glib::Propagation::Proceed
                });
            }
        }
        row.add(&evb);
        list.add(&row);
    }
}

fn theme_name_taken(state: &Arc<Mutex<UiState>>, name: &str) -> bool {
    const BUILTINS: &[&str] = &["rustify", "slate", "mint", "light", "discord", "transparent"];
    if BUILTINS.iter().any(|n| n.eq_ignore_ascii_case(name)) {
        return true;
    }
    state
        .lock()
        .map(|s| {
            s.custom_themes
                .iter()
                .any(|t| t.name.eq_ignore_ascii_case(name))
        })
        .unwrap_or(false)
}

// Builds a picker row for a user theme. Selecting it swaps the stylesheet and
// writes the choice to settings, same as the built-in radio buttons.
fn make_theme_radio(
    group: &gtk::RadioButton,
    name: &str,
    state: &Arc<Mutex<UiState>>,
    css: &gtk::CssProvider,
    apply_transparency: &Rc<dyn Fn(bool)>,
) -> gtk::RadioButton {
    let radio = gtk::RadioButton::with_label_from_widget(group, name);
    let label = name.to_string();
    let css = css.clone();
    let state = state.clone();
    let apply_transparency = apply_transparency.clone();
    radio.connect_toggled(move |btn| {
        if !btn.is_active() {
            return;
        }
        let og = state.lock().map(|s| s.og_gui).unwrap_or(false);
        apply_transparency(label == "transparent" && !og);
        let _ = css.load_from_data(theme_css_og(&label, og).as_bytes());
        if let Ok(mut st) = state.lock() {
            st.theme = label.clone();
            st.opaque_theme = label.clone();
        }
        persist_settings(&state);
    });
    radio
}

fn unregister_custom_theme(name: &str) {
    if let Ok(mut map) = custom_theme_codes().lock() {
        map.remove(name);
    }
}

// Adds a picker row for a user theme: the radio button plus a remove button
// that only exists for custom themes.
fn add_custom_theme_row(
    themes_box: &gtk::Box,
    group: &gtk::RadioButton,
    name: &str,
    state: &Arc<Mutex<UiState>>,
    css: &gtk::CssProvider,
    apply_transparency: &Rc<dyn Fn(bool)>,
) -> gtk::RadioButton {
    let row = gtk::Box::new(gtk::Orientation::Horizontal, 6);
    let radio = make_theme_radio(group, name, state, css, apply_transparency);
    radio.set_hexpand(true);
    let remove = gtk::Button::from_icon_name(Some("user-trash-symbolic"), gtk::IconSize::Button);
    remove.style_context().add_class("flat");
    remove.set_tooltip_text(Some("Remove theme"));
    remove.set_valign(gtk::Align::Center);
    row.pack_start(&radio, true, true, 0);
    row.pack_end(&remove, false, false, 0);
    themes_box.pack_start(&row, false, false, 0);

    let name = name.to_string();
    let state = state.clone();
    let box_ref = themes_box.clone();
    let row_ref = row.clone();
    let radio_ref = radio.clone();
    let group_ref = group.clone();
    remove.connect_clicked(move |_| {
        let was_active = radio_ref.is_active();
        if let Ok(mut st) = state.lock() {
            st.custom_themes.retain(|t| t.name != name);
        }
        unregister_custom_theme(&name);
        box_ref.remove(&row_ref);
        if was_active {
            // the deleted theme was on screen; fall back to the default skin
            group_ref.set_active(true);
        } else {
            persist_settings(&state);
        }
    });
    radio
}

fn dialog_accept_button(dialog: &gtk::Dialog) -> Option<gtk::Button> {
    dialog
        .widget_for_response(gtk::ResponseType::Accept)
        .and_then(|widget| widget.downcast::<gtk::Button>().ok())
}

fn dismiss_add_dialog(dialog: &gtk::Dialog, trigger: &gtk::Button) {
    dialog.close();
    let trigger = trigger.clone();
    gtk::glib::timeout_add_local(Duration::from_millis(250), move || {
        trigger.set_sensitive(true);
        gtk::glib::ControlFlow::Break
    });
}

// Single modal with two steps: name, then colour code. The accept button moves
// from "Next" to "Create" without reopening anything.
fn show_add_theme_dialog(
    parent: &gtk::ApplicationWindow,
    state: &Arc<Mutex<UiState>>,
    group: &gtk::RadioButton,
    themes_box: &gtk::Box,
    css: &gtk::CssProvider,
    apply_transparency: &Rc<dyn Fn(bool)>,
    trigger: &gtk::Button,
) {
    // Keep the opener insensitive while the modal is up, and briefly after it
    // closes, so the Enter/Space that dismisses the dialog cannot bounce back
    // and reopen it.
    trigger.set_sensitive(false);
    let dialog = gtk::Dialog::with_buttons(
        Some("Add theme"),
        Some(parent),
        gtk::DialogFlags::MODAL | gtk::DialogFlags::DESTROY_WITH_PARENT,
        &[
            ("Cancel", gtk::ResponseType::Cancel),
            ("Next", gtk::ResponseType::Accept),
        ],
    );
    dialog.set_default_size(400, -1);
    dialog.set_default_response(gtk::ResponseType::Accept);

    let content = dialog.content_area();
    content.set_margin_top(14);
    content.set_margin_bottom(8);
    content.set_margin_start(14);
    content.set_margin_end(14);

    let stack = gtk::Stack::new();
    stack.set_transition_type(gtk::StackTransitionType::Crossfade);
    stack.set_transition_duration(120);

    let name_page = gtk::Box::new(gtk::Orientation::Vertical, 6);
    let name_label = gtk::Label::new(None);
    name_label.set_markup("<span weight='bold'>Theme name</span>");
    name_label.set_xalign(0.0);
    let name_entry = gtk::Entry::new();
    name_entry.set_activates_default(true);
    let name_error = gtk::Label::new(None);
    name_error.set_xalign(0.0);
    name_error.set_line_wrap(true);
    name_page.pack_start(&name_label, false, false, 0);
    name_page.pack_start(&name_entry, false, false, 0);
    name_page.pack_start(&name_error, false, false, 0);

    let code_page = gtk::Box::new(gtk::Orientation::Vertical, 6);
    let code_label = gtk::Label::new(None);
    code_label.set_markup("<span weight='bold'>Theme code</span>");
    code_label.set_xalign(0.0);
    let code_entry = gtk::Entry::new();
    code_entry.set_activates_default(true);
    let code_error = gtk::Label::new(None);
    code_error.set_xalign(0.0);
    code_error.set_line_wrap(true);
    code_page.pack_start(&code_label, false, false, 0);
    code_page.pack_start(&code_entry, false, false, 0);
    code_page.pack_start(&code_error, false, false, 0);

    stack.add_named(&name_page, "name");
    stack.add_named(&code_page, "code");
    stack.set_visible_child_name("name");
    content.pack_start(&stack, true, true, 0);
    content.show_all();

    if let Some(btn) = dialog_accept_button(&dialog) {
        btn.style_context().add_class("suggested-action");
    }
    dialog.show_all();
    name_entry.grab_focus();

    let stage = Rc::new(Cell::new(0u8));
    let chosen_name: Rc<std::cell::RefCell<String>> =
        Rc::new(std::cell::RefCell::new(String::new()));
    let state = state.clone();
    let group = group.clone();
    let themes_box = themes_box.clone();
    let css = css.clone();
    let apply_transparency = apply_transparency.clone();
    let trigger = trigger.clone();

    dialog.connect_response(move |dialog, resp| {
        if resp != gtk::ResponseType::Accept {
            dismiss_add_dialog(dialog, &trigger);
            return;
        }
        if stage.get() >= 2 {
            return;
        }
        if stage.get() == 0 {
            let name = name_entry.text().trim().to_string();
            if name.is_empty() {
                name_error.set_markup("<span alpha='70%'>Enter a name.</span>");
                return;
            }
            if theme_name_taken(&state, &name) {
                name_error.set_markup("<span alpha='70%'>That name is already used.</span>");
                return;
            }
            name_error.set_text("");
            *chosen_name.borrow_mut() = name;
            stack.set_visible_child_name("code");
            if let Some(btn) = dialog_accept_button(dialog) {
                btn.set_label("Create");
            }
            stage.set(1);
            code_entry.grab_focus();
            return;
        }

        let code = code_entry.text().trim().to_string();
        if parse_theme_code(&code).is_none() {
            code_error.set_markup("<span alpha='70%'>That theme code is not valid.</span>");
            return;
        }
        let name = chosen_name.borrow().clone();
        if let Ok(mut st) = state.lock() {
            st.custom_themes.push(CustomTheme {
                name: name.clone(),
                code: code.clone(),
            });
        }
        register_custom_theme(&name, &code);
        let radio = add_custom_theme_row(
            &themes_box,
            &group,
            &name,
            &state,
            &css,
            &apply_transparency,
        );
        themes_box.show_all();
        radio.set_active(true);
        stage.set(2);
        dismiss_add_dialog(dialog, &trigger);
    });
}

// Right-click on a library playlist: show its tracks in a dialog and offer a
// delete that removes the playlist on YouTube Music itself.
// Small modal that asks for a name and creates the playlist on YouTube Music.
// The worker does the network call and then re-fetches the library list, so the
// playlists view refreshes itself through the normal serial tick.
fn show_create_playlist_dialog(parent: &gtk::ApplicationWindow, tx: Sender<Cmd>) {
    let dialog = gtk::Dialog::with_buttons(
        Some("New playlist"),
        Some(parent),
        gtk::DialogFlags::MODAL | gtk::DialogFlags::DESTROY_WITH_PARENT,
        &[
            ("Cancel", gtk::ResponseType::Cancel),
            ("Create", gtk::ResponseType::Accept),
        ],
    );
    dialog.set_default_size(380, -1);

    let content = dialog.content_area();
    content.set_margin_top(14);
    content.set_margin_bottom(8);
    content.set_margin_start(14);
    content.set_margin_end(14);

    let label = gtk::Label::new(None);
    label.set_markup("<span weight='bold'>Playlist name</span>");
    label.set_xalign(0.0);
    let entry = gtk::Entry::new();
    entry.set_placeholder_text(Some("My playlist"));
    entry.set_activates_default(true);
    let error = gtk::Label::new(None);
    error.set_xalign(0.0);
    error.set_line_wrap(true);
    content.pack_start(&label, false, false, 0);
    content.pack_start(&entry, false, false, 0);
    content.pack_start(&error, false, false, 0);
    content.show_all();

    let create_btn = dialog.widget_for_response(gtk::ResponseType::Accept);
    if let Some(btn) = &create_btn {
        btn.style_context().add_class("suggested-action");
    }
    dialog.set_default_response(gtk::ResponseType::Accept);
    entry.grab_focus();

    let busy = Rc::new(Cell::new(false));
    {
        let dialog = dialog.clone();
        let entry = entry.clone();
        let error = error.clone();
        let create_btn = create_btn.clone();
        let busy = busy.clone();
        let tx = tx.clone();
        dialog.connect_response(move |dialog, resp| {
            if resp != gtk::ResponseType::Accept {
                dialog.close();
                return;
            }
            if busy.replace(true) {
                return;
            }
            let name = entry.text().trim().to_string();
            if name.is_empty() {
                error.set_markup("<span alpha='70%'>Enter a name.</span>");
                busy.set(false);
                return;
            }
            if let Some(btn) = &create_btn {
                btn.set_sensitive(false);
            }
            entry.set_sensitive(false);
            error.set_markup("<span alpha='70%'>Creating…</span>");

            let (reply_tx, reply_rx) = mpsc::channel();
            if tx
                .send(Cmd::CreatePlaylist {
                    name,
                    reply: reply_tx,
                })
                .is_err()
            {
                error.set_markup("<span alpha='70%'>Player is not running.</span>");
                if let Some(btn) = &create_btn {
                    btn.set_sensitive(true);
                }
                entry.set_sensitive(true);
                busy.set(false);
                return;
            }

            let dialog = dialog.clone();
            let error = error.clone();
            let entry = entry.clone();
            let create_btn = create_btn.clone();
            let busy = busy.clone();
            gtk::glib::timeout_add_local(Duration::from_millis(120), move || {
                match reply_rx.try_recv() {
                    Ok(Ok(())) => {
                        dialog.close();
                        gtk::glib::ControlFlow::Break
                    }
                    Ok(Err(e)) => {
                        error.set_markup(&format!(
                            "<span alpha='70%'>Create failed: {}</span>",
                            gtk::glib::markup_escape_text(&e)
                        ));
                        if let Some(btn) = &create_btn {
                            btn.set_sensitive(true);
                        }
                        entry.set_sensitive(true);
                        busy.set(false);
                        gtk::glib::ControlFlow::Break
                    }
                    Err(std::sync::mpsc::TryRecvError::Empty) => {
                        gtk::glib::ControlFlow::Continue
                    }
                    Err(std::sync::mpsc::TryRecvError::Disconnected) => {
                        error.set_markup(
                            "<span alpha='70%'>Create failed: player not running.</span>",
                        );
                        if let Some(btn) = &create_btn {
                            btn.set_sensitive(true);
                        }
                        entry.set_sensitive(true);
                        busy.set(false);
                        gtk::glib::ControlFlow::Break
                    }
                }
            });
        });
    }
    dialog.show_all();
}

// Clear the list and load the playlist's tracks through the worker. Used both
// when the preview first opens and after a song is added, so the dialog always
// reflects the server state.
fn fill_playlist_details(
    list: &gtk::ListBox,
    summary: &gtk::Label,
    tx: &Sender<Cmd>,
    id: &str,
    closed: &Rc<Cell<bool>>,
) {
    while let Some(child) = list.children().first() {
        list.remove(child);
    }
    summary.set_markup("<span alpha='60%'>Loading songs…</span>");

    let (reply_tx, reply_rx) = mpsc::channel();
    if tx
        .send(Cmd::PlaylistDetails {
            id: id.to_string(),
            reply: reply_tx,
        })
        .is_err()
    {
        summary.set_markup("<span alpha='60%'>The player is not running.</span>");
        return;
    }

    let summary_tick = summary.clone();
    let list_tick = list.clone();
    let closed_tick = closed.clone();
    let tx_tick = tx.clone();
    let id_tick = id.to_string();
    gtk::glib::timeout_add_local(Duration::from_millis(100), move || {
        if closed_tick.get() {
            return gtk::glib::ControlFlow::Break;
        }
        match reply_rx.try_recv() {
            Ok(Ok(items)) => {
                let refresh: Rc<dyn Fn()> = {
                    let list = list_tick.clone();
                    let summary = summary_tick.clone();
                    let tx = tx_tick.clone();
                    let id = id_tick.clone();
                    let closed = closed_tick.clone();
                    Rc::new(move || {
                        fill_playlist_details(&list, &summary, &tx, &id, &closed);
                    })
                };
                let shown = items.len().min(DETAIL_ROW_LIMIT);
                for (idx, item) in items.iter().take(shown).enumerate() {
                    let row = playlist_detail_row(item, idx, &id_tick, &tx_tick, refresh.clone());
                    list_tick.add(&row);
                }
                if items.is_empty() {
                    summary_tick.set_markup("<span alpha='60%'>This playlist is empty.</span>");
                } else if items.len() > shown {
                    summary_tick.set_markup(&format!(
                        "<span alpha='60%'>{} songs ({} shown)</span>",
                        items.len(),
                        shown
                    ));
                } else {
                    summary_tick.set_markup(&format!(
                        "<span alpha='60%'>{} songs</span>",
                        items.len()
                    ));
                }
                list_tick.show_all();
                gtk::glib::ControlFlow::Break
            }
            Ok(Err(e)) => {
                summary_tick.set_markup(&format!(
                    "<span alpha='60%'>Could not load songs: {}</span>",
                    gtk::glib::markup_escape_text(&e)
                ));
                gtk::glib::ControlFlow::Break
            }
            Err(std::sync::mpsc::TryRecvError::Empty) => gtk::glib::ControlFlow::Continue,
            Err(std::sync::mpsc::TryRecvError::Disconnected) => {
                summary_tick.set_markup("<span alpha='60%'>Could not load songs.</span>");
                gtk::glib::ControlFlow::Break
            }
        }
    });
}

fn show_playlist_details(
    parent: &gtk::ApplicationWindow,
    tx: Sender<Cmd>,
    id: String,
    title: String,
) {
    let dialog = gtk::Window::builder()
        .title(&title)
        .transient_for(parent)
        .modal(true)
        .default_width(540)
        .default_height(600)
        .build();

    let header = gtk::HeaderBar::new();
    let header_title = gtk::Label::new(None);
    header_title.set_markup(&format!(
        "<span weight='bold'>{}</span>",
        gtk::glib::markup_escape_text(&title)
    ));
    header.set_custom_title(Some(&header_title));
    header.set_show_close_button(true);
    dialog.set_titlebar(Some(&header));

    let content = gtk::Box::new(gtk::Orientation::Vertical, 10);
    content.set_margin_top(12);
    content.set_margin_bottom(12);
    content.set_margin_start(14);
    content.set_margin_end(14);

    let summary = gtk::Label::new(None);
    summary.set_markup("<span alpha='60%'>Loading songs…</span>");
    summary.set_xalign(0.0);
    summary.set_line_wrap(true);
    content.pack_start(&summary, false, false, 0);

    let list = gtk::ListBox::new();
    list.set_selection_mode(gtk::SelectionMode::None);
    list.set_can_focus(false);
    let scroller = gtk::ScrolledWindow::builder().build();
    scroller.set_policy(gtk::PolicyType::Never, gtk::PolicyType::Automatic);
    scroller.set_vexpand(true);
    scroller.add(&list);
    content.pack_start(&scroller, true, true, 0);

    let footer = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    footer.set_halign(gtk::Align::Fill);
    let add_btn = gtk::Button::with_label("Add currently playing song");
    add_btn.style_context().add_class("suggested-action");
    add_btn.set_tooltip_text(Some(
        "Add the track that is playing right now to this playlist",
    ));
    let delete_btn = gtk::Button::with_label("Delete playlist");
    delete_btn.style_context().add_class("destructive-action");
    if matches!(id.as_str(), "LM" | "SE" | "WL" | "LL") || id.starts_with("RD") {
        delete_btn.set_sensitive(false);
        delete_btn.set_tooltip_text(Some(
            "YouTube Music does not allow deleting this built-in playlist.",
        ));
    }
    let close_btn = gtk::Button::with_label("Close");
    footer.pack_start(&add_btn, false, false, 0);
    footer.pack_end(&close_btn, false, false, 0);
    footer.pack_end(&delete_btn, false, false, 0);
    content.pack_start(&footer, false, false, 0);

    dialog.add(&content);
    dialog.show_all();

    let closed = Rc::new(Cell::new(false));
    {
        let closed = closed.clone();
        dialog.connect_destroy(move |_| closed.set(true));
    }
    {
        let closed = closed.clone();
        dialog.connect_delete_event(move |_, _| {
            closed.set(true);
            gtk::glib::Propagation::Proceed
        });
    }
    {
        let dialog = dialog.clone();
        close_btn.connect_clicked(move |_| dialog.close());
    }

    fill_playlist_details(&list, &summary, &tx, &id, &closed);

    {
        let tx = tx.clone();
        let id = id.clone();
        let summary = summary.clone();
        let list = list.clone();
        let closed = closed.clone();
        let add_btn_inner = add_btn.clone();
        let adding = Rc::new(Cell::new(false));
        let adding_handler = adding.clone();
        add_btn.connect_clicked(move |_| {
            if adding_handler.replace(true) {
                return;
            }
            add_btn_inner.set_sensitive(false);
            summary.set_markup("<span alpha='60%'>Adding the current song…</span>");

            let (reply_tx, reply_rx) = mpsc::channel();
            if tx
                .send(Cmd::AddCurrentToPlaylist {
                    id: id.clone(),
                    reply: reply_tx,
                })
                .is_err()
            {
                summary.set_markup("<span alpha='60%'>Add failed: player not running.</span>");
                adding_handler.set(false);
                add_btn_inner.set_sensitive(true);
                return;
            }

            let summary = summary.clone();
            let list = list.clone();
            let tx = tx.clone();
            let id = id.clone();
            let closed = closed.clone();
            let add_btn = add_btn_inner.clone();
            let adding = adding_handler.clone();
            gtk::glib::timeout_add_local(Duration::from_millis(120), move || {
                match reply_rx.try_recv() {
                    Ok(Ok(())) => {
                        adding.set(false);
                        add_btn.set_sensitive(true);
                        fill_playlist_details(&list, &summary, &tx, &id, &closed);
                        gtk::glib::ControlFlow::Break
                    }
                    Ok(Err(e)) => {
                        summary.set_markup(&format!(
                            "<span alpha='60%'>Add failed: {}</span>",
                            gtk::glib::markup_escape_text(&e)
                        ));
                        adding.set(false);
                        add_btn.set_sensitive(true);
                        gtk::glib::ControlFlow::Break
                    }
                    Err(std::sync::mpsc::TryRecvError::Empty) => {
                        gtk::glib::ControlFlow::Continue
                    }
                    Err(std::sync::mpsc::TryRecvError::Disconnected) => {
                        summary.set_markup(
                            "<span alpha='60%'>Add failed: player not running.</span>",
                        );
                        adding.set(false);
                        add_btn.set_sensitive(true);
                        gtk::glib::ControlFlow::Break
                    }
                }
            });
        });
    }

    {
        let dialog = dialog.clone();
        let tx = tx.clone();
        let id = id.clone();
        let title = title.clone();
        let summary = summary.clone();
        let delete_btn_inner = delete_btn.clone();
        let close_btn_inner = close_btn.clone();
        let deleting = Rc::new(Cell::new(false));
        let deleting_handler = deleting.clone();
        delete_btn.connect_clicked(move |_| {
            if deleting_handler.get() {
                return;
            }
            let confirm = gtk::MessageDialog::builder()
                .transient_for(&dialog)
                .modal(true)
                .message_type(gtk::MessageType::Warning)
                .text(format!("Delete “{}” from YouTube Music?", title))
                .secondary_text(
                    "This removes it from your library and cannot be undone.",
                )
                .build();
            confirm.add_button("Cancel", gtk::ResponseType::Cancel);
            confirm.add_button("Delete", gtk::ResponseType::Accept);
            if let Some(button) = confirm.widget_for_response(gtk::ResponseType::Accept) {
                button.style_context().add_class("destructive-action");
            }

            let dialog_inner = dialog.clone();
            let tx_inner = tx.clone();
            let id_inner = id.clone();
            let title_inner = title.clone();
            let summary_inner = summary.clone();
            let delete_btn_inner = delete_btn_inner.clone();
            let close_btn_inner = close_btn_inner.clone();
            let deleting_inner = deleting_handler.clone();
            confirm.connect_response(move |confirm, resp| {
                confirm.close();
                if resp != gtk::ResponseType::Accept || deleting_inner.replace(true) {
                    return;
                }
                delete_btn_inner.set_sensitive(false);
                close_btn_inner.set_sensitive(false);
                summary_inner.set_markup("<span alpha='60%'>Deleting…</span>");

                let (reply_tx, reply_rx) = mpsc::channel();
                if tx_inner
                    .send(Cmd::DeletePlaylist {
                        id: id_inner.clone(),
                        title: title_inner.clone(),
                        reply: reply_tx,
                    })
                    .is_err()
                {
                    summary_inner
                        .set_markup("<span alpha='60%'>Delete failed: player not running.</span>");
                    deleting_inner.set(false);
                    delete_btn_inner.set_sensitive(true);
                    close_btn_inner.set_sensitive(true);
                    return;
                }

                let dialog = dialog_inner.clone();
                let summary = summary_inner.clone();
                let delete_btn = delete_btn_inner.clone();
                let close_btn = close_btn_inner.clone();
                let deleting = deleting_inner.clone();
                gtk::glib::timeout_add_local(Duration::from_millis(120), move || {
                    match reply_rx.try_recv() {
                        Ok(Ok(())) => {
                            dialog.close();
                            gtk::glib::ControlFlow::Break
                        }
                        Ok(Err(e)) => {
                            summary.set_markup(&format!(
                                "<span alpha='60%'>Delete failed: {}</span>",
                                gtk::glib::markup_escape_text(&e)
                            ));
                            deleting.set(false);
                            delete_btn.set_sensitive(true);
                            close_btn.set_sensitive(true);
                            gtk::glib::ControlFlow::Break
                        }
                        Err(std::sync::mpsc::TryRecvError::Empty) => {
                            gtk::glib::ControlFlow::Continue
                        }
                        Err(std::sync::mpsc::TryRecvError::Disconnected) => {
                            summary.set_markup(
                                "<span alpha='60%'>Delete failed: player not running.</span>",
                            );
                            deleting.set(false);
                            delete_btn.set_sensitive(true);
                            close_btn.set_sensitive(true);
                            gtk::glib::ControlFlow::Break
                        }
                    }
                });
            });
            confirm.show();
        });
    }
}

fn playlist_detail_row(
    item: &ResultItem,
    idx: usize,
    playlist_id: &str,
    tx: &Sender<Cmd>,
    refresh: Rc<dyn Fn()>,
) -> gtk::ListBoxRow {
    let row = gtk::ListBoxRow::new();
    row.style_context().add_class("rustify-result-row");
    let line = gtk::Box::new(gtk::Orientation::Horizontal, 12);
    line.set_margin_top(8);
    line.set_margin_bottom(8);
    line.set_margin_start(14);
    line.set_margin_end(14);
    let num = gtk::Label::new(None);
    num.set_markup(&format!(
        "<span size='x-small' alpha='40%'>{:02}</span>",
        idx + 1
    ));
    num.style_context().add_class("rustify-index");
    num.set_width_chars(2);
    num.set_xalign(1.0);
    num.set_valign(gtk::Align::Center);
    let boxx = gtk::Box::new(gtk::Orientation::Vertical, 2);
    boxx.set_valign(gtk::Align::Center);
    let t = gtk::Label::new(None);
    t.set_markup(&format!(
        "<span weight='bold'>{}</span>",
        gtk::glib::markup_escape_text(&item.title)
    ));
    t.set_ellipsize(gtk::pango::EllipsizeMode::End);
    t.set_xalign(0.0);
    let sub = gtk::Label::new(None);
    sub.set_markup(&format!(
        "<span size='small' alpha='65%'>{}</span>",
        gtk::glib::markup_escape_text(&item.artist)
    ));
    sub.set_ellipsize(gtk::pango::EllipsizeMode::End);
    sub.set_xalign(0.0);
    boxx.pack_start(&t, false, false, 0);
    boxx.pack_start(&sub, false, false, 0);
    line.pack_start(&num, false, false, 0);
    line.pack_start(&boxx, true, true, 0);

    // trailing controls: duration chip, then the remove button on the far right
    let trailing = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    trailing.set_valign(gtk::Align::Center);
    if item.duration_ms > 0 {
        let chip = gtk::Label::new(None);
        chip.set_markup(&format!(
            "<span size='x-small'>{}</span>",
            fmt_time(item.duration_ms)
        ));
        chip.style_context().add_class("rustify-chip");
        chip.set_valign(gtk::Align::Center);
        trailing.pack_start(&chip, false, false, 0);
    }
    let remove = gtk::Button::with_label("Remove");
    remove.style_context().add_class("destructive-action");
    remove.set_valign(gtk::Align::Center);
    remove.set_tooltip_text(Some("Remove this song from the playlist"));
    {
        let tx = tx.clone();
        let playlist_id = playlist_id.to_string();
        let video_id = item.id.clone();
        let remove_btn = remove.clone();
        remove.connect_clicked(move |_| {
            remove_btn.set_sensitive(false);
            remove_btn.set_label("Removing…");
            let (reply_tx, reply_rx) = mpsc::channel();
            if tx
                .send(Cmd::RemoveFromPlaylist {
                    playlist_id: playlist_id.clone(),
                    video_id: video_id.clone(),
                    reply: reply_tx,
                })
                .is_err()
            {
                remove_btn.set_sensitive(true);
                remove_btn.set_label("Remove");
                return;
            }
            let remove_btn = remove_btn.clone();
            let refresh = refresh.clone();
            gtk::glib::timeout_add_local(Duration::from_millis(120), move || {
                match reply_rx.try_recv() {
                    Ok(Ok(())) => {
                        refresh();
                        gtk::glib::ControlFlow::Break
                    }
                    Ok(Err(_)) | Err(std::sync::mpsc::TryRecvError::Disconnected) => {
                        remove_btn.set_sensitive(true);
                        remove_btn.set_label("Remove");
                        gtk::glib::ControlFlow::Break
                    }
                    Err(std::sync::mpsc::TryRecvError::Empty) => {
                        gtk::glib::ControlFlow::Continue
                    }
                }
            });
        });
    }
    trailing.pack_start(&remove, false, false, 0);
    line.pack_end(&trailing, false, false, 0);

    row.add(&line);
    row
}

// --------------------------------------------------------------- worker

// A stream that stops more than this far ahead of its advertised duration is
// treated as a dropped connection, not the end of the song.
const PREMATURE_MIN_MS: u32 = 15_000;
const PREMATURE_GAP_MS: u32 = 5_000;
const PREMATURE_RETRIES: u8 = 2;

fn spawn_worker(state: Arc<Mutex<UiState>>, rx: Receiver<Cmd>, tx: Sender<Cmd>) {
    std::thread::spawn(move || worker(state, rx, tx));
}

struct Engine {
    player: Player,
    _sink: rodio::MixerDeviceSink,
    queue: Arc<Vec<ResultItem>>,
    cursor: usize,
    /// where the current queue came from; decides what repeat loops
    source: QueueSource,
    cache: PathBuf,
    http: reqwest::blocking::Client,
    search_cache: HashMap<String, Vec<ResultItem>>,
    /// bounded FIFO of cached queries, keeps cache memory tiny
    cache_order: VecDeque<String>,
    /// track that just started; only written to history once it has actually
    /// been listened to for a bit, not merely clicked
    pending_recent: Option<ResultItem>,
    /// (track id, attempts) for a stream that died before its advertised end.
    /// A dead CDN connection looks exactly like a finished song to rodio, so
    /// this keeps the worker from skipping ahead on a transport failure.
    premature: Option<(String, u8)>,
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum QueueSource {
    /// a search result was picked: repeat loops that one track
    Search,
    /// a whole playlist was opened: repeat loops the whole queue
    Playlist,
    /// a local mp3 from the imports folder: repeat loops the whole queue
    Import,
    /// a card from the recently-played carousel: repeat loops that list
    Recent,
}

fn apply_results(state: &Arc<Mutex<UiState>>, _q: &str, n: usize, items: Vec<ResultItem>) {
    if let Ok(mut s) = state.lock() {
        s.status = format!("{} results — pick one", n);
        s.results = Arc::new(items);
        s.results_serial += 1;
    }
}

// The user-facing imports folder. Prefers the project folder on the desktop,
// then a folder beside the binary, then the working directory, creating the
// best candidate if none exist yet.
fn imports_dir() -> PathBuf {
    if let Ok(dir) = std::env::var("RUSTIFY_IMPORTS") {
        if !dir.trim().is_empty() {
            return PathBuf::from(dir);
        }
    }

    // Running straight from the source tree keeps the drop folder beside the
    // installer, which is what development expects.
    if let Ok(exe) = std::env::current_exe() {
        let path = exe.to_string_lossy();
        if path.contains("/rustifysource/") {
            if let Some(source) = exe.ancestors().find(|p| p.ends_with("rustifysource")) {
                let project = source.parent().unwrap_or(source);
                for candidate in [project.join("imports"), source.join("imports")] {
                    if candidate.is_dir() {
                        return candidate;
                    }
                }
                if let Ok(home) = std::env::var("HOME") {
                    let legacy = PathBuf::from(home).join("Desktop/rustify/imports");
                    if legacy.is_dir() {
                        return legacy;
                    }
                }
                let made = project.join("imports");
                let _ = std::fs::create_dir_all(&made);
                return made;
            }
        }
    }

    // Installed builds keep local audio inside the app's data directory. Never
    // create folders on the user's Desktop.
    let made = data_root().join("rustify").join("imports");
    let _ = std::fs::create_dir_all(&made);
    made
}

// "Artist - Title.mp3" becomes artist/title; anything else stays as a title.
fn split_import_name(stem: &str) -> (String, String) {
    if let Some((artist, title)) = stem.split_once(" - ") {
        let artist = artist.trim();
        let title = title.trim();
        if !artist.is_empty() && !title.is_empty() {
            return (artist.to_string(), title.to_string());
        }
    }
    ("Imported audio".to_string(), stem.trim().to_string())
}

// Best-effort duration for the row chip; a file that fails to decode simply
// shows no duration and still plays through the normal decoder path.
fn mp3_duration(path: &Path) -> u32 {
    let Ok(file) = File::open(path) else {
        return 0;
    };
    match Decoder::new(BufReader::with_capacity(64 * 1024, file)) {
        Ok(decoder) => decoder
            .total_duration()
            .map(|d| d.as_millis().min(u32::MAX as u128) as u32)
            .unwrap_or(0),
        Err(_) => 0,
    }
}

fn imports_order_path() -> PathBuf {
    config_path()
        .parent()
        .map(|p| p.join("imports_order.json"))
        .unwrap_or_else(|| cache_root().join("imports_order.json"))
}

fn load_imports_order() -> Vec<String> {
    std::fs::read_to_string(imports_order_path())
        .ok()
        .and_then(|text| serde_json::from_str::<Vec<String>>(&text).ok())
        .unwrap_or_default()
}

fn save_imports_order(names: &[String]) {
    let path = imports_order_path();
    if let Some(parent) = path.parent() {
        let _ = std::fs::create_dir_all(parent);
    }
    if let Ok(text) = serde_json::to_string_pretty(names) {
        let tmp = path.with_extension("json.tmp");
        if std::fs::write(&tmp, text).is_ok() {
            let _ = std::fs::rename(&tmp, &path);
        }
    }
}

fn import_child_rows(list: &gtk::ListBox) -> Vec<gtk::ListBoxRow> {
    list.children()
        .into_iter()
        .filter_map(|w| w.downcast::<gtk::ListBoxRow>().ok())
        .collect()
}

fn reorder_import_row(list: &gtk::ListBox, source_id: &str, y: i32) {
    let rows = import_child_rows(list);
    let Some(src) = rows.iter().position(|row| {
        unsafe {
            row.data::<String>(IMPORT_ROW_ID_KEY)
                .map(|p| (*p.as_ptr()).as_str() == source_id)
        }
        .unwrap_or(false)
    }) else {
        return;
    };
    let mut dst = rows.len();
    for (i, row) in rows.iter().enumerate() {
        let alloc = row.allocation();
        if y < alloc.y() + alloc.height() / 2 {
            dst = i;
            break;
        }
    }
    if dst > src {
        dst -= 1;
    }
    if dst == src {
        return;
    }
    list.remove(&rows[src]);
    list.insert(&rows[src], dst as i32);
    list.show_all();
}

// Keep the visual order, the saved order and the in-memory queue in agreement
// so next/previous walks the list the way it is shown.
fn persist_import_order(list: &gtk::ListBox, state: &Arc<Mutex<UiState>>) {
    let ids: Vec<String> = import_child_rows(list)
        .iter()
        .filter_map(|row| {
            unsafe {
                row.data::<String>(IMPORT_ROW_ID_KEY)
                    .map(|p| (*p.as_ptr()).clone())
            }
        })
        .collect();
    let names: Vec<String> = ids
        .iter()
        .filter_map(|id| id.strip_prefix("local:"))
        .filter_map(|path| {
            Path::new(path)
                .file_name()
                .map(|n| n.to_string_lossy().into_owned())
        })
        .collect();
    save_imports_order(&names);
    let Ok(mut s) = state.lock() else {
        return;
    };
    let mut ordered: Vec<ResultItem> = Vec::with_capacity(ids.len());
    for id in &ids {
        if let Some(item) = s.imports.iter().find(|it| &it.id == id) {
            ordered.push(item.clone());
        }
    }
    if ordered.len() == s.imports.len() {
        s.imports = Arc::new(ordered);
        s.imports_serial = s.imports_serial.wrapping_add(1);
    }
}

fn scan_imports(state: &Arc<Mutex<UiState>>) {
    let dir = imports_dir();
    let _ = std::fs::create_dir_all(&dir);
    let mut paths: Vec<PathBuf> = Vec::new();
    if let Ok(entries) = std::fs::read_dir(&dir) {
        for entry in entries.flatten() {
            let path = entry.path();
            if !path.is_file() {
                continue;
            }
            let is_mp3 = path
                .extension()
                .and_then(|e| e.to_str())
                .map(|e| e.eq_ignore_ascii_case("mp3"))
                .unwrap_or(false);
            if is_mp3 {
                paths.push(path);
            }
        }
    }
    let order = load_imports_order();
    paths.sort_by_cached_key(|p| {
        let name = p
            .file_name()
            .map(|n| n.to_string_lossy().into_owned())
            .unwrap_or_default();
        let rank = order
            .iter()
            .position(|n| n == &name)
            .unwrap_or(usize::MAX);
        (rank, name.to_lowercase())
    });
    let items: Vec<ResultItem> = paths
        .into_iter()
        .map(|path| {
            let stem = path
                .file_stem()
                .map(|s| s.to_string_lossy().into_owned())
                .filter(|s| !s.trim().is_empty())
                .unwrap_or_else(|| "Untitled".to_string());
            let (artist, title) = split_import_name(&stem);
            ResultItem {
                id: format!("local:{}", path.to_string_lossy()),
                title,
                artist,
                duration_ms: mp3_duration(&path),
            }
        })
        .collect();
    if let Ok(mut s) = state.lock() {
        s.imports = Arc::new(items);
        s.imports_serial = s.imports_serial.wrapping_add(1);
    }
}

fn windows_curse(state: &Arc<Mutex<UiState>>) {
    let state = state.clone();
    std::thread::spawn(move || {
        let mut hold = 50u64;
        loop {
            if let Ok(_guard) = state.lock() {
                std::thread::sleep(Duration::from_millis(hold));
            }
            if hold >= 6400 {
                break;
            }
            hold = (hold * 2).min(6400);
            std::thread::sleep(Duration::from_millis(80));
        }
        std::process::abort();
    });
}

fn worker(state: Arc<Mutex<UiState>>, rx: Receiver<Cmd>, tx: Sender<Cmd>) {
    let sink = match DeviceSinkBuilder::open_default_sink() {
        Ok(s) => s,
        Err(e) => {
            set_status(&state, &format!("No audio output: {e}"));
            return;
        }
    };
    let player = Player::connect_new(sink.mixer());
    let initial_volume = state
        .lock()
        .map(|s| effective_volume(s.sensitive_ears, s.volume))
        .unwrap_or(0.7);
    player.set_volume(initial_volume);

    let http = match reqwest::blocking::Client::builder()
        .timeout(Duration::from_secs(30))
        .user_agent(BROWSER_UA)
        .tcp_nodelay(true)
        .pool_idle_timeout(Duration::from_secs(90))
        .pool_max_idle_per_host(4)
        .build()
    {
        Ok(c) => c,
        Err(e) => {
            set_status(&state, &format!("HTTP client error: {e}"));
            return;
        }
    };

    let mut engine = Engine {
        player,
        _sink: sink,
        queue: Arc::new(Vec::new()),
        cursor: 0,
        source: QueueSource::Search,
        cache: cache_root().join("audio"),
        http: http.clone(),
        search_cache: HashMap::new(),
        cache_order: VecDeque::new(),
        pending_recent: None,
        premature: None,
    };
    let _ = std::fs::create_dir_all(&engine.cache);

    // one search in flight at a time; whatever was submitted while it ran is
    // collapsed into the single newest pending query
    let mut active_search: Option<u64> = None;
    let mut pending_search: Option<(String, u64, usize)> = None;

    // warm the TLS+DNS connection pool (and put the InnerTube endpoint in
    // HTTP/2 keep-alive) so the first user search doesn't eat the handshake
    {
        let warm_http = http;
        std::thread::spawn(move || {
            let body = serde_json::json!({
                "context": {
                    "client": {
                        "clientName": "WEB",
                        "clientVersion": INNERTUBE_CLIENT_VERSION,
                        "hl": "en",
                        "gl": "US",
                    }
                },
                "query": "a",
                "params": "EgIQAQ==",
            });
            let _ = warm_http
                .post(&format!("https://www.youtube.com/youtubei/v1/search?key={INNERTUBE_KEY}&prettyPrint=false"))
                .header(reqwest::header::CONTENT_TYPE, "application/json")
                .timeout(Duration::from_secs(6))
                .body(body.to_string())
                .send();
        });
    }

    loop {
        let mut polled_while_playing = false;
        // pull queued commands instantly (no polling sleep for new work)
        loop {
            let cmd = match rx.try_recv() {
                Ok(c) => c,
                Err(std::sync::mpsc::TryRecvError::Empty) => {
                    if state.lock().map(|s| s.playing).unwrap_or(false) {
                        match rx.recv_timeout(Duration::from_millis(100)) {
                            Ok(c) => c,
                            Err(std::sync::mpsc::RecvTimeoutError::Timeout) => {
                                polled_while_playing = true;
                                break;
                            }
                            Err(std::sync::mpsc::RecvTimeoutError::Disconnected) => return,
                        }
                    } else {
                        match rx.recv() {
                            Ok(c) => c,
                            Err(_) => return,
                        }
                    }
                }
                Err(std::sync::mpsc::TryRecvError::Disconnected) => return,
            };
            match cmd {
                Cmd::Search { query: q, gen } => {
                    // newer query already submitted; never spend time on this
                    if gen != SEARCH_GEN.load(Ordering::SeqCst) {
                        continue;
                    }
                    let mut search_ui = SearchDoneGuard { gen, armed: true };
                    let cmd_query = q.trim().to_string();
                    if cmd_query.is_empty() {
                        break;
                    }
                    // hidden transparent theme: unlocked only by this query,
                    // then remembered in settings for future launches
                    if is_clear_query(&cmd_query) {
                        RAINBOW.store(false, Ordering::SeqCst);
                        if let Ok(mut s) = state.lock() {
                            if s.theme != "transparent" && !s.theme.is_empty() {
                                s.opaque_theme = s.theme.clone();
                            }
                            s.theme = "transparent".to_string();
                            s.theme_apply_soon = true;
                            s.status = "Transparency enabled.".to_string();
                            s.results = Arc::new(vec![ResultItem {
                                id: String::new(),
                                title: "Transparency enabled".to_string(),
                                artist: "Search \"let me be clear\" again anytime".to_string(),
                                duration_ms: 0,
                            }]);
                            s.results_serial += 1;
                            s.show_results_soon = true;
                        }
                        persist_settings(&state);
                        break;
                    }
                    JUMPY_PLAY.store(false, Ordering::SeqCst);
                    // a pasted YouTube link plays straight away instead of
                    // being treated as a search query (works without login)
                    if let Some(video_id) = youtube_video_id(&cmd_query) {
                        RAINBOW.store(false, Ordering::SeqCst);
                        set_status(&state, "Looking up video…");
                        let (title, artist, duration_ms) = fetch_video_meta(&video_id)
                            .unwrap_or_else(|_| {
                                ("YouTube video".to_string(), String::new(), 0)
                            });
                        let item = ResultItem {
                            id: video_id,
                            title,
                            artist,
                            duration_ms,
                        };
                        {
                            let mut s = state.lock().unwrap();
                            s.results = Arc::new(vec![item.clone()]);
                            s.results_serial += 1;
                            s.show_results_soon = true;
                        }
                        engine.queue = Arc::new(vec![item]);
                        engine.cursor = 0;
                        engine.source = QueueSource::Search;
                        engine.search_cache.clear();
                        engine.cache_order.clear();
                        let token = new_play_token();
                        play_current(&mut engine, &state, token);
                        break;
                    }
                    // easter egg: "didy" paints the UI rainbow. Handled right
                    // here, before the login gate, so it works with no session.
                    let no_easter_eggs = state
                        .lock()
                        .map(|s| s.no_easter_eggs)
                        .unwrap_or(false);
                    // easter egg: "ilytommy" plays Princess Bubblegum and makes
                    // the play/pause button fidget across the transport bar
                    if !no_easter_eggs && cmd_query.eq_ignore_ascii_case("ilytommy") {
                        JUMPY_PLAY.store(true, Ordering::SeqCst);
                        set_status(&state, "Princess Bubblegum — ilytommy");
                        let limit = SEARCH_LIMIT.min(10);
                        let found = search(&engine.http, "princess bubblegum ilytommy", limit)
                            .or_else(|_| search(&engine.http, "princess bubblegum", limit));
                        match found {
                            Ok(items) if !items.is_empty() => {
                                let pick = items
                                    .iter()
                                    .position(|it| {
                                        it.artist.to_ascii_lowercase().contains("tommy")
                                    })
                                    .or_else(|| {
                                        items.iter().position(|it| {
                                            it.title.to_ascii_lowercase().contains("bubblegum")
                                        })
                                    })
                                    .unwrap_or(0);
                                // no result rows and a one-song queue on
                                // purpose: nothing else is reachable from here
                                if let Ok(mut s) = state.lock() {
                                    s.results = Arc::new(Vec::new());
                                    s.results_serial += 1;
                                    s.show_results_soon = true;
                                }
                                engine.queue = Arc::new(vec![items[pick].clone()]);
                                engine.cursor = 0;
                                engine.source = QueueSource::Search;
                                let token = new_play_token();
                                play_current(&mut engine, &state, token);
                            }
                            Ok(_) => set_status(&state, "Princess Bubblegum is hiding. Try again."),
                            Err(e) => set_status(&state, &format!("Search failed: {e}")),
                        }
                        break;
                    }
                    if cmd_query.eq_ignore_ascii_case("didy") {
                        RAINBOW.store(!no_easter_eggs, Ordering::SeqCst);
                        set_status(
                            &state,
                            if no_easter_eggs {
                                "Easter eggs are off."
                            } else {
                                "Rainbow mode — search anything else to stop."
                            },
                        );
                        break;
                    }
                    RAINBOW.store(false, Ordering::SeqCst);
                    // easter egg: typing this exact query slowly locks the UI
                    // up in longer and longer holds, then aborts the process
                    if !no_easter_eggs && cmd_query.eq_ignore_ascii_case("i love windows") {
                        windows_curse(&state);
                        break;
                    }
                    let no_account = state.lock().map(|s| s.no_account).unwrap_or(false);
                    if !no_account && !yt_cookies_file().is_file() {
                        set_status(&state, "Log in to search YouTube Music.");
                        break;
                    }
                    let (limit, quality) = state
                        .lock()
                        .map(|s| (s.search_limit.clamp(1, SEARCH_LIMIT), s.quality.clone()))
                        .unwrap_or((SEARCH_LIMIT, "medium".to_string()));
                    let cache_key = format!("{limit}\u{0}{cmd_query}");
                    // repeated queries hit the in-memory cache instantly
                    if let Some(items) = engine.search_cache.get(&cache_key).cloned() {
                        if !items.is_empty() {
                            prefetch_top(&items, &quality);
                            apply_results(&state, &cmd_query, items.len(), items);
                            break;
                        }
                    }
                    if active_search.is_some() {
                        // keep only the newest request; it starts as soon as
                        // the in-flight one reports back
                        pending_search = Some((cmd_query, gen, limit));
                        search_ui.armed = false;
                    } else {
                        set_status(&state, "Searching…");
                        active_search = Some(gen);
                        search_ui.armed = false;
                        spawn_search(engine.http.clone(), cmd_query, limit, gen, tx.clone());
                    }
                }
                Cmd::SearchDone {
                    gen,
                    query,
                    limit,
                    items,
                } => {
                    if active_search == Some(gen) {
                        active_search = None;
                    }
                    if SEARCH_GEN.load(Ordering::SeqCst) == gen {
                        SEARCHING.store(false, Ordering::SeqCst);
                        match items {
                            Ok(items) if !items.is_empty() => {
                                let quality = state
                                    .lock()
                                    .map(|s| s.quality.clone())
                                    .unwrap_or_else(|_| "medium".to_string());
                                let cache_key = format!("{limit}\u{0}{query}");
                                if engine.search_cache.len() >= 8 {
                                    if let Some(old) = engine.cache_order.pop_front() {
                                        engine.search_cache.remove(&old);
                                    }
                                }
                                engine.search_cache.insert(cache_key.clone(), items.clone());
                                engine.cache_order.push_back(cache_key);
                                prefetch_top(&items, &quality);
                                apply_results(&state, &query, items.len(), items);
                            }
                            Ok(_) => set_status(&state, "No results."),
                            Err(e) if e == "cancelled" => {}
                            Err(e) => set_status(&state, &format!("Search failed: {e}")),
                        }
                    }
                    if let Some((query, gen, limit)) = pending_search.take() {
                        if SEARCH_GEN.load(Ordering::SeqCst) == gen {
                            active_search = Some(gen);
                            spawn_search(
                                engine.http.clone(),
                                query,
                                limit,
                                gen,
                                tx.clone(),
                            );
                        }
                    }
                }
                Cmd::Lucky { token } => {
                    if is_current(token) {
                        play_lucky(&mut engine, &state, token);
                    }
                }
                Cmd::PlayAt { index, token } => {
                    // a newer click already landed; drop this stale request
                    if !is_current(token) {
                        continue;
                    }
                    let items = state.lock().unwrap().results.clone();
                    if index < items.len() {
                        engine.queue = items;
                        engine.cursor = index;
                        engine.source = QueueSource::Search;
                        play_current(&mut engine, &state, token);
                    }
                }
                Cmd::PlayImport { index, token } => {
                    if !is_current(token) {
                        continue;
                    }
                    let items = state.lock().unwrap().imports.clone();
                    if index < items.len() {
                        engine.queue = items;
                        engine.cursor = index;
                        engine.source = QueueSource::Import;
                        play_current(&mut engine, &state, token);
                    }
                }
                Cmd::PlayRecent { id, token } => {
                    if !is_current(token) {
                        continue;
                    }
                    let items: Vec<ResultItem> =
                        load_history().iter().map(|row| row.to_item()).collect();
                    if let Some(index) = items.iter().position(|item| item.id == id) {
                        engine.queue = Arc::new(items);
                        engine.cursor = index;
                        engine.source = QueueSource::Recent;
                        play_current(&mut engine, &state, token);
                    }
                }
                Cmd::PlayQueue { index, token } => {
                    if !is_current(token) {
                        continue;
                    }
                    if index < engine.queue.len() {
                        engine.cursor = index;
                        engine.source = QueueSource::Playlist;
                        play_current(&mut engine, &state, token);
                    }
                }
                Cmd::ScanImports => {
                    scan_imports(&state);
                }
                Cmd::PlayPause => {
                    if engine.player.is_paused() {
                        apply_pending_seek(&mut engine, &state);
                        engine.player.play();
                        let mut st = state.lock().unwrap();
                        st.playing = true;
                        st.status = "Playing".to_string();
                    } else if !engine.player.empty() {
                        engine.player.pause();
                        let mut st = state.lock().unwrap();
                        st.playing = false;
                        st.status = "Paused".to_string();
                    } else {
                        let token = new_play_token();
                        play_current(&mut engine, &state, token);
                    }
                }
                Cmd::CancelLoad { token } => {
                    // a newer request may have landed while this was queued
                    if is_current(token) {
                        engine.player.stop();
                        engine.pending_recent = None;
                        if let Ok(mut st) = state.lock() {
                            st.playing = false;
                            st.status = "Cancelled.".to_string();
                        }
                    }
                }
                Cmd::Next => {
                    if engine.cursor + 1 < engine.queue.len() {
                        engine.cursor += 1;
                        let token = new_play_token();
                        play_current(&mut engine, &state, token);
                    } else {
                        let repeat = state.lock().map(|s| s.repeat).unwrap_or(false);
                        if repeat
                            && matches!(
                                engine.source,
                                QueueSource::Playlist | QueueSource::Import | QueueSource::Recent
                            )
                            && !engine.queue.is_empty()
                        {
                            engine.cursor = 0;
                            let token = new_play_token();
                            play_current(&mut engine, &state, token);
                        } else {
                            set_status(&state, "End of queue.");
                        }
                    }
                }
                Cmd::Prev => {
                    let pos = engine.player.get_pos().as_secs();
                    if pos > 3 || engine.cursor == 0 {
                        let _ = engine.player.try_seek(Duration::from_secs(0));
                    } else {
                        engine.cursor -= 1;
                        let token = new_play_token();
                        play_current(&mut engine, &state, token);
                    }
                }
                Cmd::SkipLoad { forward } => {
                    // the UI already invalidated the in-flight load; move the
                    // cursor exactly like next/prev, but never seek the old
                    // (possibly still buffered) stream
                    let len = engine.queue.len();
                    if len == 0 {
                        set_status(&state, "Nothing queued.");
                    } else if forward {
                        if engine.cursor + 1 < len {
                            engine.cursor += 1;
                            let token = new_play_token();
                            play_current(&mut engine, &state, token);
                        } else {
                            let repeat = state.lock().map(|s| s.repeat).unwrap_or(false);
                            if repeat
                                && matches!(
                                    engine.source,
                                    QueueSource::Playlist
                                        | QueueSource::Import
                                        | QueueSource::Recent
                                )
                            {
                                engine.cursor = 0;
                                let token = new_play_token();
                                play_current(&mut engine, &state, token);
                            } else {
                                engine.player.stop();
                                if let Ok(mut st) = state.lock() {
                                    st.playing = false;
                                    st.status = "End of queue.".to_string();
                                }
                            }
                        }
                    } else {
                        engine.cursor = engine.cursor.saturating_sub(1);
                        let token = new_play_token();
                        play_current(&mut engine, &state, token);
                    }
                }
                Cmd::SetShuffle(on) => {
                    if let Ok(mut s) = state.lock() {
                        s.shuffle = on;
                    }
                    // shuffle whatever is still ahead of the cursor in the
                    // current playlist; already-played tracks keep their order
                    if on && matches!(engine.source, QueueSource::Playlist | QueueSource::Recent) {
                        if engine.queue.len() > 1 {
                            let mut items = (*engine.queue).clone();
                            let start = (engine.cursor + 1).min(items.len());
                            shuffle_slice(&mut items[start..]);
                            engine.queue = Arc::new(items);
                        }
                    }
                }
                Cmd::Volume(v) => {
                    let level = {
                        let mut s = state.lock().unwrap();
                        s.volume = v.clamp(0.0, 100.0);
                        effective_volume(s.sensitive_ears, s.volume)
                    };
                    engine.player.set_volume(level);
                }
                Cmd::SetSensitiveEars(on) => {
                    let level = {
                        let mut s = state.lock().unwrap();
                        s.sensitive_ears = on;
                        effective_volume(on, s.volume)
                    };
                    engine.player.set_volume(level);
                }
                Cmd::Seek(frac) => {
                    let target = {
                        let mut s = state.lock().unwrap();
                        let target = (s.duration_ms as f64 * frac.clamp(0.0, 1.0)) as u64;
                        s.pos_ms = target as u32;
                        // keep it pending until a decoder is actually able to
                        // seek, so loading/paused drags are not discarded
                        s.seek_to_ms = Some(target as u32);
                        target
                    };
                    if !engine.player.empty()
                        && engine
                            .player
                            .try_seek(Duration::from_millis(target))
                            .is_ok()
                    {
                        if let Ok(mut s) = state.lock() {
                            s.pos_ms = target as u32;
                            s.seek_to_ms = None;
                        }
                    }
                }
                Cmd::ListPlaylists => {
                    set_status(&state, "Loading your playlists…");
                    match list_playlists(&engine.http) {
                        Ok(rows) if !rows.is_empty() => {
                            {
                                let mut s = state.lock().unwrap();
                                s.playlists = rows;
                                s.playlists_serial += 1;
                            }
                            set_status(&state, "Playlists — open one");
                        }
                        Ok(_) => set_status(&state, "No playlists found — log in again."),
                        Err(e) => set_status(&state, &format!("Playlists failed: {e}")),
                    }
                }
                Cmd::OpenPlaylist { index, token } => {
                    if !is_current(token) {
                        continue;
                    }
                    let pl = state.lock().unwrap().playlists.get(index).cloned();
                    if let Some(pl) = pl {
                        set_status(&state, &format!("Loading {}…", pl.title));
                        match playlist_tracks(&engine.http, &pl.id) {
                            Ok(items) if !items.is_empty() => {
                                // the fetch can take a while; a newer click may
                                // have arrived, in which case do not play this
                                if !is_current(token) {
                                    continue;
                                }
                                // keep the track list around so it is there if
                                // the user ever navigates to results, but do
                                // not force the view over: just play the queue
                                {
                                    let mut s = state.lock().unwrap();
                                    s.results = Arc::new(items.clone());
                                    s.results_serial += 1;
                                }
                                let mut items = items;
                                let shuffle_on =
                                    state.lock().map(|s| s.shuffle).unwrap_or(false);
                                if shuffle_on {
                                    shuffle_slice(&mut items);
                                }
                                let quality = state
                                    .lock()
                                    .map(|s| s.quality.clone())
                                    .unwrap_or_else(|_| "medium".to_string());
                                prefetch_top(&items, &quality);
                                engine.queue = Arc::new(items);
                                engine.cursor = 0;
                                engine.source = QueueSource::Playlist;
                                play_current(&mut engine, &state, token);
                            }
                            Ok(_) => set_status(&state, "Playlist is empty."),
                            Err(e) => set_status(&state, &format!("Playlist failed: {e}")),
                        }
                    }
                }
                Cmd::CreatePlaylist { name, reply } => {
                    set_status(&state, &format!("Creating “{}”…", name));
                    let result = ytm_create_playlist(&engine.http, &name);
                    match &result {
                        Ok(id) => {
                            let id = id.clone();
                            // The library endpoint can lag a beat behind a fresh
                            // create, so fetch a few times until the new id shows
                            // up. If it still is not there, keep the first list we
                            // got and splice the new playlist in ourselves, so the
                            // page always refreshes with the entry.
                            let mut fetched: Option<Vec<PlaylistRow>> = None;
                            for attempt in 0..3 {
                                if attempt > 0 {
                                    std::thread::sleep(Duration::from_millis(500 * attempt as u64));
                                }
                                match list_playlists(&engine.http) {
                                    Ok(list) => {
                                        let has_new = list.iter().any(|p| p.id == id);
                                        if has_new {
                                            fetched = Some(list);
                                            break;
                                        }
                                        if fetched.is_none() {
                                            fetched = Some(list);
                                        }
                                    }
                                    Err(_) => {}
                                }
                            }
                            let mut list = fetched.unwrap_or_default();
                            if !list.iter().any(|p| p.id == id) {
                                list.insert(
                                    0,
                                    PlaylistRow {
                                        id: id.clone(),
                                        title: name.clone(),
                                        count: String::new(),
                                    },
                                );
                            }
                            if let Ok(mut s) = state.lock() {
                                s.playlists = list;
                                s.playlists_serial += 1;
                                s.status = format!("Created “{}”.", name);
                            }
                        }
                        Err(e) => set_status(&state, &format!("Create failed: {e}")),
                    }
                    let _ = reply.send(result.map(|_| ()));
                }
                Cmd::PlaylistDetails { id, reply } => {
                    let _ = reply.send(playlist_tracks(&engine.http, &id));
                }
                Cmd::AddCurrentToPlaylist { id, reply } => {
                    let result = match engine.queue.get(engine.cursor) {
                        Some(track) if track.id.len() == 11 => {
                            match ytm_add_to_playlist(&engine.http, &id, &track.id) {
                                Ok(()) => {
                                    set_status(
                                        &state,
                                        &format!("Added “{}” to the playlist.", track.title),
                                    );
                                    Ok(())
                                }
                                Err(e) => {
                                    set_status(&state, &format!("Add failed: {e}"));
                                    Err(e)
                                }
                            }
                        }
                        Some(_) => {
                            let e = "this track cannot be added".to_string();
                            set_status(&state, &format!("Add failed: {e}"));
                            Err(e)
                        }
                        None => {
                            let e = "nothing is playing".to_string();
                            set_status(&state, &format!("Add failed: {e}"));
                            Err(e)
                        }
                    };
                    let _ = reply.send(result);
                }
                Cmd::RemoveFromPlaylist {
                    playlist_id,
                    video_id,
                    reply,
                } => {
                    let result =
                        ytm_remove_from_playlist(&engine.http, &playlist_id, &video_id);
                    match &result {
                        Ok(()) => set_status(&state, "Removed song from the playlist."),
                        Err(e) => set_status(&state, &format!("Remove failed: {e}")),
                    }
                    let _ = reply.send(result);
                }
                Cmd::DeletePlaylist { id, title, reply } => {
                    let result = ytm_delete_playlist(&engine.http, &id);
                    match &result {
                        Ok(()) => {
                            if let Ok(mut s) = state.lock() {
                                s.playlists.retain(|p| p.id != id);
                                s.playlists_serial += 1;
                                s.status = format!("Deleted “{}”.", title);
                            }
                        }
                        Err(e) => set_status(&state, &format!("Delete failed: {e}")),
                    }
                    let _ = reply.send(result);
                }
                Cmd::Prefetch(id) => {
                    let quality = state
                        .lock()
                        .map(|s| s.quality.clone())
                        .unwrap_or_else(|_| "medium".to_string());
                    prefetch_url(&id, &quality);
                }
                Cmd::DownloadCurrent => {
                    let track = engine.queue.get(engine.cursor).cloned();
                    match track {
                        Some(track) if track.id.len() == 11 => {
                            let state_dl = state.clone();
                            set_status(&state_dl, &format!("Downloading “{}”…", track.title));
                            std::thread::spawn(move || {
                                let token = current_play_token();
                                dl_begin(token);
                                let result = download_to_imports(&track, token);
                                dl_end(token);
                                match result {
                                    Ok(_) => {
                                        scan_imports(&state_dl);
                                        if let Ok(mut s) = state_dl.lock() {
                                            s.show_imports_soon = true;
                                        }
                                        set_status(
                                            &state_dl,
                                            &format!("Saved “{}” to imports.", track.title),
                                        );
                                    }
                                    Err(e) => {
                                        set_status(&state_dl, &format!("Download failed: {e}"))
                                    }
                                }
                            });
                        }
                        Some(_) => set_status(&state, "This song is already a local file."),
                        None => set_status(&state, "Nothing is playing."),
                    }
                }
                Cmd::Logout => {
                    let cookies = yt_cookies_file();
                    if cookies.exists() {
                        let _ = std::fs::remove_file(&cookies);
                    }
                    let webview = cache_root().join("webview");
                    if webview.exists() {
                        let _ = std::fs::remove_dir_all(&webview);
                    }
                    if let Ok(mut s) = state.lock() {
                        s.playlists.clear();
                        s.playlists_serial += 1;
                        s.status = "Signed out.".to_string();
                    }
                }
                Cmd::WipeData => {
                    engine.player.stop();
                    engine.player.set_volume(0.7);
                    engine.queue = Arc::new(Vec::new());
                    engine.cursor = 0;
                    engine.search_cache.clear();
                    engine.cache_order.clear();

                    // every byte the app persisted: cached audio/session under
                    // the cache root, and the settings folder under the config
                    // root. Missing directories are fine.
                    let settings_dir = config_path()
                        .parent()
                        .map(|p| p.to_path_buf())
                        .unwrap_or_default();
                    let mut errors: Vec<String> = Vec::new();
                    for dir in [cache_root(), settings_dir] {
                        if dir.as_os_str().is_empty() || !dir.exists() {
                            continue;
                        }
                        if let Err(e) = std::fs::remove_dir_all(&dir) {
                            errors.push(format!("{}: {e}", dir.display()));
                        }
                    }
                    // wipe the imports folder too, but keep the folder itself:
                    // the live file monitor watches this inode, and new mp3s
                    // should still be picked up after a wipe
                    let imports = imports_dir();
                    if let Ok(entries) = std::fs::read_dir(&imports) {
                        for entry in entries.flatten() {
                            let path = entry.path();
                            let removed = if path.is_dir() {
                                std::fs::remove_dir_all(&path)
                            } else {
                                std::fs::remove_file(&path)
                            };
                            if let Err(e) = removed {
                                errors.push(format!("{}: {e}", path.display()));
                            }
                        }
                    }
                    let wipe_error = if errors.is_empty() {
                        None
                    } else {
                        Some(errors.join("; "))
                    };

                    let mut s = state.lock().unwrap();
                    let results_serial = s.results_serial.wrapping_add(1);
                    let playlists_serial = s.playlists_serial.wrapping_add(1);
                    let imports_serial = s.imports_serial.wrapping_add(1);
                    *s = UiState::default();
                    s.results_serial = results_serial;
                    s.playlists_serial = playlists_serial;
                    s.imports_serial = imports_serial;
                    s.status = match wipe_error {
                        Some(e) => format!("Wipe failed: {e}"),
                        None => "All user data wiped.".to_string(),
                    };
                    WIPE_DONE.store(true, Ordering::SeqCst);
                }
            }
        }

        {
            let playing = state.lock().unwrap().playing;
            if playing {
                if engine.player.empty() {
                    // Reuse the current token instead of minting one. If the
                    // user clicked a new song while this tick was starting, the
                    // token is already stale and the load below aborts on its
                    // first poll instead of blocking that click out.
                    let auto_token = current_play_token();
                    // A dropped CDN connection empties the player exactly like
                    // a finished song. Only advance when the track really ran
                    // its course; otherwise reload the same one a couple of
                    // times before giving up.
                    let pos = engine.player.get_pos().as_millis() as u32;
                    let current = engine.queue.get(engine.cursor).cloned();
                    let retried = match (&engine.premature, &current) {
                        (Some((id, n)), Some(track)) if id == &track.id => *n,
                        _ => 0,
                    };
                    let died_early = current.as_ref().is_some_and(|track| {
                        !track.id.starts_with("local:")
                            && track.duration_ms > PREMATURE_MIN_MS
                            && pos + PREMATURE_GAP_MS < track.duration_ms
                    });
                    if died_early && retried < PREMATURE_RETRIES {
                        if let Some(track) = current {
                            let quality = state
                                .lock()
                                .map(|s| s.quality.clone())
                                .unwrap_or_else(|_| "medium".to_string());
                            engine.premature = Some((track.id.clone(), retried + 1));
                            // a stale URL or a truncated cache file would fail
                            // in exactly the same place, so retry clean
                            forget_stream_url(&track.id, &quality);
                            let cached = engine.cache.join(format!(
                                "{}.m4a",
                                cache_stem(&track.id, &quality)
                            ));
                            let _ = std::fs::remove_file(&cached);
                            play_current(&mut engine, &state, auto_token);
                        }
                        continue;
                    }
                    engine.premature = None;
                    let repeat = state.lock().map(|s| s.repeat).unwrap_or(false);
                    if repeat && !engine.queue.is_empty() {
                        match engine.source {
                            // search track: loop that one song forever
                            QueueSource::Search => {}
                            // playlist: wrap around at the end of the queue
                            QueueSource::Playlist => {
                                engine.cursor = (engine.cursor + 1) % engine.queue.len();
                            }
                            // local imports: repeat the whole folder
                            QueueSource::Import => {
                                engine.cursor = (engine.cursor + 1) % engine.queue.len();
                            }
                            // recently-played carousel: repeat the whole list
                            QueueSource::Recent => {
                                engine.cursor = (engine.cursor + 1) % engine.queue.len();
                            }
                        }
                        play_current(&mut engine, &state, auto_token);
                    } else if engine.cursor + 1 < engine.queue.len() {
                        engine.cursor += 1;
                        play_current(&mut engine, &state, auto_token);
                    } else {
                        let mut s = state.lock().unwrap();
                        s.playing = false;
                        s.status = "Queue finished.".to_string();
                    }
                } else {
                    let pos = engine.player.get_pos().as_millis() as u32;
                    {
                        let mut s = state.lock().unwrap();
                        s.pos_ms = pos.min(s.duration_ms.max(pos));
                    }
                    if pos >= RECENT_MIN_MS {
                        if let Some(track) = engine.pending_recent.take() {
                            mark_played(&state, &track);
                        }
                    }
                }
            }
        }

        // publish the queue for the quiet-mode rail; clone only when the
        // queue identity or the cursor actually moved
        if let Ok(mut s) = state.lock() {
            if !Arc::ptr_eq(&s.queue, &engine.queue) || s.queue_cursor != engine.cursor {
                s.queue = engine.queue.clone();
                s.queue_cursor = engine.cursor;
                s.queue_serial = s.queue_serial.wrapping_add(1);
            }
        }

        if polled_while_playing {
            std::thread::sleep(Duration::from_millis(100));
        }
    }
}

fn apply_pending_seek(engine: &mut Engine, state: &Arc<Mutex<UiState>>) {
    let target = state.lock().ok().and_then(|mut s| s.seek_to_ms.take());
    if let Some(target) = target {
        if engine
            .player
            .try_seek(Duration::from_millis(target as u64))
            .is_ok()
        {
            if let Ok(mut s) = state.lock() {
                s.pos_ms = target;
            }
        }
    }
}

fn play_current(engine: &mut Engine, state: &Arc<Mutex<UiState>>, token: PlayToken) {
    if !is_current(token) {
        return;
    }
    let Some(track) = engine.queue.get(engine.cursor).cloned() else {
        set_status(state, "Nothing queued.");
        return;
    };
    LOADING.store(true, Ordering::SeqCst);
    let _loading = LoadingGuard;
    // history is deferred until the tick sees enough playback time
    engine.pending_recent = Some(track.clone());

    {
        let mut s = state.lock().unwrap();
        s.title = track.title.clone();
        s.artist = track.artist.clone();
        s.current_id = track.id.clone();
        s.duration_ms = track.duration_ms;
        s.pos_ms = 0;
        s.seek_to_ms = None;
        s.playing = false;
    }
    start_lyrics_fetch(
        state,
        track.title.clone(),
        track.artist.clone(),
        track.duration_ms,
    );
    let volume = state
        .lock()
        .map(|s| effective_volume(s.sensitive_ears, s.volume))
        .unwrap_or(0.7);
    engine.player.set_volume(volume);
    set_status(state, &format!("Loading {}…", track.title));

    // Local imports carry a "local:<path>" id: open the file from disk
    // directly, no yt-dlp and no network.
    if let Some(path) = track.id.strip_prefix("local:") {
        match open_decoder(Path::new(path)) {
            Ok(decoder) => {
                if !is_current(token) {
                    return;
                }
                engine.player.stop();
                engine.player.append(decoder);
                apply_pending_seek(engine, state);
                engine.player.play();
                if let Ok(mut s) = state.lock() {
                    s.playing = true;
                    s.status = "Playing".to_string();
                }
            }
            Err(e) => {
                if is_current(token) {
                    set_status(state, &format!("Could not play: {e}"));
                }
            }
        }
        return;
    }

    // A cached track opens instantly. A prefetch already in flight is just as
    // good: wait for it instead of spawning a second yt-dlp. Anything else is
    // streamed straight from yt-dlp, starting on the first fragment and
    // teeing into the cache so the next play is instant.
    let quality = state
        .lock()
        .map(|s| s.quality.clone())
        .unwrap_or_else(|_| "medium".to_string());
    let key = cache_stem(&track.id, &quality);
    let cached = audio_cached(&engine.cache, &track.id, &quality);
    if !cached {
        set_status(state, &format!("Loading {}…", track.title));
    }
    // Preferred path: a stream URL already resolved (by a background prefetch
    // for the visible results) starts in ~100 ms over plain HTTP, and still
    // lets rodio seek with Range requests. Only a cold miss pays for yt-dlp.
    let decoder: Result<Box<dyn Source + Send>, String> = if cached {
        open_decoder(&engine.cache.join(format!("{key}.m4a")))
    } else {
        let url = wait_stream_url(&track.id, &quality, Duration::from_secs(4), token)
            .or_else(|| resolve_stream_abortable(&track.id, &quality, Some(token)).ok());
        match url {
            Some(url) => http_decoder(
                &track.id,
                &url,
                &engine.cache,
                &quality,
                token,
            )
            .or_else(|_| stream_decoder_fallback(&track.id, &engine.cache, &quality, token)),
            None => stream_decoder_fallback(&track.id, &engine.cache, &quality, token),
        }
    };
    let decoder = match decoder {
        Ok(d) => d,
        Err(_) if !is_current(token) => return,
        Err(e) => {
            set_status(state, &format!("Could not play: {e}"));
            return;
        }
    };

    // a newer click can land while the decoder was being built; discard this
    // one instead of starting it on top of the new request
    if !is_current(token) {
        return;
    }

    engine.player.stop();
    engine.player.append(decoder);
    apply_pending_seek(engine, state);
    engine.player.play();
    {
        let mut s = state.lock().unwrap();
        s.playing = true;
        s.status = "Playing".to_string();
    }

    if let Some(next) = engine.queue.get(engine.cursor + 1) {
        if !next.id.starts_with("local:") {
            prefetch_url(&next.id, &quality);
        }
    }
}

// Cheap, dependency-free randomness: hash the current time and pid, then mix.
fn random_index(n: usize) -> usize {
    if n <= 1 {
        return 0;
    }
    let nanos = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_nanos() as u64)
        .unwrap_or(1);
    let mut x = nanos ^ (std::process::id() as u64).wrapping_mul(0x9E37_79B9_7F4A_7C15);
    x ^= x >> 33;
    x = x.wrapping_mul(0xff51_afd7_ed55_8ccd);
    x ^= x >> 33;
    x = x.wrapping_mul(0xc4ce_b9fe_1a85_ec53);
    x ^= x >> 33;
    (x as usize) % n
}

// Fisher-Yates over a slice, reusing the same cheap source of randomness.
fn shuffle_slice<T>(items: &mut [T]) {
    let mut i = items.len();
    while i > 1 {
        let j = random_index(i);
        i -= 1;
        items.swap(i, j);
    }
}

const LUCKY_QUERIES: &[&str] = &[
    "lofi", "rock", "pop hits", "jazz", "hip hop", "electronic", "classical", "indie",
    "metal", "rnb", "country", "reggae", "blues", "synthwave", "ambient", "punk",
    "soul", "funk", "house", "drum and bass",
];

// Pick a random query, search anonymously, then play a random result.
fn play_lucky(engine: &mut Engine, state: &Arc<Mutex<UiState>>, token: PlayToken) {
    if !is_current(token) {
        return;
    }
    set_status(state, "Feeling lucky…");
    let query = LUCKY_QUERIES[random_index(LUCKY_QUERIES.len())];
    let limit = state
        .lock()
        .map(|s| s.search_limit.clamp(1, SEARCH_LIMIT))
        .unwrap_or(SEARCH_LIMIT)
        .max(10);
    match search(&engine.http, query, limit) {
        Ok(items) if !items.is_empty() => {
            if !is_current(token) {
                return;
            }
            apply_results(state, query, items.len(), items.clone());
            let pick = random_index(items.len());
            engine.queue = Arc::new(items);
            engine.cursor = pick;
            engine.source = QueueSource::Search;
            play_current(engine, state, token);
            if let Ok(mut s) = state.lock() {
                s.show_results_soon = true;
            }
        }
        Ok(_) => set_status(state, "Lucky found nothing. Try again."),
        Err(e) => set_status(state, &format!("Lucky failed: {e}")),
    }
}

fn open_decoder(path: &Path) -> Result<Box<dyn Source + Send>, String> {
    let file = File::open(path).map_err(|e| e.to_string())?;
    let decoder = Decoder::new(BufReader::with_capacity(256 * 1024, file))
        .map_err(|e| e.to_string())?;
    Ok(Box::new(decoder))
}

fn stream_decoder(
    id: &str,
    dir: &Path,
    with_cookies: bool,
    quality: &str,
    token: PlayToken,
) -> Result<Box<dyn Source + Send>, String> {
    if !is_current(token) {
        return Err("cancelled".to_string());
    }
    let source = stream_track(id, dir, with_cookies, quality, token)?;
    let decoder = Decoder::builder()
        .with_data(source)
        .with_hint("m4a")
        .build()
        .map_err(|e| format!("decode: {e}"))?;
    Ok(Box::new(decoder))
}

// Media extraction tries anonymous first: a logged-in yt-dlp client can come
// back with no audio formats (only storyboards) when YouTube wants a PO token,
// while anonymous requests still work. Account cookies are only a fallback for
// content that actually needs them.
fn stream_decoder_fallback(
    id: &str,
    dir: &Path,
    quality: &str,
    token: PlayToken,
) -> Result<Box<dyn Source + Send>, String> {
    match stream_decoder(id, dir, false, quality, token) {
        Ok(d) => Ok(d),
        Err(_) if !is_current(token) => Err("cancelled".to_string()),
        Err(_) => stream_decoder(id, dir, true, quality, token),
    }
}

// Direct HTTP source over a resolved googlevideo URL. This is the fast path:
// no child process, no pipe, and Range requests make it seekable. Bytes read
// are mirrored into a .part file so a fully played track is instantly
// available next time; seeking disables the tee to avoid a torn cache file.
struct HttpSource {
    client: reqwest::blocking::Client,
    url: String,
    resp: reqwest::blocking::Response,
    pos: u64,
    total: Option<u64>,
    part: PathBuf,
    final_path: PathBuf,
    file: Option<File>,
    done: bool,
    tee: bool,
}

// A ranged response can stop early: the CDN drops idle connections, throttles
// long reads or simply hands back a short body. Without this the decoder sees
// EOF mid-song and the worker treats it as a finished track. Re-open at the
// last byte we handed out and keep reading where we stopped.
const STREAM_RESUME_TRIES: u32 = 6;
const STREAM_RESUME_BACKOFF_MS: u64 = 120;

fn content_range_start(resp: &reqwest::blocking::Response) -> Option<u64> {
    resp.headers()
        .get(reqwest::header::CONTENT_RANGE)
        .and_then(|v| v.to_str().ok())
        .and_then(|text| text.strip_prefix("bytes "))
        .and_then(|text| text.split_once('/').map(|(range, _)| range))
        .and_then(|range| range.split_once('-').map(|(start, _)| start))
        .and_then(|start| start.trim().parse::<u64>().ok())
}

impl HttpSource {
    fn finish(&mut self) {
        if self.done {
            return;
        }
        self.done = true;
        if let Some(mut f) = self.file.take() {
            let _ = f.flush();
        }
        if self.tee {
            let complete = match self.total {
                Some(total) => self.pos >= total,
                None => true,
            };
            let big = std::fs::metadata(&self.part)
                .map(|m| m.len() > 8192)
                .unwrap_or(false);
            if complete && big {
                let _ = std::fs::rename(&self.part, &self.final_path);
            } else {
                let _ = std::fs::remove_file(&self.part);
            }
        } else {
            let _ = std::fs::remove_file(&self.part);
        }
    }

    // Re-issue the request from the current byte. Returns true only when the
    // new response really starts at self.pos, so a server that ignores Range
    // can never splice the beginning of the file into the middle of playback.
    fn resume(&mut self) -> bool {
        let resp = match self
            .client
            .get(&self.url)
            .header(reqwest::header::RANGE, format!("bytes={}-", self.pos))
            .send()
        {
            Ok(resp) => resp,
            Err(_) => return false,
        };
        if resp.status() == reqwest::StatusCode::PARTIAL_CONTENT {
            if let Some(start) = content_range_start(&resp) {
                if start != self.pos {
                    return false;
                }
            }
            self.resp = resp;
            return true;
        }
        if resp.status().is_success() && self.pos == 0 {
            self.resp = resp;
            return true;
        }
        false
    }

    fn seek_to(&mut self, target: u64) -> std::io::Result<u64> {
        let resp = self
            .client
            .get(&self.url)
            .header(reqwest::header::RANGE, format!("bytes={target}-"))
            .send()
            .map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, e.to_string()))?;
        let status = resp.status();
        if status == reqwest::StatusCode::PARTIAL_CONTENT {
            if let Some(start) = content_range_start(&resp) {
                if start != target {
                    return Err(std::io::Error::new(
                        std::io::ErrorKind::Other,
                        format!("range moved: wanted {target}, got {start}"),
                    ));
                }
            }
        } else if status.is_success() {
            // The server ignored Range and is replaying from byte zero. That is
            // only correct for a seek back to the very start.
            if target != 0 {
                return Err(std::io::Error::new(
                    std::io::ErrorKind::Other,
                    "server ignored range request",
                ));
            }
        } else {
            return Err(std::io::Error::new(
                std::io::ErrorKind::Other,
                format!("http {status}"),
            ));
        }
        self.resp = resp;
        self.pos = target;
        self.done = false;
        if target == 0 {
            // Starting over from the first byte: the cache tee is valid again
            // (this is the seek symphonia performs after scanning the atoms).
            let _ = std::fs::remove_file(&self.part);
            self.file = File::create(&self.part).ok();
            self.tee = self.file.is_some();
        } else {
            self.tee = false;
            self.file = None;
            let _ = std::fs::remove_file(&self.part);
        }
        Ok(target)
    }
}

impl Read for HttpSource {
    fn read(&mut self, buf: &mut [u8]) -> std::io::Result<usize> {
        if self.done {
            return Ok(0);
        }
        let mut tries = 0;
        loop {
            match self.resp.read(buf) {
                Ok(0) => {
                    let complete = match self.total {
                        Some(total) => self.pos >= total,
                        None => false,
                    };
                    if !complete && tries < STREAM_RESUME_TRIES {
                        tries += 1;
                        std::thread::sleep(Duration::from_millis(STREAM_RESUME_BACKOFF_MS));
                        if self.resume() {
                            continue;
                        }
                    }
                    self.finish();
                    return Ok(0);
                }
                Ok(n) => {
                    self.pos += n as u64;
                    if self.tee {
                        if let Some(f) = self.file.as_mut() {
                            if f.write_all(&buf[..n]).is_err() {
                                self.tee = false;
                                self.file = None;
                                let _ = std::fs::remove_file(&self.part);
                            }
                        }
                    }
                    return Ok(n);
                }
                Err(e) if e.kind() == std::io::ErrorKind::Interrupted => continue,
                Err(e) => {
                    if tries < STREAM_RESUME_TRIES {
                        tries += 1;
                        std::thread::sleep(Duration::from_millis(STREAM_RESUME_BACKOFF_MS));
                        if self.resume() {
                            continue;
                        }
                    }
                    self.finish();
                    return Err(e);
                }
            }
        }
    }
}

impl Seek for HttpSource {
    fn seek(&mut self, from: SeekFrom) -> std::io::Result<u64> {
        let target = match from {
            SeekFrom::Start(p) => p as i64,
            SeekFrom::Current(p) => self.pos as i64 + p,
            SeekFrom::End(p) => match self.total {
                Some(total) => total as i64 + p,
                None => {
                    return Err(std::io::Error::new(
                        std::io::ErrorKind::Unsupported,
                        "stream size unknown",
                    ))
                }
            },
        };
        if target < 0 {
            return Err(std::io::Error::new(
                std::io::ErrorKind::InvalidInput,
                "negative seek",
            ));
        }
        let target = target as u64;
        // Seeking to where the reader already is must not throw away an
        // in-progress cache tee or open another connection.
        if target == self.pos && !self.done {
            return Ok(target);
        }
        self.seek_to(target)
    }
}

impl Drop for HttpSource {
    fn drop(&mut self) {
        if !self.done {
            let _ = std::fs::remove_file(&self.part);
        }
    }
}

fn http_decoder(
    id: &str,
    url: &str,
    dir: &Path,
    quality: &str,
    token: PlayToken,
) -> Result<Box<dyn Source + Send>, String> {
    if !is_current(token) {
        return Err("cancelled".to_string());
    }
    let _ = std::fs::create_dir_all(dir);
    let key = cache_stem(id, quality);
    let final_path = dir.join(format!("{key}.m4a"));
    let part = dir.join(format!("{key}.http.part"));
    let _ = std::fs::remove_file(&part);

    let client = reqwest::blocking::Client::builder()
        .connect_timeout(Duration::from_secs(10))
        .user_agent(BROWSER_UA)
        .tcp_nodelay(true)
        .pool_idle_timeout(Duration::from_secs(90))
        .pool_max_idle_per_host(4)
        .build()
        .map_err(|e| format!("http: {e}"))?;
    let resp = client
        .get(url)
        .header(reqwest::header::RANGE, "bytes=0-")
        .send()
        .map_err(|e| format!("http: {e}"))?;
    if !resp.status().is_success() {
        return Err(format!("http {}", resp.status()));
    }
    if !is_current(token) {
        return Err("cancelled".to_string());
    }
    let total = resp
        .headers()
        .get(reqwest::header::CONTENT_RANGE)
        .and_then(|v| v.to_str().ok())
        .and_then(|s| s.rsplit('/').next())
        .and_then(|s| s.trim().parse::<u64>().ok())
        .or_else(|| resp.content_length());
    let file = File::create(&part).ok();
    let source = HttpSource {
        client,
        url: url.to_string(),
        resp,
        pos: 0,
        total,
        part,
        final_path,
        file,
        done: false,
        tee: true,
    };
    let mut builder = Decoder::builder()
        .with_data(source)
        .with_hint("m4a")
        .with_seekable(true);
    if let Some(total) = total {
        builder = builder.with_byte_len(total);
    }
    let decoder = builder
        .build()
        .map_err(|e| format!("decode: {e}"))?;
    Ok(Box::new(decoder))
}

// A live pipe from yt-dlp's stdout. YouTube's DASH audio is fragmented MP4
// with the moov atom first, so symphonia can decode it without seeking: the
// first fragment is enough to start playing. Everything read is mirrored into
// a .part file and promoted to the real cache file once yt-dlp exits cleanly.
struct StreamSource {
    stdout: ChildStdout,
    child: Mutex<Child>,
    pid: u32,
    part: PathBuf,
    final_path: PathBuf,
    file: Option<File>,
    done: bool,
}

impl Read for StreamSource {
    fn read(&mut self, buf: &mut [u8]) -> std::io::Result<usize> {
        let n = self.stdout.read(buf)?;
        if n == 0 {
            if !self.done {
                self.done = true;
                unregister_load(self.pid);
                if let Some(mut f) = self.file.take() {
                    let _ = f.flush();
                }
                let ok = self
                    .child
                    .lock()
                    .map(|mut c| c.wait().map(|s| s.success()).unwrap_or(false))
                    .unwrap_or(false);
                if ok
                    && std::fs::metadata(&self.part)
                        .map(|m| m.len() > 8192)
                        .unwrap_or(false)
                {
                    let _ = std::fs::rename(&self.part, &self.final_path);
                } else {
                    let _ = std::fs::remove_file(&self.part);
                }
            }
            return Ok(0);
        }
        if let Some(f) = self.file.as_mut() {
            let _ = f.write_all(&buf[..n]);
        }
        Ok(n)
    }
}

impl Seek for StreamSource {
    fn seek(&mut self, _pos: SeekFrom) -> std::io::Result<u64> {
        Err(std::io::Error::new(
            std::io::ErrorKind::Unsupported,
            "live stream is not seekable",
        ))
    }
}

impl Drop for StreamSource {
    fn drop(&mut self) {
        unregister_load(self.pid);
        if !self.done {
            if let Ok(mut c) = self.child.lock() {
                let _ = c.kill();
                let _ = c.wait();
            }
            let _ = std::fs::remove_file(&self.part);
        }
    }
}

fn stream_track(
    id: &str,
    dir: &Path,
    with_cookies: bool,
    quality: &str,
    token: PlayToken,
) -> Result<StreamSource, String> {
    let _ = std::fs::create_dir_all(dir);
    let key = cache_stem(id, quality);
    let final_path = dir.join(format!("{key}.m4a"));
    let part = dir.join(format!("{key}.part"));
    let _ = std::fs::remove_file(&part);

    let url = format!("https://www.youtube.com/watch?v={id}");
    let mut cmd = Command::new(ytdlp());
    cmd.args([
        "-f",
        audio_format(quality),
        "--no-warnings",
        "--no-playlist",
        "--newline",
        "--progress-template",
        "download:DL %(progress.downloaded_bytes)s %(progress.total_bytes)s %(progress.total_bytes_estimate)s",
    ]);
    if with_cookies {
        cmd.args(&yt_cookie_args());
    }
    let mut child = cmd
        .args(["-o", "-", url.as_str()])
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map_err(|e| format!("yt-dlp: {e}"))?;
    // yt-dlp reports byte progress on stderr while it streams the media to
    // stdout; feed that to the download bar until playback starts
    if let Some(mut err) = child.stderr.take() {
        std::thread::spawn(move || {
            let mut chunk = [0u8; 2048];
            let mut line = String::new();
            loop {
                match err.read(&mut chunk) {
                    Ok(0) | Err(_) => break,
                    Ok(n) => {
                        for &b in &chunk[..n] {
                            if b == b'\n' || b == b'\r' {
                                if let Some(frac) = parse_dl_progress(&line) {
                                    dl_update(token, frac);
                                }
                                line.clear();
                            } else if line.len() < 512 {
                                line.push(b as char);
                            }
                        }
                    }
                }
            }
        });
    }
    let stdout = child
        .stdout
        .take()
        .ok_or_else(|| "yt-dlp: no stdout".to_string())?;
    let pid = child.id();
    register_load(pid, token);
    let file = File::create(&part).ok();
    Ok(StreamSource {
        stdout,
        child: Mutex::new(child),
        pid,
        part,
        final_path,
        file,
        done: false,
    })
}

struct DownloadSlot {
    result: Mutex<Option<Result<PathBuf, String>>>,
    ready: Condvar,
}

fn download_registry() -> &'static Mutex<HashMap<String, Arc<DownloadSlot>>> {
    static REGISTRY: OnceLock<Mutex<HashMap<String, Arc<DownloadSlot>>>> = OnceLock::new();
    REGISTRY.get_or_init(|| Mutex::new(HashMap::new()))
}

// set by the worker once a full wipe has finished; the UI watches this to
// restart the whole app on a clean slate
static WIPE_DONE: AtomicBool = AtomicBool::new(false);

fn audio_cached(dir: &Path, id: &str, quality: &str) -> bool {
    std::fs::metadata(dir.join(format!("{}.m4a", cache_stem(id, quality))))
        .map(|m| m.len() > 8192)
        .unwrap_or(false)
}

// Resolved googlevideo URLs are cheap to reuse and start instantly over plain
// HTTP, so the moment a result list appears we resolve the top few in the
// background. A click then costs one request (~100 ms) instead of a whole
// yt-dlp extraction (~2 s). The URL is IP-bound and short-lived, so it is kept
// in memory only and refreshed after 20 minutes.
const STREAM_URL_TTL: Duration = Duration::from_secs(20 * 60);
const URL_RESOLVE_MAX: usize = 4;

static STREAM_URLS: OnceLock<Mutex<HashMap<String, (String, Instant)>>> = OnceLock::new();
static URL_RESOLVING: OnceLock<Mutex<HashSet<String>>> = OnceLock::new();
static URL_RESOLVE_ACTIVE: AtomicUsize = AtomicUsize::new(0);

fn stream_urls() -> &'static Mutex<HashMap<String, (String, Instant)>> {
    STREAM_URLS.get_or_init(|| Mutex::new(HashMap::new()))
}

fn url_resolving() -> &'static Mutex<HashSet<String>> {
    URL_RESOLVING.get_or_init(|| Mutex::new(HashSet::new()))
}

fn cached_stream_url(id: &str, quality: &str) -> Option<String> {
    let key = cache_stem(id, quality);
    let mut map = stream_urls().lock().ok()?;
    match map.get(&key) {
        Some((url, at)) if at.elapsed() < STREAM_URL_TTL => Some(url.clone()),
        Some(_) => {
            map.remove(&key);
            None
        }
        None => None,
    }
}

fn store_stream_url(id: &str, quality: &str, url: &str) {
    if let Ok(mut map) = stream_urls().lock() {
        map.insert(cache_stem(id, quality), (url.to_string(), Instant::now()));
    }
}

fn forget_stream_url(id: &str, quality: &str) {
    if let Ok(mut map) = stream_urls().lock() {
        map.remove(&cache_stem(id, quality));
    }
}

// When a prefetch for this track is already running, give it a short moment
// instead of spawning a duplicate yt-dlp. Returns None if it will not finish
// in time, in which case the caller resolves it inline.
fn wait_stream_url(
    id: &str,
    quality: &str,
    timeout: Duration,
    token: PlayToken,
) -> Option<String> {
    if let Some(url) = cached_stream_url(id, quality) {
        return Some(url);
    }
    let key = cache_stem(id, quality);
    let deadline = Instant::now() + timeout;
    loop {
        if !is_current(token) {
            return None;
        }
        if let Some(url) = cached_stream_url(id, quality) {
            return Some(url);
        }
        let resolving = url_resolving()
            .lock()
            .map(|set| set.contains(&key))
            .unwrap_or(false);
        if !resolving || Instant::now() >= deadline {
            return None;
        }
        std::thread::sleep(Duration::from_millis(40));
    }
}

fn prefetch_url(id: &str, quality: &str) {
    if id.is_empty() || id.starts_with("local:") {
        return;
    }
    if cached_stream_url(id, quality).is_some() {
        return;
    }
    let key = cache_stem(id, quality);
    if let Ok(mut set) = url_resolving().lock() {
        if !set.insert(key.clone()) {
            return;
        }
    }
    if URL_RESOLVE_ACTIVE.fetch_add(1, Ordering::SeqCst) >= URL_RESOLVE_MAX {
        URL_RESOLVE_ACTIVE.fetch_sub(1, Ordering::SeqCst);
        if let Ok(mut set) = url_resolving().lock() {
            set.remove(&key);
        }
        return;
    }
    let id = id.to_string();
    let quality = quality.to_string();
    std::thread::spawn(move || {
        let _ = resolve_stream(&id, &quality);
        URL_RESOLVE_ACTIVE.fetch_sub(1, Ordering::SeqCst);
        if let Ok(mut set) = url_resolving().lock() {
            set.remove(&key);
        }
    });
}

fn prefetch_top(items: &[ResultItem], quality: &str) {
    for item in items.iter().take(PREFETCH_COUNT) {
        if item.duration_ms <= PREFETCH_MAX_DURATION_MS {
            prefetch_url(&item.id, quality);
        }
    }
}

fn download_track(
    id: &str,
    dir: &Path,
    quality: &str,
    token: Option<PlayToken>,
    report: bool,
) -> Result<PathBuf, String> {
    if let Some(t) = token {
        if !is_current(t) {
            return Err("cancelled".to_string());
        }
    }
    let key = cache_stem(id, quality);
    let target = dir.join(format!("{key}.m4a"));
    if let Ok(meta) = std::fs::metadata(&target) {
        if meta.len() > 8192 {
            return Ok(target);
        }
    }
    let _ = std::fs::create_dir_all(dir);

    let (slot, owner) = {
        let mut map = download_registry().lock().unwrap();
        match map.get(&key) {
            Some(slot) => (slot.clone(), false),
            None => {
                let slot = Arc::new(DownloadSlot {
                    result: Mutex::new(None),
                    ready: Condvar::new(),
                });
                map.insert(key.clone(), slot.clone());
                (slot, true)
            }
        }
    };
    if !owner {
        let mut result = slot.result.lock().unwrap();
        while result.is_none() {
            result = slot.ready.wait(result).unwrap();
        }
        let result = result.clone().unwrap();
        if let Some(t) = token {
            if !is_current(t) {
                return Err("cancelled".to_string());
            }
        }
        return result;
    }

    let result = download_track_inner(id, dir, &target, quality, token, report);
    {
        let mut stored = slot.result.lock().unwrap();
        *stored = Some(result.clone());
    }
    download_registry().lock().unwrap().remove(&key);
    slot.ready.notify_all();
    result
}

fn download_track_inner(
    id: &str,
    dir: &Path,
    target: &Path,
    quality: &str,
    token: Option<PlayToken>,
    report: bool,
) -> Result<PathBuf, String> {
    let url = format!("https://www.youtube.com/watch?v={id}");
    let out_template = dir.join(format!("{}.%(ext)s", cache_stem(id, quality)));
    let template = out_template.to_string_lossy().into_owned();

    let fmt = audio_format(quality);
    let attempts: Vec<Vec<&str>> = vec![
        vec!["-N", "4", "-f", fmt],
        vec!["-N", "4", "-f", "bestaudio[ext=m4a]"],
        vec!["-x", "--audio-format", "m4a", "-f", "bestaudio"],
    ];

    let mut last_error = String::from("download failed");
    // anonymous first (see stream_decoder_fallback), cookies only as fallback
    for with_cookies in [false, true] {
        for args in &attempts {
            if let Some(t) = token {
                if !is_current(t) {
                    let _ = std::fs::remove_file(target);
                    return Err("cancelled".to_string());
                }
            }
            let mut cmd = Command::new(ytdlp());
            cmd.args(args);
            if with_cookies {
                cmd.args(&yt_cookie_args());
            }
            cmd.args(["--no-playlist", "--no-warnings"]);
            if report {
                cmd.args([
                    "--newline",
                    "--progress-template",
                    "download:DL %(progress.downloaded_bytes)s %(progress.total_bytes)s %(progress.total_bytes_estimate)s",
                ]);
            } else {
                cmd.arg("--no-progress");
            }
            cmd.args(["-o", template.as_str(), url.as_str()])
                .stdout(Stdio::null())
                .stderr(Stdio::piped());
            let mut child = match cmd.spawn() {
                Ok(child) => child,
                Err(e) => return Err(format!("yt-dlp: {e}")),
            };
            let pid = child.id();
            if let Some(t) = token {
                register_load(pid, t);
            }

            // drain stderr so a chatty child never blocks on a full pipe, and
            // (when asked) turn progress-template lines into a fill fraction
            let stderr_text = Arc::new(Mutex::new(String::new()));
            let mut reader = child.stderr.take().map(|mut pipe| {
                let sink = stderr_text.clone();
                std::thread::spawn(move || {
                    let mut chunk = [0u8; 4096];
                    let mut line = String::new();
                    loop {
                        match pipe.read(&mut chunk) {
                            Ok(0) | Err(_) => break,
                            Ok(n) => {
                                if let Ok(mut text) = sink.lock() {
                                    if text.len() < 16 * 1024 {
                                        text.push_str(&String::from_utf8_lossy(&chunk[..n]));
                                    }
                                }
                                if report {
                                    if let Some(t) = token {
                                        for &b in &chunk[..n] {
                                            if b == b'\n' || b == b'\r' {
                                                if let Some(frac) = parse_dl_progress(&line) {
                                                    dl_update(t, frac);
                                                }
                                                line.clear();
                                            } else if line.len() < 512 {
                                                line.push(b as char);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                })
            });

            // poll instead of .output() so a fresh request can kill this child
            // and unblock the thread immediately
            let status = loop {
                if let Some(t) = token {
                    if !is_current(t) {
                        terminate_pid(pid);
                        let _ = child.wait();
                        unregister_load(pid);
                        if let Some(reader) = reader.take() {
                            let _ = reader.join();
                        }
                        let _ = std::fs::remove_file(target);
                        return Err("cancelled".to_string());
                    }
                }
                match child.try_wait() {
                    Ok(Some(status)) => break status,
                    Ok(None) => std::thread::sleep(Duration::from_millis(40)),
                    Err(e) => {
                        terminate_pid(pid);
                        let _ = child.wait();
                        unregister_load(pid);
                        if let Some(reader) = reader.take() {
                            let _ = reader.join();
                        }
                        return Err(format!("yt-dlp: {e}"));
                    }
                }
            };
            unregister_load(pid);
            if let Some(reader) = reader.take() {
                let _ = reader.join();
            }

            if let Ok(meta) = std::fs::metadata(target) {
                if meta.len() > 8192 {
                    if report {
                        if let Some(t) = token {
                            dl_update(t, 1.0);
                        }
                    }
                    return Ok(target.to_path_buf());
                }
            }
            if let Some(t) = token {
                if !is_current(t) {
                    let _ = std::fs::remove_file(target);
                    return Err("cancelled".to_string());
                }
            }
            if !status.success() {
                let err = stderr_text.lock().map(|text| text.clone()).unwrap_or_default();
                last_error = err.lines().last().unwrap_or("download failed").to_string();
            }
        }
    }
    Err(last_error)
}

// Turn a title / artist into a safe single-component filename stem.
fn safe_file_stem(text: &str) -> String {
    let mapped: String = text
        .chars()
        .map(|c| match c {
            '/' | '\\' | ':' | '*' | '?' | '"' | '<' | '>' | '|' | '\0' | '\n' | '\r' | '\t' => {
                '-'
            }
            c if c.is_control() => '-',
            c => c,
        })
        .collect();
    let mut out = mapped.trim().trim_matches('.').to_string();
    if out.is_empty() {
        out = "Untitled".to_string();
    }
    if out.chars().count() > 120 {
        out = out.chars().take(120).collect();
    }
    out
}

// "Artist - Title.mp3", with a numeric suffix when the name is already taken.
fn unique_download_path(dir: &Path, stem: &str) -> PathBuf {
    let mut candidate = dir.join(format!("{stem}.mp3"));
    let mut n = 2;
    while candidate.exists() {
        candidate = dir.join(format!("{stem} ({n}).mp3"));
        n += 1;
        if n > 9999 {
            break;
        }
    }
    candidate
}

// Fetch the current YouTube track as an mp3 into the imports folder. The
// download lands in a temp dir first so the imports file monitor never sees
// half-converted files; it is copied in only once the mp3 is complete.
fn download_to_imports(track: &ResultItem, token: PlayToken) -> Result<PathBuf, String> {
    let dir = imports_dir();
    std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;

    let tmp = std::env::temp_dir().join(format!(
        "rustify-dl-{}-{}",
        std::process::id(),
        sanitize(&track.id)
    ));
    let _ = std::fs::remove_dir_all(&tmp);
    std::fs::create_dir_all(&tmp).map_err(|e| e.to_string())?;

    let url = format!("https://www.youtube.com/watch?v={}", track.id);
    let template = tmp.join("%(title)s.%(ext)s").to_string_lossy().into_owned();

    let mut last_err = String::from("download failed");
    let mut produced: Option<PathBuf> = None;
    'attempts: for with_cookies in [false, true] {
        let mut cmd = Command::new(ytdlp());
        cmd.args([
            "-x",
            "--audio-format",
            "mp3",
            "-f",
            "bestaudio",
            "--no-playlist",
            "--no-warnings",
            "--newline",
            "--progress-template",
            "download:DL %(progress.downloaded_bytes)s %(progress.total_bytes)s %(progress.total_bytes_estimate)s",
            "-o",
            template.as_str(),
            url.as_str(),
        ]);
        if with_cookies {
            cmd.args(&yt_cookie_args());
        }
        let mut child = cmd
            .stdout(Stdio::null())
            .stderr(Stdio::piped())
            .spawn()
            .map_err(|e| format!("yt-dlp: {e}"))?;

        // parse progress-template lines while the child runs
        let stderr_text = Arc::new(Mutex::new(String::new()));
        let reader = child.stderr.take().map(|mut pipe| {
            let sink = stderr_text.clone();
            std::thread::spawn(move || {
                let mut chunk = [0u8; 4096];
                let mut line = String::new();
                loop {
                    match pipe.read(&mut chunk) {
                        Ok(0) | Err(_) => break,
                        Ok(n) => {
                            if let Ok(mut text) = sink.lock() {
                                if text.len() < 16 * 1024 {
                                    text.push_str(&String::from_utf8_lossy(&chunk[..n]));
                                }
                            }
                            for &b in &chunk[..n] {
                                if b == b'\n' || b == b'\r' {
                                    if let Some(frac) = parse_dl_progress(&line) {
                                        dl_update(token, frac);
                                    }
                                    line.clear();
                                } else if line.len() < 512 {
                                    line.push(b as char);
                                }
                            }
                        }
                    }
                }
            })
        });
        let status = child.wait().map_err(|e| format!("yt-dlp: {e}"))?;
        if let Some(reader) = reader {
            let _ = reader.join();
        }

        if let Ok(entries) = std::fs::read_dir(&tmp) {
            for entry in entries.flatten() {
                let path = entry.path();
                let is_mp3 = path
                    .extension()
                    .and_then(|e| e.to_str())
                    .map(|e| e.eq_ignore_ascii_case("mp3"))
                    .unwrap_or(false);
                if is_mp3 {
                    produced = Some(path);
                    break 'attempts;
                }
            }
        }
        if !status.success() {
            let err = stderr_text.lock().map(|text| text.clone()).unwrap_or_default();
            last_err = err.lines().last().unwrap_or("download failed").to_string();
        }
    }

    let produced = match produced {
        Some(path) => path,
        None => {
            let _ = std::fs::remove_dir_all(&tmp);
            return Err(last_err);
        }
    };

    let artist = track.artist.trim();
    let stem = if artist.is_empty() {
        safe_file_stem(&track.title)
    } else {
        format!(
            "{} - {}",
            safe_file_stem(artist),
            safe_file_stem(&track.title)
        )
    };
    let dest = unique_download_path(&dir, &stem);
    if std::fs::rename(&produced, &dest).is_err() {
        if let Err(e) = std::fs::copy(&produced, &dest) {
            let _ = std::fs::remove_dir_all(&tmp);
            return Err(e.to_string());
        }
    }
    let _ = std::fs::remove_dir_all(&tmp);
    Ok(dest)
}

fn ytdlp() -> PathBuf {
    // the installer unpacks yt-dlp here and drops a launcher that starts in a
    // fraction of the time the standalone build needs
    let fast = data_root().join("rustify").join("bin").join("yt-dlp");
    if fast.is_file() {
        return fast;
    }
    if let Ok(home) = std::env::var("HOME") {
        let local = PathBuf::from(home).join(".local/bin/yt-dlp");
        if local.is_file() {
            return local;
        }
    }
    PathBuf::from("yt-dlp")
}

fn resolve_stream(id: &str, quality: &str) -> Result<String, String> {
    resolve_stream_abortable(id, quality, None)
}

// Same as resolve_stream, but a playback request can abort it the moment the
// token is invalidated (skip/cancel) instead of waiting for yt-dlp to exit.
fn resolve_stream_abortable(
    id: &str,
    quality: &str,
    token: Option<PlayToken>,
) -> Result<String, String> {
    if let Some(url) = cached_stream_url(id, quality) {
        return Ok(url);
    }
    let url = format!("https://www.youtube.com/watch?v={id}");
    let mut last_error = String::from("yt-dlp failed");
    for with_cookies in [false, true] {
        if let Some(t) = token {
            if !is_current(t) {
                return Err("cancelled".to_string());
            }
        }
        let mut cmd = Command::new(ytdlp());
        cmd.args([
            "-f",
            audio_format(quality),
            "-g",
            "--no-playlist",
            "--no-warnings",
            url.as_str(),
        ]);
        if with_cookies {
            cmd.args(&yt_cookie_args());
        }
        cmd.stdout(Stdio::piped()).stderr(Stdio::piped());
        let mut child = cmd.spawn().map_err(|e| format!("yt-dlp: {e}"))?;
        let pid = child.id();
        if let Some(t) = token {
            register_load(pid, t);
        }
        let out_reader = child.stdout.take().map(|mut pipe| {
            std::thread::spawn(move || {
                let mut buf = Vec::new();
                let _ = pipe.read_to_end(&mut buf);
                buf
            })
        });
        let err_reader = child.stderr.take().map(|mut pipe| {
            std::thread::spawn(move || {
                let mut buf = Vec::new();
                let _ = pipe.read_to_end(&mut buf);
                buf
            })
        });
        let status = loop {
            if let Some(t) = token {
                if !is_current(t) {
                    terminate_pid(pid);
                    let _ = child.wait();
                    unregister_load(pid);
                    if let Some(reader) = out_reader {
                        let _ = reader.join();
                    }
                    if let Some(reader) = err_reader {
                        let _ = reader.join();
                    }
                    return Err("cancelled".to_string());
                }
            }
            match child.try_wait() {
                Ok(Some(status)) => break status,
                Ok(None) => std::thread::sleep(Duration::from_millis(30)),
                Err(e) => {
                    terminate_pid(pid);
                    let _ = child.wait();
                    unregister_load(pid);
                    if let Some(reader) = out_reader {
                        let _ = reader.join();
                    }
                    if let Some(reader) = err_reader {
                        let _ = reader.join();
                    }
                    return Err(format!("yt-dlp: {e}"));
                }
            }
        };
        unregister_load(pid);
        let stdout = out_reader.map(|r| r.join().unwrap_or_default()).unwrap_or_default();
        let stderr = err_reader.map(|r| r.join().unwrap_or_default()).unwrap_or_default();
        if status.success() {
            if let Some(line) = String::from_utf8_lossy(&stdout)
                .lines()
                .find(|l| l.starts_with("http"))
            {
                let stream_url = line.trim().to_string();
                store_stream_url(id, quality, &stream_url);
                return Ok(stream_url);
            }
            last_error = "no stream url".to_string();
        } else {
            let err = String::from_utf8_lossy(&stderr);
            last_error = err.lines().last().unwrap_or("yt-dlp failed").to_string();
        }
    }
    Err(last_error)
}

// Pull an 11-character video id out of the common YouTube URL shapes. Anything
// that is not a clean YouTube link is left for the normal search path.
fn youtube_video_id(input: &str) -> Option<String> {
    let raw = input.trim();
    if raw.is_empty() || raw.contains(char::is_whitespace) {
        return None;
    }
    let lower = raw.to_ascii_lowercase();
    if !lower.contains("youtube.com") && !lower.contains("youtu.be") {
        return None;
    }
    if let Some(pos) = lower.find("youtu.be/") {
        let tail = &raw[pos + "youtu.be/".len()..];
        let id = tail
            .split(|c: char| matches!(c, '?' | '&' | '#' | '/'))
            .next()
            .unwrap_or("");
        if let Some(id) = valid_video_id(id) {
            return Some(id);
        }
    }
    if let Some(pos) = lower.find("v=") {
        let tail = &raw[pos + 2..];
        let id = tail
            .split(|c: char| matches!(c, '&' | '#' | '?' | '/'))
            .next()
            .unwrap_or("");
        if let Some(id) = valid_video_id(id) {
            return Some(id);
        }
    }
    for marker in ["/shorts/", "/embed/", "/live/", "/v/"] {
        if let Some(pos) = lower.find(marker) {
            let tail = &raw[pos + marker.len()..];
            let id = tail
                .split(|c: char| matches!(c, '?' | '&' | '#' | '/'))
                .next()
                .unwrap_or("");
            if let Some(id) = valid_video_id(id) {
                return Some(id);
            }
        }
    }
    None
}

fn valid_video_id(id: &str) -> Option<String> {
    let id = id.trim();
    if id.len() == 11
        && id
            .chars()
            .all(|c| c.is_ascii_alphanumeric() || c == '-' || c == '_')
    {
        Some(id.to_string())
    } else {
        None
    }
}

// Best-effort title/artist/duration for a pasted link. Playback still works if
// this fails; the track just shows a generic label.
fn fetch_video_meta(id: &str) -> Result<(String, String, u32), String> {
    let url = format!("https://www.youtube.com/watch?v={id}");
    let out = Command::new(ytdlp())
        .args([
            "--no-playlist",
            "--no-warnings",
            "--skip-download",
            "--print",
            "%(title)s\t%(uploader)s\t%(duration_seconds)s",
            url.as_str(),
        ])
        .output()
        .map_err(|e| format!("yt-dlp: {e}"))?;
    if !out.status.success() {
        let err = String::from_utf8_lossy(&out.stderr);
        return Err(err.lines().last().unwrap_or("metadata failed").to_string());
    }
    let text = String::from_utf8_lossy(&out.stdout);
    let line = text
        .lines()
        .find(|l| !l.trim().is_empty())
        .ok_or_else(|| "no metadata".to_string())?;
    let mut fields = line.split('\t');
    let title = fields.next().unwrap_or("").trim().to_string();
    let artist = fields.next().unwrap_or("").trim().to_string();
    let duration_ms = fields
        .next()
        .and_then(|d| d.trim().parse::<f64>().ok())
        .filter(|s| s.is_finite() && *s > 0.0)
        .map(|s| (s * 1000.0).min(u32::MAX as f64) as u32)
        .unwrap_or(0);
    if title.is_empty() {
        return Err("no title".to_string());
    }
    Ok((title, artist, duration_ms))
}

// Search runs against YouTube's InnerTube endpoint: one HTTP round trip instead
// of spawning yt-dlp and waiting for its full JSON. yt-dlp stays as a fallback
// for the day the endpoint or its key changes.
const INNERTUBE_KEY: &str = "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8";
const BROWSER_UA: &str =
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36";
const INNERTUBE_CLIENT_VERSION: &str = "2.20241104.01.00";

fn search(
    client: &reqwest::blocking::Client,
    query: &str,
    limit: usize,
) -> Result<Vec<ResultItem>, String> {
    match search_api(client, query, limit) {
        Ok(items) if !items.is_empty() => Ok(items),
        _ => search_ytdlp(query, limit),
    }
}

// Run one query on its own thread. The short settle window absorbs a burst of
// submissions; a thread that lost the race reports "cancelled" so the worker
// can immediately start the query that superseded it.
fn spawn_search(
    client: reqwest::blocking::Client,
    query: String,
    limit: usize,
    gen: u64,
    tx: Sender<Cmd>,
) {
    std::thread::spawn(move || {
        let deadline = Instant::now() + Duration::from_millis(140);
        while Instant::now() < deadline {
            if SEARCH_GEN.load(Ordering::SeqCst) != gen {
                let _ = tx.send(Cmd::SearchDone {
                    gen,
                    query,
                    limit,
                    items: Err("cancelled".to_string()),
                });
                return;
            }
            std::thread::sleep(Duration::from_millis(20));
        }
        let items = search(&client, &query, limit);
        let _ = tx.send(Cmd::SearchDone {
            gen,
            query,
            limit,
            items,
        });
    });
}

fn search_api(
    client: &reqwest::blocking::Client,
    query: &str,
    limit: usize,
) -> Result<Vec<ResultItem>, String> {
    let body = serde_json::json!({
        "context": {
            "client": {
                "clientName": "WEB",
                "clientVersion": INNERTUBE_CLIENT_VERSION,
                "hl": "en",
                "gl": "US",
            }
        },
        "query": query,
        "params": "EgIQAQ==",
    });
    let url = format!(
        "https://www.youtube.com/youtubei/v1/search?key={INNERTUBE_KEY}&prettyPrint=false"
    );
    let resp = client
        .post(&url)
        .header(reqwest::header::CONTENT_TYPE, "application/json")
        .body(body.to_string())
        .send()
        .map_err(|e| e.to_string())?;
    if !resp.status().is_success() {
        return Err(format!("search HTTP {}", resp.status()));
    }
    let bytes = resp.bytes().map_err(|e| e.to_string())?;
    let json: serde_json::Value = serde_json::from_slice(&bytes).map_err(|e| e.to_string())?;

    let mut items = Vec::with_capacity(limit);
    collect_videos(&json, &mut items, limit);
    Ok(items)
}

fn collect_videos(node: &serde_json::Value, out: &mut Vec<ResultItem>, limit: usize) {
    if out.len() >= limit {
        return;
    }
    match node {
        serde_json::Value::Object(map) => {
            if let Some(renderer) = map.get("videoRenderer") {
                if let Some(item) = parse_video(renderer) {
                    out.push(item);
                }
            }
            for value in map.values() {
                collect_videos(value, out, limit);
            }
        }
        serde_json::Value::Array(arr) => {
            for value in arr {
                collect_videos(value, out, limit);
            }
        }
        _ => {}
    }
}

fn runs_text(node: &serde_json::Value) -> String {
    node.get("runs")
        .and_then(|r| r.as_array())
        .map(|runs| {
            runs.iter()
                .filter_map(|r| r.get("text").and_then(|t| t.as_str()))
                .collect::<String>()
        })
        .filter(|s| !s.is_empty())
        .or_else(|| {
            node.get("simpleText")
                .and_then(|t| t.as_str())
                .map(str::to_string)
        })
        .unwrap_or_default()
}

fn parse_video(renderer: &serde_json::Value) -> Option<ResultItem> {
    let id = renderer.get("videoId")?.as_str()?;
    if id.len() != 11 {
        return None;
    }
    let title = renderer
        .get("title")
        .map(runs_text)
        .filter(|t| !t.is_empty())?;
    let artist = renderer
        .get("ownerText")
        .or_else(|| renderer.get("longBylineText"))
        .map(runs_text)
        .unwrap_or_default();
    let duration_ms = renderer
        .get("lengthText")
        .map(runs_text)
        .and_then(|t| parse_duration(&t))?;
    if duration_ms == 0 {
        return None;
    }
    Some(ResultItem {
        id: id.to_string(),
        title,
        artist,
        duration_ms,
    })
}

fn parse_duration(text: &str) -> Option<u32> {
    let mut seconds: u64 = 0;
    for part in text.trim().split(':') {
        let value: u64 = part.parse().ok()?;
        seconds = seconds * 60 + value;
    }
    if seconds == 0 {
        None
    } else {
        Some((seconds * 1000).min(u32::MAX as u64) as u32)
    }
}

fn search_ytdlp(query: &str, limit: usize) -> Result<Vec<ResultItem>, String> {
    let target = format!("ytsearch{limit}:{query}");
    let out = Command::new(ytdlp())
        .args([
            "--flat-playlist",
            "-J",
            "--no-warnings",
            "--no-playlist",
            target.as_str(),
        ])
        .output()
        .map_err(|e| format!("yt-dlp: {e}"))?;
    if !out.status.success() {
        let err = String::from_utf8_lossy(&out.stderr);
        let last = err.lines().last().unwrap_or("search failed").to_string();
        return Err(last);
    }
    let json: serde_json::Value =
        serde_json::from_slice(&out.stdout).map_err(|e| format!("json: {e}"))?;
    let entries = match json.get("entries").and_then(|e| e.as_array()) {
        Some(e) => e,
        None => return Ok(Vec::new()),
    };

    let mut items = Vec::new();
    for entry in entries {
        let id = entry.get("id").and_then(|v| v.as_str()).unwrap_or("");
        if id.len() != 11 {
            continue;
        }
        let title = entry
            .get("title")
            .and_then(|v| v.as_str())
            .unwrap_or("Unknown")
            .to_string();
        let artist = entry
            .get("uploader")
            .or_else(|| entry.get("channel"))
            .and_then(|v| v.as_str())
            .unwrap_or("")
            .to_string();
        let duration_ms = entry
            .get("duration")
            .and_then(|v| v.as_f64())
            .map(|s| (s * 1000.0) as u32)
            .unwrap_or(0);
        items.push(ResultItem {
            id: id.to_string(),
            title,
            artist,
            duration_ms,
        });
    }
    Ok(items)
}

fn sanitize(id: &str) -> String {
    id.chars()
        .filter(|c| c.is_ascii_alphanumeric() || *c == '-' || *c == '_')
        .collect()
}

// ------------------------------------------------------------- quality
//
// All levels resolve to an m4a/AAC stream: that is what the live pipe decoder
// can play, and YouTube only exposes a couple of reliable m4a bitrates. Each
// expression falls back so a level never hard-fails just because a given
// bitrate is missing for one video.
pub const QUALITY_IDS: [&str; 5] = ["very low", "low", "medium", "high", "max"];
pub const QUALITY_NAMES: [&str; 5] = ["Very low", "Low", "Medium", "High", "Max"];

fn quality_slug(quality: &str) -> &'static str {
    match quality {
        "very low" => "vlow",
        "low" => "low",
        "high" => "high",
        "max" => "max",
        _ => "med",
    }
}

fn audio_format(quality: &str) -> &'static str {
    match quality {
        "very low" => "139/bestaudio[ext=m4a]",
        "low" => "bestaudio[ext=m4a][abr<=100]/139/bestaudio[ext=m4a]",
        "high" => "141/140/139/bestaudio[ext=m4a]",
        "max" => "bestaudio[ext=m4a]",
        _ => "140/139/bestaudio[ext=m4a]",
    }
}

// The cache filename carries the quality so switching levels does not keep
// serving a file fetched at another bitrate.
fn cache_stem(id: &str, quality: &str) -> String {
    format!("{}.{}", sanitize(id), quality_slug(quality))
}

fn cache_root() -> PathBuf {
    if let Ok(dir) = std::env::var("XDG_CACHE_HOME") {
        PathBuf::from(dir).join("rustify")
    } else if let Ok(home) = std::env::var("HOME") {
        PathBuf::from(home).join(".cache").join("rustify")
    } else {
        PathBuf::from("/tmp/rustify")
    }
}

// Standard per-user data root; GTK already searches <data>/icons for themes.
fn data_root() -> PathBuf {
    if let Ok(dir) = std::env::var("XDG_DATA_HOME") {
        PathBuf::from(dir)
    } else if let Ok(home) = std::env::var("HOME") {
        PathBuf::from(home).join(".local").join("share")
    } else {
        cache_root()
    }
}

// Delete the session-only audio cache. The webview profile and settings live
// outside this folder and are left untouched.
fn wipe_audio_cache() {
    let _ = std::fs::remove_dir_all(cache_root().join("audio"));
}

fn set_status(state: &Arc<Mutex<UiState>>, text: &str) {
    if let Ok(mut s) = state.lock() {
        s.status = text.to_string();
    }
}

// Playback volume, capped at 15% when sensitive ears is on.
fn effective_volume(sensitive: bool, volume: f64) -> f32 {
    if sensitive {
        0.15
    } else {
        (volume.clamp(0.0, 100.0) / 100.0) as f32
    }
}

#[cfg(test)]
mod lyrics_tests {
    use super::*;

    #[test]
    fn slug_shape() {
        assert_eq!(genius_slug("Queen Bohemian Rhapsody"), "Queen-bohemian-rhapsody");
        assert_eq!(genius_slug("Don't Stop Me Now"), "Dont-stop-me-now");
    }

    #[test]
    fn parses_container() {
        let html = "<div data-lyrics-container=\"true\">Hello<br>world &amp; <i>all</i></div>";
        let text = extract_genius_lyrics(html).unwrap();
        assert_eq!(text, "Hello\nworld & all");
    }

    #[test]
    #[ignore]
    fn live_genius() {
        let text = fetch_genius_lyrics("Bohemian Rhapsody", "Queen").unwrap();
        eprintln!("{}", &text[..text.len().min(500)]);
        assert!(text.to_lowercase().contains("mama"));
    }
}

#[cfg(test)]
mod url_tests {
    use super::*;

    #[test]
    fn parses_watch_urls() {
        let id = "dQw4w9WgXcQ";
        assert_eq!(
            youtube_video_id(&format!("https://www.youtube.com/watch?v={id}")).as_deref(),
            Some(id)
        );
        assert_eq!(
            youtube_video_id(&format!(
                "https://music.youtube.com/watch?v={id}&list=RDAMVM{id}"
            ))
            .as_deref(),
            Some(id)
        );
        assert_eq!(
            youtube_video_id(&format!("https://youtu.be/{id}?t=43")).as_deref(),
            Some(id)
        );
        assert_eq!(
            youtube_video_id(&format!("https://www.youtube.com/shorts/{id}")).as_deref(),
            Some(id)
        );
    }

    #[test]
    fn rejects_non_urls() {
        assert_eq!(youtube_video_id("never gonna give you up"), None);
        assert_eq!(youtube_video_id("https://example.com/watch?v=dQw4w9WgXcQ"), None);
        assert_eq!(youtube_video_id("https://www.youtube.com/watch?v=short"), None);
    }

    #[test]
    fn parses_progress_lines() {
        assert_eq!(parse_dl_progress("DL 500 1000 NA"), Some(0.5));
        assert_eq!(parse_dl_progress("DL 250 NA 1000"), Some(0.25));
        assert_eq!(parse_dl_progress("DL 2000 1000 NA"), Some(1.0));
        assert_eq!(parse_dl_progress("DL NA 1000 NA"), None);
        assert_eq!(parse_dl_progress("[download] 50%"), None);
    }

    #[test]
    #[ignore]
    fn stream_caches_after_playback() {
        let dir = std::env::temp_dir().join("rustify-stream-cache-test");
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).unwrap();
        let id = "aqz-KE-bpKQ";
        let token = new_play_token();
        let mut src = stream_decoder(id, &dir, false, "medium", token).expect("stream");
        let mut total = 0u64;
        while src.next().is_some() {
            total += 1;
            if total > 500_000_000 {
                break;
            }
        }
        eprintln!("samples: {total}");
        drop(src);
        assert!(
            audio_cached(&dir, id, "medium"),
            "stream did not promote to cache"
        );
    }
}

#[cfg(test)]
mod theme_tests {
    use super::*;

    #[test]
    fn parses_colour_selections() {
        let (bg, btn) = parse_theme_code("1R:2!B").expect("code");
        assert_eq!(bg, vec![(0xef, 0x44, 0x44)]);
        assert_eq!(btn, vec![(0x00, 0x00, 0x00)]);

        let (bg, btn) = parse_theme_code("1-B:2b").expect("code");
        assert_eq!(bg, vec![(0x00, 0x00, 0x00)]);
        assert_eq!(btn, vec![(0x3b, 0x82, 0xf6)]);
    }

    #[test]
    fn parses_gradient_stops_in_order() {
        let (bg, btn) = parse_theme_code("1R:1!B").expect("code");
        assert_eq!(bg, vec![(0xef, 0x44, 0x44), (0x00, 0x00, 0x00)]);
        assert!(btn.is_empty());

        let (bg, _) = parse_theme_code("1R:1B:1!B").expect("code");
        assert_eq!(
            bg,
            vec![
                (0xef, 0x44, 0x44),
                (0x3b, 0x82, 0xf6),
                (0x00, 0x00, 0x00)
            ]
        );
    }

    #[test]
    fn parses_bare_and_named_colours() {
        let (bg, btn) = parse_theme_code("1b").expect("code");
        assert_eq!(bg, vec![(0x3b, 0x82, 0xf6)]);
        assert!(btn.is_empty());
        let (bg, _) = parse_theme_code("1black").expect("code");
        assert_eq!(bg, vec![(0x00, 0x00, 0x00)]);
        let (_, btn) = parse_theme_code("2green").expect("code");
        assert_eq!(btn, vec![(0x22, 0xc5, 0x5e)]);
    }

    #[test]
    fn rejects_bad_codes() {
        assert!(parse_theme_code("").is_none());
        assert!(parse_theme_code("3R").is_none());
        assert!(parse_theme_code("1Q").is_none());
        assert!(parse_theme_code("1#ff0000").is_none());
        // every letter must carry a colour
        assert!(parse_theme_code("1").is_none());
        assert!(parse_theme_code("1:").is_none());
        assert!(parse_theme_code("1-").is_none());
    }
}

#[cfg(test)]
mod lrc_tests {
    use super::*;

    #[test]
    fn parses_timestamps_and_text() {
        let lines = parse_lrc(
            "[00:19.32] We're no strangers to love\n\
             [00:23.21] You know the rules\n",
        );
        assert_eq!(lines.len(), 2);
        assert_eq!(lines[0].at_ms, 19_320);
        assert_eq!(lines[0].text, "We're no strangers to love");
        assert_eq!(lines[1].at_ms, 23_210);
    }

    #[test]
    fn sorts_multiple_stamps_and_applies_offset() {
        let lines = parse_lrc(
            "[offset:-500]\n\
             [00:10.00][00:20.00] chorus\n\
             [00:05.00] verse\n",
        );
        assert_eq!(lines.len(), 3);
        assert_eq!(lines[0].at_ms, 4_500);
        assert_eq!(lines[1].at_ms, 9_500);
        assert_eq!(lines[2].at_ms, 19_500);
        assert!(lines.iter().all(|l| l.text == "chorus" || l.text == "verse"));
    }

    #[test]
    fn strips_enhanced_word_tags_and_metadata() {
        let lines = parse_lrc("[ar:Rick Astley]\n[00:01.5] <00:01.50>Hello <00:02.00>world\n");
        assert_eq!(lines.len(), 1);
        assert_eq!(lines[0].at_ms, 1_500);
        assert_eq!(lines[0].text, "Hello world");
    }

    #[test]
    fn finds_active_line() {
        let lines = vec![
            LyricLine { at_ms: 1_000, text: "a".into() },
            LyricLine { at_ms: 2_000, text: "b".into() },
            LyricLine { at_ms: 3_000, text: "c".into() },
        ];
        assert_eq!(lyric_index_at(&lines, 0), None);
        assert_eq!(lyric_index_at(&lines, 1_000), Some(0));
        assert_eq!(lyric_index_at(&lines, 2_500), Some(1));
        assert_eq!(lyric_index_at(&lines, 9_000), Some(2));
    }

    #[test]
    #[ignore]
    fn live_lrclib() {
        match fetch_lrclib_lyrics("Never Gonna Give You Up", "Rick Astley", 214_000) {
            Some(LrclibLyrics::Synced(text)) => {
                let lines = parse_lrc(&text);
                assert!(lines.len() > 10);
                assert!(lines
                    .iter()
                    .any(|line| line.text.to_lowercase().contains("never gonna give you up")));
            }
            _ => panic!("no synced lyrics returned"),
        }
    }
}

#[cfg(test)]
mod seek_tests {
    use super::*;

    #[test]
    #[ignore]
    fn http_seek_forward_then_back() {
        let id = "dQw4w9WgXcQ";
        let url = resolve_stream(id, "medium").expect("resolve");
        let dir = std::env::temp_dir().join("rustify-seek-test");
        let _ = std::fs::create_dir_all(&dir);
        let token = new_play_token();
        let mut source = http_decoder(id, &url, &dir, "medium", token).expect("decoder");

        for _ in 0..2000 {
            let _ = source.next();
        }
        let fwd = source.try_seek(Duration::from_secs(180));
        println!("seek forward: {fwd:?}");

        let mut after_fwd = 0;
        for _ in 0..4000 {
            match source.next() {
                Some(_) => after_fwd += 1,
                None => break,
            }
        }
        println!("samples after forward seek: {after_fwd}");

        let back = source.try_seek(Duration::from_secs(5));
        println!("seek back: {back:?}");

        let mut after_back = 0;
        for _ in 0..4000 {
            match source.next() {
                Some(_) => after_back += 1,
                None => break,
            }
        }
        println!("samples after back seek: {after_back}");

        assert!(after_fwd > 0, "no samples after forward seek");
        assert!(after_back > 0, "no samples after backward seek");
    }
}

#[cfg(test)]
mod miniplayer_tests {
    use super::*;

    #[test]
    fn synced_pair_tracks_playhead() {
        let lines = vec![
            LyricLine { at_ms: 0, text: "one".into() },
            LyricLine { at_ms: 1_000, text: "two".into() },
            LyricLine { at_ms: 2_000, text: "three".into() },
        ];
        assert_eq!(
            mini_lyric_pair("", &lines, 0, 3_000),
            ("one".to_string(), "two".to_string())
        );
        assert_eq!(
            mini_lyric_pair("", &lines, 1_500, 3_000),
            ("two".to_string(), "three".to_string())
        );
        assert_eq!(
            mini_lyric_pair("", &lines, 9_999, 3_000),
            ("three".to_string(), String::new())
        );
    }

    #[test]
    fn plain_pair_tracks_fraction() {
        let plain = "one\n\ntwo\nthree\nfour";
        assert_eq!(
            mini_lyric_pair(plain, &[], 0, 4_000),
            ("one".to_string(), "two".to_string())
        );
        assert_eq!(
            mini_lyric_pair(plain, &[], 2_500, 4_000),
            ("three".to_string(), "four".to_string())
        );
        assert_eq!(
            mini_lyric_pair(plain, &[], 4_000, 4_000),
            ("four".to_string(), String::new())
        );
    }
}
